import re

with open("app/src/main/java/com/example/MilageViewModel.kt", "r") as f:
    content = f.read()

old_save = """    fun saveServiceRecord(record: ServiceRecord) {
        viewModelScope.launch {
            serviceRecordDao.insertServiceRecord(record)
        }
    }"""

new_save = """    fun saveServiceRecord(record: ServiceRecord) {
        viewModelScope.launch {
            val id = serviceRecordDao.insertServiceRecord(record)
            val updatedRecord = record.copy(id = id.toInt())
            ServicingAlarmScheduler.scheduleServicingAlarm(getApplication(), updatedRecord)
        }
    }"""

content = content.replace(old_save, new_save)

old_delete = """    fun deleteServiceRecord(record: ServiceRecord) {
        viewModelScope.launch {
            serviceRecordDao.deleteServiceRecord(record)
        }
    }"""

new_delete = """    fun deleteServiceRecord(record: ServiceRecord) {
        viewModelScope.launch {
            serviceRecordDao.deleteServiceRecord(record)
            ServicingAlarmScheduler.cancelServicingAlarm(getApplication(), record)
        }
    }"""

content = content.replace(old_delete, new_delete)

with open("app/src/main/java/com/example/MilageViewModel.kt", "w") as f:
    f.write(content)
