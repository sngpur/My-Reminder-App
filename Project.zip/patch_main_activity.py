import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

nav_route_code = """        composable("placeholder/{title}") { backStackEntry ->
            val title = backStackEntry.arguments?.getString("title") ?: "Coming Soon"
            PlaceholderScreen(navController = navController, title = title)
        }
        composable(
            "notification_details/{entityType}/{entityId}?isAlarmRinging={isAlarmRinging}",
            arguments = listOf(
                androidx.navigation.navArgument("entityType") { type = androidx.navigation.NavType.StringType },
                androidx.navigation.navArgument("entityId") { type = androidx.navigation.NavType.IntType },
                androidx.navigation.navArgument("isAlarmRinging") { type = androidx.navigation.NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val entityType = backStackEntry.arguments?.getString("entityType") ?: ""
            val entityId = backStackEntry.arguments?.getInt("entityId") ?: 0
            val isAlarmRinging = backStackEntry.arguments?.getBoolean("isAlarmRinging") ?: false
            NotificationDetailsScreen(
                navController = navController,
                entityId = entityId,
                entityType = entityType,
                initialIsAlarmRinging = isAlarmRinging
            )
        }"""

content = content.replace("""        composable("placeholder/{title}") { backStackEntry ->
            val title = backStackEntry.arguments?.getString("title") ?: "Coming Soon"
            PlaceholderScreen(navController = navController, title = title)
        }""", nav_route_code)

initial_route_code = """    val initialRoute = intent?.getStringExtra("route") ?: "home"
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = initialRoute) {"""

# Replace `val navController = rememberNavController()`
# and `NavHost(...)`
import re
content = re.sub(r'val navController = rememberNavController\(\)\s*NavHost\(navController = navController, startDestination = "home"\) \{', 
                 r'val initialRoute = (context as? android.app.Activity)?.intent?.getStringExtra("route") ?: "home"\n    val navController = rememberNavController()\n\n    NavHost(navController = navController, startDestination = "home") {\n        LaunchedEffect(initialRoute) {\n            if (initialRoute != "home") {\n                navController.navigate(initialRoute)\n            }\n        }', 
                 content)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
