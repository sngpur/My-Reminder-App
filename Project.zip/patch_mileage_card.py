import re

with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "r") as f:
    content = f.read()

# Add a Delete confirmation state for each item. Instead of multiple states, we can handle this by adding
# a `var showDeleteConfirm by remember { mutableStateOf(false) }` inside the `itemsIndexed` block
# But wait, itemsIndexed is a Composable block, we can just extract it to a composable or do it inline.
# Better to extract it to a `FuelRecordItem` composable to manage its state cleanly.

new_composable = """
@Composable
fun FuelRecordItem(
    record: FuelRecord,
    previousRecord: FuelRecord?,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showDelete by remember { mutableStateOf(false) }
    
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete Record") },
            text = { Text("Are you sure you want to delete this fuel record?") },
            confirmButton = { TextButton(onClick = { showDelete = false; onDelete() }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }

    val distance = previousRecord?.let { record.odometerKm - it.odometerKm } ?: 0
    val milage = if (distance > 0 && record.fuelLiters > 0) distance / record.fuelLiters else 0.0
    val dayGap = previousRecord?.let { 
         ChronoUnit.DAYS.between(
            Instant.ofEpochMilli(it.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate(),
            Instant.ofEpochMilli(record.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        )
    } ?: 0

    Card(
        modifier = Modifier.fillMaxWidth().clickable { onEdit() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Instant.ofEpochMilli(record.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${record.odometerKm} km", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = { showDelete = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.LocalGasStation, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${record.fuelLiters} L", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
                if (previousRecord != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Speed, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(String.format(Locale.getDefault(), "%.1f km/l", milage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text("+$distance km • $dayGap days", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
"""

replacement = """
                itemsIndexed(sortedRecords) { index, record ->
                    val previousRecord = if (index + 1 < sortedRecords.size) sortedRecords[index + 1] else null
                    FuelRecordItem(
                        record = record,
                        previousRecord = previousRecord,
                        onEdit = {
                            logToEdit = record
                            showFuelDialog = true
                        },
                        onDelete = { viewModel.deleteFuelRecord(record) }
                    )
                }
"""

# Replace the Card block inside itemsIndexed
content = re.sub(
    r'itemsIndexed\(sortedRecords\)\s*\{\s*index,\s*record\s*->.*?val previousRecord.*?Card\([^)]+\)\s*\{.*?Column.*?\}\s*\}\s*\}',
    replacement.strip(),
    content,
    flags=re.DOTALL
)

if "@Composable\nfun FuelRecordItem" not in content:
    content = content + "\n" + new_composable

# Need to ensure Delete icon is imported
if "import androidx.compose.material.icons.filled.Delete" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.Add", "import androidx.compose.material.icons.filled.Add\nimport androidx.compose.material.icons.filled.Delete")
    
if "import androidx.compose.foundation.clickable" not in content:
    content = content.replace("import androidx.compose.foundation.layout.*", "import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.clickable")

with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "w") as f:
    f.write(content)
