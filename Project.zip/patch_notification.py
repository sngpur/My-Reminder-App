import re

with open("app/src/main/java/com/example/NotificationReceiver.kt", "r") as f:
    content = f.read()

old_builder = """            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(category)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent)
                .build()"""

new_builder = """            val completeIntent = Intent(context, MarkCompleteReceiver::class.java).apply {
                putExtra("id", id)
            }
            val completePendingIntent = PendingIntent.getBroadcast(
                context, id + 20000, completeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(category)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_menu_edit, "Mark Complete", completePendingIntent)
                .build()"""

content = content.replace(old_builder, new_builder)

with open("app/src/main/java/com/example/NotificationReceiver.kt", "w") as f:
    f.write(content)
