with open("app/src/main/java/com/example/NotificationDetailsScreen.kt", "r") as f:
    content = f.read()

content = content.replace("package com.example", "package com.example\nimport androidx.lifecycle.compose.collectAsStateWithLifecycle")

with open("app/src/main/java/com/example/NotificationDetailsScreen.kt", "w") as f:
    f.write(content)
