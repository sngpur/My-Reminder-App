import re

with open("app/src/main/java/com/example/ReminderViewModel.kt", "r") as f:
    content = f.read()

content = content.replace("val trashedReminders: StateFlow<List<Reminder>> = dao.getTrashedReminders()", 
"""val trashedReminders: StateFlow<List<Reminder>> = dao.getTrashedReminders()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )""")
with open("app/src/main/java/com/example/ReminderViewModel.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/NoteViewModel.kt", "r") as f:
    content = f.read()

content = content.replace("val trashedNotes: StateFlow<List<Note>> = noteDao.getTrashedNotes()",
"""val trashedNotes: StateFlow<List<Note>> = noteDao.getTrashedNotes()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )""")
with open("app/src/main/java/com/example/NoteViewModel.kt", "w") as f:
    f.write(content)
