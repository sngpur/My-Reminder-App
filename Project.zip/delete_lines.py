with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "r") as f:
    lines = f.readlines()

# delete lines 341-346 (0-indexed 340-345)
del lines[340:346]

with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "w") as f:
    f.write("".join(lines))
