with open("app/src/main/java/com/example/WhatsAppAlarmScheduler.kt", "r") as f:
    content = f.read()

old_block = """            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                schedule.scheduledTimeInMillis,
                pendingIntent
            )"""
new_block = """            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, schedule.scheduledTimeInMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, schedule.scheduledTimeInMillis, pendingIntent)
            }"""

content = content.replace(old_block, new_block)

with open("app/src/main/java/com/example/WhatsAppAlarmScheduler.kt", "w") as f:
    f.write(content)

