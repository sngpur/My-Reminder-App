import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

# Uncomment camera and permissions
content = content.replace("// implementation(libs.accompanist.permissions)", "implementation(libs.accompanist.permissions)")
content = content.replace("// implementation(libs.androidx.camera.camera2)", "implementation(libs.androidx.camera.camera2)")
content = content.replace("// implementation(libs.androidx.camera.core)", "implementation(libs.androidx.camera.core)")
content = content.replace("// implementation(libs.androidx.camera.lifecycle)", "implementation(libs.androidx.camera.lifecycle)")
content = content.replace("// implementation(libs.androidx.camera.view)", "implementation(libs.androidx.camera.view)")

# Add ML kit and zxing
mlkit_zxing = """  implementation("com.google.mlkit:barcode-scanning:17.3.0")
  implementation("com.google.zxing:core:3.5.3")"""

if "com.google.mlkit:barcode-scanning" not in content:
    content = content.replace('implementation("com.google.mlkit:text-recognition:16.0.1")', 
                              'implementation("com.google.mlkit:text-recognition:16.0.1")\n' + mlkit_zxing)

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
