package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.Reminder
import com.example.ui.ReminderItemRow
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    val sampleReminder = Reminder(
        id = 1,
        taskTitle = "Payment for 70x70 plot construction materials",
        category = "Upcoming Payment",
        taskDate = "04 Jul 2026",
        taskTime = "11:00 AM",
        location = "Jamtara, Jharkhand"
    )

    composeTestRule.setContent {
      MyApplicationTheme {
        ReminderItemRow(
            reminder = sampleReminder,
            onToggleComplete = {},
            onDelete = {},
            onEdit = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
