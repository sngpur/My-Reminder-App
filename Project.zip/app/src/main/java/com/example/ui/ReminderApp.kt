package com.example.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.Reminder
import java.text.SimpleDateFormat
import java.util.*

enum class Screen {
    Home, AddReminder, MonthlySummary
}

// Helper to safely extract Month and Day from different stored string formats
fun getMonthAndDay(dateStr: String): Pair<String, String> {
    val formats = listOf("dd MMM yyyy", "yyyy-MM-dd", "d MMM yyyy")
    for (format in formats) {
        try {
            val sdf = SimpleDateFormat(format, Locale.getDefault())
            sdf.isLenient = false
            val date = sdf.parse(dateStr)
            if (date != null) {
                val month = SimpleDateFormat("MMM", Locale.getDefault()).format(date).uppercase()
                val day = SimpleDateFormat("dd", Locale.getDefault()).format(date)
                return Pair(month, day)
            }
        } catch (e: Exception) {
            // Keep looking
        }
    }
    // Simple heuristic parser
    try {
        val parts = dateStr.split(" ", "-")
        if (parts.size >= 2) {
            val first = parts[0]
            val second = parts[1]
            if (first.length == 4) { // yyyy-mm-dd
                val monthMap = listOf("", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
                val monthIdx = second.toIntOrNull() ?: 1
                val mStr = monthMap.getOrNull(monthIdx) ?: "REM"
                val dStr = parts.getOrNull(2) ?: "01"
                return Pair(mStr, dStr)
            } else if (second.length >= 3) { // dd MMM yyyy
                return Pair(second.substring(0, 3).uppercase(), first)
            }
        }
    } catch (e: Exception) {}
    return Pair("REM", "!!")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderApp(viewModel: ReminderViewModel) {
    var currentScreen by remember { mutableStateOf(Screen.Home) }
    val reminders by viewModel.allReminders.collectAsState()
    val activeReminders by viewModel.activeReminders.collectAsState()
    val isDark by viewModel.isDarkTheme.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterCategory by remember { mutableStateOf("All") }

    // State for tap-to-edit and delete-confirmation dialog
    var reminderToEdit by remember { mutableStateOf<Reminder?>(null) }
    var reminderToDelete by remember { mutableStateOf<Reminder?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                Screen.Home -> {
                    HomeScreen(
                        modifier = Modifier.padding(innerPadding),
                        reminders = reminders,
                        activeReminders = activeReminders,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        selectedCategory = selectedFilterCategory,
                        onCategorySelect = { selectedFilterCategory = it },
                        onToggleComplete = { viewModel.toggleCompletion(it) },
                        onDeletePress = { reminderToDelete = it },
                        onNavigateToAdd = {
                            reminderToEdit = null
                            currentScreen = Screen.AddReminder
                        },
                        onNavigateToEdit = { reminder ->
                            reminderToEdit = reminder
                            currentScreen = Screen.AddReminder
                        },
                        onNavigateToSummary = {
                            currentScreen = Screen.MonthlySummary
                        },
                        isDark = isDark,
                        onToggleTheme = { viewModel.toggleTheme() }
                    )
                }
                Screen.AddReminder -> {
                    AddReminderScreen(
                        modifier = Modifier.padding(innerPadding),
                        reminderToEdit = reminderToEdit,
                        onBack = {
                            reminderToEdit = null
                            currentScreen = Screen.Home
                        },
                        onSave = { title, category, dateStr, timeStr, locStr, amount, millis ->
                            if (reminderToEdit != null) {
                                viewModel.updateReminder(
                                    id = reminderToEdit!!.id,
                                    title = title,
                                    category = category,
                                    dateStr = dateStr,
                                    timeStr = timeStr,
                                    location = locStr,
                                    amount = amount,
                                    isCompleted = reminderToEdit!!.isCompleted,
                                    dateTimeMillis = millis
                                )
                            } else {
                                viewModel.addReminder(title, category, dateStr, timeStr, locStr, amount, millis)
                            }
                            reminderToEdit = null
                            currentScreen = Screen.Home
                        }
                    )
                }
                Screen.MonthlySummary -> {
                    MonthlySummaryScreen(
                        modifier = Modifier.padding(innerPadding),
                        reminders = reminders,
                        onBack = { currentScreen = Screen.Home }
                    )
                }
            }
        }
    }

    // Yes/No confirmation dialog before deleting a task
    if (reminderToDelete != null) {
        AlertDialog(
            onDismissRequest = { reminderToDelete = null },
            title = { Text("Delete Reminder", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete this reminder?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        reminderToDelete?.let { viewModel.deleteReminder(it) }
                        reminderToDelete = null
                    },
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Yes", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { reminderToDelete = null },
                    modifier = Modifier.testTag("dismiss_delete_button")
                ) {
                    Text("No", fontWeight = FontWeight.Medium)
                }
            }
        )
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier,
    reminders: List<Reminder>,
    activeReminders: List<Reminder>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedCategory: String,
    onCategorySelect: (String) -> Unit,
    onToggleComplete: (Reminder) -> Unit,
    onDeletePress: (Reminder) -> Unit,
    onNavigateToAdd: () -> Unit,
    onNavigateToEdit: (Reminder) -> Unit,
    onNavigateToSummary: () -> Unit,
    isDark: Boolean,
    onToggleTheme: () -> Unit
) {
    // Determine the next immediate active task in the future (sorted chronologically)
    val now = System.currentTimeMillis()
    val nearestReminder = activeReminders.firstOrNull { it.dateTimeMillis > now } ?: activeReminders.firstOrNull()

    // Current Month calculations for Finance Card
    val currentCalendar = Calendar.getInstance()
    val currentYear = currentCalendar.get(Calendar.YEAR)
    val currentMonth = currentCalendar.get(Calendar.MONTH)

    var currentMonthPayment = 0.0
    var currentMonthLent = 0.0

    for (reminder in reminders) {
        val remCal = Calendar.getInstance().apply { timeInMillis = reminder.dateTimeMillis }
        val isCurrentMonth = remCal.get(Calendar.YEAR) == currentYear && remCal.get(Calendar.MONTH) == currentMonth
        if (isCurrentMonth) {
            if (reminder.category == "Upcoming Payment") {
                currentMonthPayment += reminder.amount
            } else if (reminder.category == "Money Lent (Udhar)") {
                currentMonthLent += reminder.amount
            }
        }
    }

    val filteredReminders = reminders.filter { reminder ->
        val matchesSearch = reminder.taskTitle.contains(searchQuery, ignoreCase = true) ||
                reminder.location.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategory == "All" || reminder.category == selectedCategory
        matchesSearch && matchesCategory
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Section - High Stylized Bento Box Logo and profile
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFF6366F1), // Indigo
                                            Color(0xFFA855F7), // Purple
                                            Color(0xFFEC4899)  // Pink
                                        )
                                    )
                                )
                                .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "S",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = (-1.5).sp
                            )
                        }

                        Column {
                            Text(
                                text = "Somnath",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "REMINDER",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                letterSpacing = 2.sp,
                                modifier = Modifier.alpha(0.7f)
                            )
                        }
                    }

                    // Theme toggle + Profile Icon
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = onToggleTheme,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .testTag("theme_toggle")
                        ) {
                            Icon(
                                imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Theme",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Profile Icon placeholder as requested by Bento style
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Profile",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Bento Dashboard containing Nearest Upcoming Task & Finance Summaries
            item {
                StatsDashboard(
                    nearestReminder = nearestReminder,
                    currentMonthPayment = currentMonthPayment,
                    currentMonthLent = currentMonthLent,
                    onClickFinance = onNavigateToSummary
                )
            }

            // Search Bar Input
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_bar"),
                    placeholder = { Text("Search task or location...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon", tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )
            }

            // Horizontal Categories Filter Row
            item {
                val categories = listOf("All", "Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other")
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(categories) { cat ->
                        val isSelected = selectedCategory == cat
                        val displayLabel = if (cat == "Money Lent (Udhar)") "Udhar" else cat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.surface
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) Color.Transparent else MaterialTheme.colorScheme.outlineVariant,
                                    shape = RoundedCornerShape(99.dp)
                                )
                                .clickable { onCategorySelect(cat) }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = displayLabel,
                                color = if (isSelected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Schedule List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "UPCOMING SCHEDULE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "View All (${filteredReminders.size})",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onCategorySelect("All") }
                    )
                }
            }

            // Reminders List items
            if (filteredReminders.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.NotificationsActive,
                            contentDescription = "No notifications",
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Reminders Found",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Tap the '+' button below to schedule your tasks.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                }
            } else {
                items(filteredReminders, key = { it.id }) { reminder ->
                    ReminderItemRow(
                        reminder = reminder,
                        onToggleComplete = onToggleComplete,
                        onDelete = onDeletePress,
                        onEdit = onNavigateToEdit
                    )
                }
            }
        }

        // Floating Action Button to Add Reminder
        FloatingActionButton(
            onClick = onNavigateToAdd,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("add_reminder_fab"),
            containerColor = MaterialTheme.colorScheme.onSurface,
            contentColor = MaterialTheme.colorScheme.background,
            shape = RoundedCornerShape(20.dp),
            elevation = FloatingActionButtonDefaults.elevation(8.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Reminder", modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
fun StatsDashboard(
    nearestReminder: Reminder?,
    currentMonthPayment: Double,
    currentMonthLent: Double,
    onClickFinance: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Left Bento Grid Cell: Nearest Upcoming Task
        Card(
            modifier = Modifier
                .weight(1.1f)
                .aspectRatio(1.2f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = "Upcoming Task",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "UPCOMING",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Column {
                    if (nearestReminder != null) {
                        Text(
                            text = nearestReminder.taskTitle,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${nearestReminder.taskDate} • ${nearestReminder.taskTime}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(
                            text = "No upcoming tasks",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "All tasks completed!",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Right Bento Grid Cell: Finance Card displaying Current Month Summary (Clickable to breakdown)
        Card(
            modifier = Modifier
                .weight(1.1f)
                .aspectRatio(1.2f)
                .clickable { onClickFinance() }
                .testTag("finance_card"),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    )
                    .padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = "Finance Stats",
                                tint = Color(0xFFA855F7),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "FINANCE",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Pay: ₹${currentMonthPayment.toInt()}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Lent: ₹${currentMonthLent.toInt()}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "View Breakdown →",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReminderItemRow(
    reminder: Reminder,
    onToggleComplete: (Reminder) -> Unit,
    onDelete: (Reminder) -> Unit,
    onEdit: (Reminder) -> Unit
) {
    val categoryColor = when (reminder.category) {
        "Upcoming Payment" -> Color(0xFFEF4444) // Vibrant Red
        "Money Lent (Udhar)" -> Color(0xFF22C55E) // Vibrant Green
        "Personal Work" -> Color(0xFF3B82F6) // Vibrant Blue
        else -> Color(0xFF8B5CF6) // Purple for Other
    }

    val (month, day) = getMonthAndDay(reminder.taskDate)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("reminder_item_${reminder.id}")
            .clickable { onEdit(reminder) }, // Tapping the task launches edit form
        colors = CardDefaults.cardColors(
            containerColor = if (reminder.isCompleted) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = if (reminder.isCompleted) 0.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // One-click quick toggle checkbox on the extreme left
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (reminder.isCompleted) categoryColor else MaterialTheme.colorScheme.surface)
                    .border(2.dp, if (reminder.isCompleted) Color.Transparent else categoryColor, CircleShape)
                    .clickable { onToggleComplete(reminder) }
                    .testTag("check_box_${reminder.id}"),
                contentAlignment = Alignment.Center
            ) {
                if (reminder.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Divided Date Block (Month & Day display)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .width(54.dp)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = month,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = day,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Divider vertical line
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(44.dp)
                    .background(MaterialTheme.colorScheme.outlineVariant)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Core Reminder Text Information Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Category Mini Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(categoryColor.copy(alpha = 0.1f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = reminder.category,
                            color = categoryColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    // Time display
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Time",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = reminder.taskTime,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Title (crossed out if completed)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = reminder.taskTitle,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (reminder.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                        textDecoration = if (reminder.isCompleted) TextDecoration.LineThrough else null,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    // If there is an amount, show it clearly on the item
                    if (reminder.amount > 0.0) {
                        Text(
                            text = "₹${reminder.amount.toInt()}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor
                        )
                    }
                }

                if (reminder.location.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Location",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = reminder.location,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Delete action button (displays Yes/No popup)
            IconButton(
                onClick = { onDelete(reminder) },
                modifier = Modifier
                    .testTag("delete_button_${reminder.id}")
                    .padding(start = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete Reminder",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddReminderScreen(
    modifier: Modifier,
    reminderToEdit: Reminder? = null,
    onBack: () -> Unit,
    onSave: (title: String, category: String, dateStr: String, timeStr: String, locStr: String, amount: Double, millis: Long) -> Unit
) {
    val context = LocalContext.current
    val calendar = remember {
        Calendar.getInstance().apply {
            if (reminderToEdit != null) {
                timeInMillis = reminderToEdit.dateTimeMillis
            }
        }
    }

    var title by remember { mutableStateOf(reminderToEdit?.taskTitle ?: "") }
    var location by remember { mutableStateOf(reminderToEdit?.location ?: "") }
    var selectedCategory by remember { mutableStateOf(reminderToEdit?.category ?: "Upcoming Payment") }
    var amountStr by remember { mutableStateOf(reminderToEdit?.amount?.let { if (it > 0) it.toString() else "" } ?: "") }

    // Date & Time label states
    var dateLabel by remember { mutableStateOf(reminderToEdit?.taskDate ?: "") }
    var timeLabel by remember { mutableStateOf(reminderToEdit?.taskTime ?: "") }

    var yearVal by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }
    var monthVal by remember { mutableStateOf(calendar.get(Calendar.MONTH) + 1) }
    var dayVal by remember { mutableStateOf(calendar.get(Calendar.DAY_OF_MONTH)) }
    var hourVal by remember { mutableStateOf(calendar.get(Calendar.HOUR_OF_DAY)) }
    var minuteVal by remember { mutableStateOf(calendar.get(Calendar.MINUTE)) }

    var expanded by remember { mutableStateOf(false) }
    val categories = listOf("Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other")

    // Validation checks: Amount in ₹ is mandatory only when "Upcoming Payment" or "Money Lent" is selected
    val isAmountRequired = selectedCategory == "Upcoming Payment" || selectedCategory == "Money Lent (Udhar)"
    val parsedAmount = amountStr.toDoubleOrNull() ?: 0.0
    val isAmountValid = !isAmountRequired || (amountStr.isNotBlank() && parsedAmount > 0.0)
    val isFormValid = title.isNotBlank() && dateLabel.isNotBlank() && timeLabel.isNotBlank() && isAmountValid

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {
        // Styled Top Navigation Back Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                    .testTag("back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = if (reminderToEdit != null) "Edit Reminder" else "New Reminder",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                letterSpacing = (-0.5).sp
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Task Name details text field
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "WHAT IS THIS REMINDER FOR?",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("task_title_input"),
                            placeholder = { Text("Enter task details...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            // Category choice dropdown list card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CHOOSE CATEGORY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = selectedCategory,
                                onValueChange = {},
                                readOnly = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expanded = true }
                                    .testTag("category_dropdown_trigger"),
                                trailingIcon = {
                                    IconButton(onClick = { expanded = !expanded }) {
                                        Icon(
                                            imageVector = if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                            contentDescription = "Dropdown"
                                        )
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .background(MaterialTheme.colorScheme.surface)
                            ) {
                                categories.forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category, color = MaterialTheme.colorScheme.onSurface) },
                                        onClick = {
                                            selectedCategory = category
                                            expanded = false
                                        },
                                        modifier = Modifier.testTag("category_option_$category")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Mandatory dynamic 'Amount in ₹' column - Animates in beautifully only when needed
            item {
                AnimatedVisibility(
                    visible = isAmountRequired,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.padding(bottom = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "AMOUNT IN ₹ (MANDATORY) *",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEF4444),
                                letterSpacing = 0.5.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            OutlinedTextField(
                                value = amountStr,
                                onValueChange = { amountStr = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("amount_input"),
                                placeholder = { Text("E.g., 5000", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                                ),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            // Date Picker Bento trigger button
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CHOOSE DATE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedButton(
                            onClick = {
                                DatePickerDialog(
                                    context,
                                    { _, sYear, sMonth, sDay ->
                                        yearVal = sYear
                                        monthVal = sMonth + 1
                                        dayVal = sDay
                                        val dateCal = Calendar.getInstance().apply {
                                            set(Calendar.YEAR, sYear)
                                            set(Calendar.MONTH, sMonth)
                                            set(Calendar.DAY_OF_MONTH, sDay)
                                        }
                                        val formatter = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                                        dateLabel = formatter.format(dateCal.time)
                                    },
                                    yearVal,
                                    monthVal - 1,
                                    dayVal
                                ).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("date_picker_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (dateLabel.isEmpty()) "Select Due Date" else dateLabel,
                                    color = if (dateLabel.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Icon(Icons.Default.Event, contentDescription = "Choose Date", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // Time Picker Bento trigger button
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CHOOSE TIME",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(
                                    context,
                                    { _, sHour, sMinute ->
                                        hourVal = sHour
                                        minuteVal = sMinute
                                        val timeCal = Calendar.getInstance().apply {
                                            set(Calendar.HOUR_OF_DAY, sHour)
                                            set(Calendar.MINUTE, sMinute)
                                        }
                                        val formatter = SimpleDateFormat("hh:mm a", Locale.getDefault())
                                        timeLabel = formatter.format(timeCal.time)
                                    },
                                    hourVal,
                                    minuteVal,
                                    false
                                ).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("time_picker_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (timeLabel.isEmpty()) "Select Alert Time" else timeLabel,
                                    color = if (timeLabel.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Icon(Icons.Default.AccessTime, contentDescription = "Choose Time", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // Location details Input Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "LOCATION (OPTIONAL)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedTextField(
                            value = location,
                            onValueChange = { location = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("location_input"),
                            placeholder = { Text("E.g., Jamtara, Jharkhand", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)) },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = "Location Pin", tint = MaterialTheme.colorScheme.primary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Save Reminder Button
        Button(
            onClick = {
                if (isFormValid) {
                    val finalCalendar = Calendar.getInstance().apply {
                        set(Calendar.YEAR, yearVal)
                        set(Calendar.MONTH, monthVal - 1)
                        set(Calendar.DAY_OF_MONTH, dayVal)
                        set(Calendar.HOUR_OF_DAY, hourVal)
                        set(Calendar.MINUTE, minuteVal)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    onSave(
                        title.trim(),
                        selectedCategory,
                        dateLabel,
                        timeLabel,
                        location.trim(),
                        if (isAmountRequired) parsedAmount else 0.0,
                        finalCalendar.timeInMillis
                    )
                } else {
                    Toast.makeText(context, "Please enter all required fields", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("save_reminder_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isFormValid) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f),
                contentColor = MaterialTheme.colorScheme.background
            ),
            shape = RoundedCornerShape(16.dp),
            enabled = isFormValid
        ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.background)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Save Reminder",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun MonthlySummaryScreen(
    modifier: Modifier,
    reminders: List<Reminder>,
    onBack: () -> Unit
) {
    // Group reminders by year and month
    val summaries = remember(reminders) {
        reminders.groupBy { reminder ->
            val cal = Calendar.getInstance().apply { timeInMillis = reminder.dateTimeMillis }
            Pair(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH))
        }.map { (key, list) ->
            val (year, monthIdx) = key
            val cal = Calendar.getInstance().apply {
                set(Calendar.YEAR, year)
                set(Calendar.MONTH, monthIdx)
            }
            val monthName = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
            val totalPayment = list.filter { it.category == "Upcoming Payment" }.sumOf { it.amount }
            val totalLent = list.filter { it.category == "Money Lent (Udhar)" }.sumOf { it.amount }
            MonthSummary(year, monthIdx, monthName, totalPayment, totalLent)
        }.sortedWith(compareByDescending<MonthSummary> { it.year }.thenByDescending { it.month })
    }

    val lifetimePayment = reminders.filter { it.category == "Upcoming Payment" }.sumOf { it.amount }
    val lifetimeLent = reminders.filter { it.category == "Money Lent (Udhar)" }.sumOf { it.amount }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {
        // Top back button and title
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                    .testTag("summary_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Finance Summary",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                letterSpacing = (-0.5).sp
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Lifetime stats cards in Bento style
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "TOTAL PAYMENTS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEF4444)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "₹${lifetimePayment.toInt()}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "TOTAL LENT (UDHAR)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF22C55E)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "₹${lifetimeLent.toInt()}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "MONTHLY BREAKDOWN",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (summaries.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No financial records available yet.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(summaries) { summary ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = summary.monthName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Column(
                                horizontalAlignment = Alignment.End
                              ) {
                                Text(
                                    text = "Payments: ₹${summary.totalPayment.toInt()}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFEF4444)
                                )
                                Text(
                                    text = "Lent: ₹${summary.totalLent.toInt()}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF22C55E)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

data class MonthSummary(
    val year: Int,
    val month: Int,
    val monthName: String,
    val totalPayment: Double,
    val totalLent: Double
)
