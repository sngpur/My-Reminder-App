package com.example.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.Reminder
import java.text.SimpleDateFormat
import java.util.*

enum class Screen {
    Home, AddReminder
}

// Helper to safely extract Month and Day from different stored string formats
fun getMonthAndDay(dateStr: String): Pair<String, String> {
    val formats = listOf("dd MMM yyyy", "yyyy-MM-dd", "d MMM yyyy")
    for (format in formats) {
        try {
            val sdf = SimpleDateFormat(format, Locale.getDefault())
            sdf.isLenient = false
            val date = sdf.parse(dateStr)
            if (date != null) {
                val month = SimpleDateFormat("MMM", Locale.getDefault()).format(date).uppercase()
                val day = SimpleDateFormat("dd", Locale.getDefault()).format(date)
                return Pair(month, day)
            }
        } catch (e: Exception) {
            // Keep looking
        }
    }
    // Simple heuristic parser
    try {
        val parts = dateStr.split(" ", "-")
        if (parts.size >= 2) {
            val first = parts[0]
            val second = parts[1]
            if (first.length == 4) { // yyyy-mm-dd
                val monthMap = listOf("", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
                val monthIdx = second.toIntOrNull() ?: 1
                val mStr = monthMap.getOrNull(monthIdx) ?: "REM"
                val dStr = parts.getOrNull(2) ?: "01"
                return Pair(mStr, dStr)
            } else if (second.length >= 3) { // dd MMM yyyy
                return Pair(second.substring(0, 3).uppercase(), first)
            }
        }
    } catch (e: Exception) {}
    return Pair("REM", "!!")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderApp(viewModel: ReminderViewModel) {
    var currentScreen by remember { mutableStateOf(Screen.Home) }
    val reminders by viewModel.allReminders.collectAsState()
    val activeReminders by viewModel.activeReminders.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterCategory by remember { mutableStateOf("All") }

    Scaffold(
        containerColor = Color(0xFFF8F9FA) // Bento Grid light-slate layout background
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                Screen.Home -> {
                    HomeScreen(
                        modifier = Modifier.padding(innerPadding),
                        reminders = reminders,
                        activeReminders = activeReminders,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        selectedCategory = selectedFilterCategory,
                        onCategorySelect = { selectedFilterCategory = it },
                        onToggleComplete = { viewModel.toggleCompletion(it) },
                        onDelete = { viewModel.deleteReminder(it) },
                        onNavigateToAdd = { currentScreen = Screen.AddReminder }
                    )
                }
                Screen.AddReminder -> {
                    AddReminderScreen(
                        modifier = Modifier.padding(innerPadding),
                        onBack = { currentScreen = Screen.Home },
                        onSave = { title, category, dateStr, timeStr, locStr, millis ->
                            viewModel.addReminder(title, category, dateStr, timeStr, locStr, millis)
                            currentScreen = Screen.Home
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier,
    reminders: List<Reminder>,
    activeReminders: List<Reminder>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedCategory: String,
    onCategorySelect: (String) -> Unit,
    onToggleComplete: (Reminder) -> Unit,
    onDelete: (Reminder) -> Unit,
    onNavigateToAdd: () -> Unit
) {
    // Counts for bento tiles
    val activeCount = activeReminders.size
    val udharCount = activeReminders.count { it.category == "Money Lent (Udhar)" }

    val filteredReminders = reminders.filter { reminder ->
        val matchesSearch = reminder.taskTitle.contains(searchQuery, ignoreCase = true) ||
                reminder.location.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategory == "All" || reminder.category == selectedCategory
        matchesSearch && matchesCategory
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FA))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Section - High Stylized Gradient Logo Box with bold "S"
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Prominent "S" Logo with Premium Gradient Finish (Bento Style)
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            Color(0xFF6366F1), // Indigo
                                            Color(0xFFA855F7), // Purple
                                            Color(0xFFEC4899)  // Pink
                                        )
                                    )
                                )
                                .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "S",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = (-1.5).sp
                            )
                        }

                        Column {
                            Text(
                                text = "Somnath",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1C1B1F),
                                letterSpacing = (-0.5).sp
                            )
                            Text(
                                text = "REMINDER",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF49454F),
                                letterSpacing = 2.sp,
                                modifier = Modifier.alpha(0.7f)
                            )
                        }
                    }

                    // Profile Icon placeholder as requested by Bento style
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE2E8F0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Stats Dashboard Card styled exactly as the Bento Grid layout
            item {
                StatsDashboard(
                    activeCount = activeCount,
                    udharCount = udharCount
                )
            }

            // Search Bar Input
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_bar"),
                    placeholder = { Text("Search task or location...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6366F1),
                        unfocusedBorderColor = Color(0xFFE2E8F0),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )
            }

            // Horizontal Categories Filter Row (Bento rounded capsule chips)
            item {
                val categories = listOf("All", "Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other")
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(categories) { cat ->
                        val isSelected = selectedCategory == cat
                        val displayLabel = if (cat == "Money Lent (Udhar)") "Udhar" else cat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(
                                    if (isSelected) Color(0xFF1C1B1F) else Color.White
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) Color.Transparent else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(99.dp)
                                )
                                .clickable { onCategorySelect(cat) }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = displayLabel,
                                color = if (isSelected) Color.White else Color(0xFF49454F),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Schedule List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "UPCOMING SCHEDULE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF49454F),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "View All (${filteredReminders.size})",
                        fontSize = 11.sp,
                        color = Color(0xFF6366F1),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onCategorySelect("All") }
                    )
                }
            }

            // Reminders List items
            if (filteredReminders.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.NotificationsActive,
                            contentDescription = "No notifications",
                            modifier = Modifier.size(56.dp),
                            tint = Color(0xFFCBD5E1)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Reminders Found",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "Tap the '+' button below to schedule your tasks.",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                }
            } else {
                items(filteredReminders, key = { it.id }) { reminder ->
                    ReminderItemRow(
                        reminder = reminder,
                        onToggleComplete = onToggleComplete,
                        onDelete = onDelete
                    )
                }
            }
        }

        // Floating Action Button to Add Reminder
        FloatingActionButton(
            onClick = onNavigateToAdd,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("add_reminder_fab"),
            containerColor = Color(0xFF1C1B1F),
            contentColor = Color.White,
            shape = RoundedCornerShape(20.dp),
            elevation = FloatingActionButtonDefaults.elevation(8.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Reminder", modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
fun StatsDashboard(activeCount: Int, udharCount: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Left Bento Grid Cell: Active Reminders Count (Aspect ratio 1:1)
        Card(
            modifier = Modifier
                .weight(1f)
                .aspectRatio(1.2f),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFEEF2FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AssignmentLate,
                        contentDescription = "Active Tasks",
                        tint = Color(0xFF6366F1),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = String.format("%02d", activeCount),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF1C1B1F)
                    )
                    Text(
                        text = "Active Tasks",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }

        // Right Bento Grid Cell: Premium Dark Slate Gradient layout for Udhar / Finance Tracker
        Card(
            modifier = Modifier
                .weight(1f)
                .aspectRatio(1.2f),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF1C1B1F),
                                Color(0xFF49454F)
                            )
                        )
                    )
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = "Udhar",
                                tint = Color(0xFFA855F7),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "FINANCE",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                    Column {
                        Text(
                            text = if (udharCount > 0) "$udharCount Pending" else "No Udhar",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Udhar (Lent)",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReminderItemRow(
    reminder: Reminder,
    onToggleComplete: (Reminder) -> Unit,
    onDelete: (Reminder) -> Unit
) {
    val categoryColor = when (reminder.category) {
        "Upcoming Payment" -> Color(0xFFEF4444) // Vibrant Red
        "Money Lent (Udhar)" -> Color(0xFF22C55E) // Vibrant Green
        "Personal Work" -> Color(0xFF3B82F6) // Vibrant Blue
        else -> Color(0xFF8B5CF6) // Purple for Other
    }

    val (month, day) = getMonthAndDay(reminder.taskDate)

    // Bento styling with thin border, white card background, left date block, and right actions
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("reminder_item_${reminder.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (reminder.isCompleted) Color(0xFFF1F5F9) else Color.White
        ),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (reminder.isCompleted) 0.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // One-click quick toggle checkbox on the extreme left
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (reminder.isCompleted) categoryColor else Color.White)
                    .border(2.dp, if (reminder.isCompleted) Color.Transparent else categoryColor, CircleShape)
                    .clickable { onToggleComplete(reminder) }
                    .testTag("check_box_${reminder.id}"),
                contentAlignment = Alignment.Center
            ) {
                if (reminder.isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Divided Date Block (Month & Day display)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .width(54.dp)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = month,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
                Text(
                    text = day,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF1C1B1F)
                )
            }

            // Divider vertical line
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(44.dp)
                    .background(Color(0xFFE2E8F0))
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Core Reminder Text Information Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Category Mini Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(categoryColor.copy(alpha = 0.1f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = reminder.category,
                            color = categoryColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    // Time display
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Time",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = reminder.taskTime,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Title (crossed out if completed)
                Text(
                    text = reminder.taskTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (reminder.isCompleted) Color(0xFF94A3B8) else Color(0xFF1C1B1F),
                    textDecoration = if (reminder.isCompleted) TextDecoration.LineThrough else null,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (reminder.location.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = "Location",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = reminder.location,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Delete action button
            IconButton(
                onClick = { onDelete(reminder) },
                modifier = Modifier
                    .testTag("delete_button_${reminder.id}")
                    .padding(start = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete Reminder",
                    tint = Color(0xFFCBD5E1),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddReminderScreen(
    modifier: Modifier,
    onBack: () -> Unit,
    onSave: (title: String, category: String, dateStr: String, timeStr: String, locStr: String, millis: Long) -> Unit
) {
    val context = LocalContext.current
    val calendar = remember { Calendar.getInstance() }

    var title by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Upcoming Payment") }

    // Date & Time label states
    var dateLabel by remember { mutableStateOf("") }
    var timeLabel by remember { mutableStateOf("") }

    var yearVal by remember { mutableStateOf(0) }
    var monthVal by remember { mutableStateOf(0) }
    var dayVal by remember { mutableStateOf(0) }
    var hourVal by remember { mutableStateOf(0) }
    var minuteVal by remember { mutableStateOf(0) }

    var expanded by remember { mutableStateOf(false) }
    val categories = listOf("Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other")

    val isFormValid = title.isNotBlank() && dateLabel.isNotBlank() && timeLabel.isNotBlank()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FA))
            .padding(24.dp)
    ) {
        // Styled Top Navigation Back Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE2E8F0), CircleShape)
                    .testTag("back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFF1C1B1F))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "New Reminder",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1B1F),
                letterSpacing = (-0.5).sp
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Task Name details text field
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "WHAT IS THIS REMINDER FOR?",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("task_title_input"),
                            placeholder = { Text("Enter task details...") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF6366F1),
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            // Category choice dropdown list card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CHOOSE CATEGORY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = selectedCategory,
                                onValueChange = {},
                                readOnly = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expanded = true }
                                    .testTag("category_dropdown_trigger"),
                                trailingIcon = {
                                    IconButton(onClick = { expanded = !expanded }) {
                                        Icon(
                                            imageVector = if (expanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                            contentDescription = "Dropdown"
                                        )
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF6366F1),
                                    unfocusedBorderColor = Color(0xFFE2E8F0)
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .background(Color.White)
                            ) {
                                categories.forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category) },
                                        onClick = {
                                            selectedCategory = category
                                            expanded = false
                                        },
                                        modifier = Modifier.testTag("category_option_$category")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Date Picker Bento trigger button
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CHOOSE DATE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedButton(
                            onClick = {
                                DatePickerDialog(
                                    context,
                                    { _, sYear, sMonth, sDay ->
                                        yearVal = sYear
                                        monthVal = sMonth + 1
                                        dayVal = sDay
                                        val dateCal = Calendar.getInstance().apply {
                                            set(Calendar.YEAR, sYear)
                                            set(Calendar.MONTH, sMonth)
                                            set(Calendar.DAY_OF_MONTH, sDay)
                                        }
                                        val formatter = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                                        dateLabel = formatter.format(dateCal.time)
                                    },
                                    calendar.get(Calendar.YEAR),
                                    calendar.get(Calendar.MONTH),
                                    calendar.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("date_picker_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1C1B1F)),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (dateLabel.isEmpty()) "Select Due Date" else dateLabel,
                                    color = if (dateLabel.isEmpty()) Color(0xFF94A3B8) else Color(0xFF1C1B1F),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Icon(Icons.Default.Event, contentDescription = "Choose Date", tint = Color(0xFF6366F1))
                            }
                        }
                    }
                }
            }

            // Time Picker Bento trigger button
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "CHOOSE TIME",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(
                                    context,
                                    { _, sHour, sMinute ->
                                        hourVal = sHour
                                        minuteVal = sMinute
                                        val timeCal = Calendar.getInstance().apply {
                                            set(Calendar.HOUR_OF_DAY, sHour)
                                            set(Calendar.MINUTE, sMinute)
                                        }
                                        val formatter = SimpleDateFormat("hh:mm a", Locale.getDefault())
                                        timeLabel = formatter.format(timeCal.time)
                                    },
                                    calendar.get(Calendar.HOUR_OF_DAY),
                                    calendar.get(Calendar.MINUTE),
                                    false
                                ).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("time_picker_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF1C1B1F)),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (timeLabel.isEmpty()) "Select Alert Time" else timeLabel,
                                    color = if (timeLabel.isEmpty()) Color(0xFF94A3B8) else Color(0xFF1C1B1F),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Icon(Icons.Default.AccessTime, contentDescription = "Choose Time", tint = Color(0xFFA855F7))
                            }
                        }
                    }
                }
            }

            // Location details Input Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "LOCATION (OPTIONAL)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        OutlinedTextField(
                            value = location,
                            onValueChange = { location = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("location_input"),
                            placeholder = { Text("E.g., Jamtara, Jharkhand") },
                            leadingIcon = { Icon(Icons.Default.Place, contentDescription = "Location Pin", tint = Color(0xFFEF4444)) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF6366F1),
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Save Reminder Button
        Button(
            onClick = {
                if (isFormValid) {
                    val finalCalendar = Calendar.getInstance().apply {
                        set(Calendar.YEAR, yearVal)
                        set(Calendar.MONTH, monthVal - 1)
                        set(Calendar.DAY_OF_MONTH, dayVal)
                        set(Calendar.HOUR_OF_DAY, hourVal)
                        set(Calendar.MINUTE, minuteVal)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    onSave(
                        title.trim(),
                        selectedCategory,
                        dateLabel,
                        timeLabel,
                        location.trim(),
                        finalCalendar.timeInMillis
                    )
                } else {
                    Toast.makeText(context, "Please enter all required fields", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("save_reminder_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isFormValid) Color(0xFF1C1B1F) else Color(0xFFCBD5E1),
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(16.dp),
            enabled = isFormValid
        ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Save Reminder",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
