package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = Color(0xFF6366F1), // Indigo
    secondary = Color(0xFFA855F7), // Purple
    tertiary = Color(0xFFEC4899),  // Pink
    background = Color(0xFF0F172A), // rich slate-900
    surface = Color(0xFF1E293B), // slate-800
    onBackground = Color(0xFFF1F5F9), // slate-100
    onSurface = Color(0xFFF1F5F9), // slate-100
    outlineVariant = Color(0xFF334155), // slate-700
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFF94A3B8) // slate-400
  )

private val LightColorScheme =
  lightColorScheme(
    primary = Color(0xFF6366F1), // Indigo
    secondary = Color(0xFFA855F7), // Purple
    tertiary = Color(0xFFEC4899),  // Pink
    background = Color(0xFFF8F9FA), // soft off-white
    surface = Color.White,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF1C1B1F),
    outlineVariant = Color(0xFFE2E8F0),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF64748B)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
