package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium indicator colors & primary theme
val PrimaryBrand = Color(0xFF3498DB) // "S" brand blue
val SecondaryBrand = Color(0xFF2C3E50)
val SoftGrey = Color(0xFFF5F5F5)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF3498DB)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
