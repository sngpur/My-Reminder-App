package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium indicator colors & primary theme
val PrimaryBrand = Color(0xFF3498DB) // "S" brand blue
val SecondaryBrand = Color(0xFF2C3E50)
val SoftGrey = Color(0xFFF5F5F5)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF3498DB)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Premium Dark Theme Colors
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkPrimary = Color(0xFF818CF8) // Soft indigo/blue
val DarkSecondary = Color(0xFFFBBF24) // Soft amber/gold
val DarkTertiary = Color(0xFF34D399) // Soft emerald/teal
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkError = Color(0xFFF87171)
val DarkOnError = Color(0xFF450A0A)
