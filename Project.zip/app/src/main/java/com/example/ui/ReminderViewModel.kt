package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Reminder
import com.example.data.ReminderRepository
import com.example.notification.NotificationHelper
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReminderViewModel(
    private val repository: ReminderRepository,
    private val notificationHelper: NotificationHelper
) : ViewModel() {

    val allReminders: StateFlow<List<Reminder>> = repository.allReminders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeReminders: StateFlow<List<Reminder>> = repository.activeReminders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch {
            try {
                val currentReminders = repository.allReminders.first()
                if (currentReminders.isEmpty()) {
                    prepopulateData()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private suspend fun prepopulateData() {
        val dummyReminders = listOf(
            Reminder(
                taskTitle = "Payment for 70x70 plot construction materials",
                category = "Upcoming Payment",
                taskDate = "2026-07-04",
                taskTime = "11:00 AM",
                location = "Jamtara, Jharkhand",
                dateTimeMillis = calculateMillis(2026, 7, 4, 11, 0)
            ),
            Reminder(
                taskTitle = "Sonali chicken feed order for Jenny Farm",
                category = "Personal Work",
                taskDate = "2026-07-05",
                taskTime = "02:30 PM",
                location = "Jamtara, Jharkhand",
                dateTimeMillis = calculateMillis(2026, 7, 5, 14, 30)
            ),
            Reminder(
                taskTitle = "Money lent to Suresh for emergency",
                category = "Money Lent (Udhar)",
                taskDate = "2026-07-06",
                taskTime = "04:00 PM",
                location = "",
                dateTimeMillis = calculateMillis(2026, 7, 6, 16, 0)
            ),
            Reminder(
                taskTitle = "Railway duty roster update",
                category = "Personal Work",
                taskDate = "2026-07-08",
                taskTime = "09:00 AM",
                location = "",
                dateTimeMillis = calculateMillis(2026, 7, 8, 9, 0)
            )
        )

        for (reminder in dummyReminders) {
            val id = repository.insert(reminder)
            notificationHelper.scheduleAlarm(reminder.copy(id = id))
        }
    }

    fun addReminder(
        title: String,
        category: String,
        dateStr: String,
        timeStr: String,
        location: String,
        dateTimeMillis: Long
    ) {
        viewModelScope.launch {
            val reminder = Reminder(
                taskTitle = title,
                category = category,
                taskDate = dateStr,
                taskTime = timeStr,
                location = location,
                isCompleted = false,
                dateTimeMillis = dateTimeMillis
            )
            val id = repository.insert(reminder)
            val scheduledReminder = reminder.copy(id = id)
            notificationHelper.scheduleAlarm(scheduledReminder)
        }
    }

    fun toggleCompletion(reminder: Reminder) {
        viewModelScope.launch {
            val updated = reminder.copy(isCompleted = !reminder.isCompleted)
            repository.update(updated)
            if (updated.isCompleted) {
                notificationHelper.cancelAlarm(reminder.id)
            } else {
                notificationHelper.scheduleAlarm(updated)
            }
        }
    }

    fun deleteReminder(reminder: Reminder) {
        viewModelScope.launch {
            repository.delete(reminder)
            notificationHelper.cancelAlarm(reminder.id)
        }
    }

    fun calculateMillis(year: Int, month: Int, day: Int, hour: Int, minute: Int): Long {
        val calendar = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.YEAR, year)
            set(java.util.Calendar.MONTH, month - 1) // 0-indexed month
            set(java.util.Calendar.DAY_OF_MONTH, day)
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }
}

class ReminderViewModelFactory(
    private val repository: ReminderRepository,
    private val notificationHelper: NotificationHelper
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ReminderViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ReminderViewModel(repository, notificationHelper) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
