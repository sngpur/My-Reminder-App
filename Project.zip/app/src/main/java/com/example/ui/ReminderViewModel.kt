package com.example.ui

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Reminder
import com.example.data.ReminderRepository
import com.example.data.jsonObjectToReminder
import com.example.data.calculateNextOccurrence
import com.example.notification.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray

class ReminderViewModel(
    private val repository: ReminderRepository,
    private val notificationHelper: NotificationHelper,
    private val context: Context
) : ViewModel() {

    private val sharedPreferences = context.getSharedPreferences("somnath_reminder_prefs", Context.MODE_PRIVATE)

    private val _isDarkTheme = MutableStateFlow(sharedPreferences.getBoolean("dark_theme", false))
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleTheme() {
        val nextValue = !_isDarkTheme.value
        _isDarkTheme.value = nextValue
        sharedPreferences.edit().putBoolean("dark_theme", nextValue).apply()
    }

    val allReminders: StateFlow<List<Reminder>> = repository.allReminders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeReminders: StateFlow<List<Reminder>> = repository.activeReminders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch {
            try {
                val currentReminders = repository.allReminders.first()
                if (currentReminders.isEmpty()) {
                    prepopulateData()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private suspend fun prepopulateData() {
        val dummyReminders = listOf(
            Reminder(
                taskTitle = "Payment for 70x70 plot construction materials",
                category = "Upcoming Payment",
                taskDate = "2026-07-04",
                taskTime = "11:00 AM",
                location = "Jamtara, Jharkhand",
                amount = 45000.0,
                dateTimeMillis = calculateMillis(2026, 7, 4, 11, 0),
                reminder1Date = "2026-07-04",
                reminder1Time = "11:00 AM",
                reminder1Millis = calculateMillis(2026, 7, 4, 11, 0)
            ),
            Reminder(
                taskTitle = "Sonali chicken feed order for Jenny Farm",
                category = "Personal Work",
                taskDate = "2026-07-05",
                taskTime = "02:30 PM",
                location = "Jamtara, Jharkhand",
                amount = 0.0,
                dateTimeMillis = calculateMillis(2026, 7, 5, 14, 30),
                reminder1Date = "2026-07-05",
                reminder1Time = "02:30 PM",
                reminder1Millis = calculateMillis(2026, 7, 5, 14, 30)
            ),
            Reminder(
                taskTitle = "Money lent to Suresh for emergency",
                category = "Money Lent (Udhar)",
                taskDate = "2026-07-06",
                taskTime = "04:00 PM",
                location = "",
                amount = 15000.0,
                dateTimeMillis = calculateMillis(2026, 7, 6, 16, 0),
                reminder1Date = "2026-07-06",
                reminder1Time = "04:00 PM",
                reminder1Millis = calculateMillis(2026, 7, 6, 16, 0)
            ),
            Reminder(
                taskTitle = "Railway duty roster update",
                category = "Personal Work",
                taskDate = "2026-07-08",
                taskTime = "09:00 AM",
                location = "",
                amount = 0.0,
                dateTimeMillis = calculateMillis(2026, 7, 8, 9, 0),
                reminder1Date = "2026-07-08",
                reminder1Time = "09:00 AM",
                reminder1Millis = calculateMillis(2026, 7, 8, 9, 0)
            )
        )

        for (reminder in dummyReminders) {
            val id = repository.insert(reminder)
            notificationHelper.scheduleAlarm(reminder.copy(id = id))
        }
    }

    fun addReminder(
        title: String,
        category: String,
        location: String,
        amount: Double,
        reminder1Date: String,
        reminder1Time: String,
        reminder1Millis: Long,
        reminder2Date: String = "",
        reminder2Time: String = "",
        reminder2Millis: Long = 0L,
        reminder3Date: String = "",
        reminder3Time: String = "",
        reminder3Millis: Long = 0L,
        repeatInterval: String = "None",
        tags: String = "",
        imageUri: String = ""
    ) {
        viewModelScope.launch {
            val reminder = Reminder(
                taskTitle = title,
                category = category,
                taskDate = reminder1Date,
                taskTime = reminder1Time,
                location = location,
                amount = amount,
                isCompleted = false,
                dateTimeMillis = reminder1Millis,
                reminder1Date = reminder1Date,
                reminder1Time = reminder1Time,
                reminder1Millis = reminder1Millis,
                reminder2Date = reminder2Date,
                reminder2Time = reminder2Time,
                reminder2Millis = reminder2Millis,
                reminder3Date = reminder3Date,
                reminder3Time = reminder3Time,
                reminder3Millis = reminder3Millis,
                repeatInterval = repeatInterval,
                tags = tags,
                imageUri = imageUri
            )
            val id = repository.insert(reminder)
            notificationHelper.scheduleAlarm(reminder.copy(id = id))
        }
    }

    fun updateReminder(
        id: Long,
        title: String,
        category: String,
        location: String,
        amount: Double,
        isCompleted: Boolean,
        reminder1Date: String,
        reminder1Time: String,
        reminder1Millis: Long,
        reminder2Date: String = "",
        reminder2Time: String = "",
        reminder2Millis: Long = 0L,
        reminder3Date: String = "",
        reminder3Time: String = "",
        reminder3Millis: Long = 0L,
        repeatInterval: String = "None",
        tags: String = "",
        imageUri: String = ""
    ) {
        viewModelScope.launch {
            val reminder = Reminder(
                id = id,
                taskTitle = title,
                category = category,
                taskDate = reminder1Date,
                taskTime = reminder1Time,
                location = location,
                amount = amount,
                isCompleted = isCompleted,
                dateTimeMillis = reminder1Millis,
                reminder1Date = reminder1Date,
                reminder1Time = reminder1Time,
                reminder1Millis = reminder1Millis,
                reminder2Date = reminder2Date,
                reminder2Time = reminder2Time,
                reminder2Millis = reminder2Millis,
                reminder3Date = reminder3Date,
                reminder3Time = reminder3Time,
                reminder3Millis = reminder3Millis,
                repeatInterval = repeatInterval,
                tags = tags,
                imageUri = imageUri
            )
            if (isCompleted && repeatInterval != "None") {
                val nextReminder = calculateNextOccurrence(reminder)
                repository.update(nextReminder)
                notificationHelper.scheduleAlarm(nextReminder)
                Toast.makeText(context, "Rescheduled repeat task to ${nextReminder.taskDate}", Toast.LENGTH_LONG).show()
            } else {
                repository.update(reminder)
                if (!isCompleted) {
                    notificationHelper.scheduleAlarm(reminder)
                } else {
                    notificationHelper.cancelAlarm(reminder.id)
                }
            }
        }
    }

    fun toggleCompletion(reminder: Reminder) {
        viewModelScope.launch {
            if (!reminder.isCompleted && reminder.repeatInterval != "None") {
                val nextReminder = calculateNextOccurrence(reminder)
                repository.update(nextReminder)
                notificationHelper.scheduleAlarm(nextReminder)
                Toast.makeText(context, "Completed! Next alarm: ${nextReminder.taskDate} at ${nextReminder.taskTime}", Toast.LENGTH_LONG).show()
            } else {
                val updated = reminder.copy(isCompleted = !reminder.isCompleted)
                repository.update(updated)
                if (updated.isCompleted) {
                    notificationHelper.cancelAlarm(reminder.id)
                } else {
                    notificationHelper.scheduleAlarm(updated)
                }
            }
        }
    }

    fun deleteReminder(reminder: Reminder) {
        viewModelScope.launch {
            repository.delete(reminder)
            notificationHelper.cancelAlarm(reminder.id)
        }
    }

    fun exportData(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val remindersList = repository.allReminders.first()
                val jsonArray = JSONArray()
                for (reminder in remindersList) {
                    jsonArray.put(reminder.toJsonObject())
                }
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    outputStream.write(jsonArray.toString(4).toByteArray())
                }
                Toast.makeText(context, "Data exported successfully!", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to export data: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun importData(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val content = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    inputStream.bufferedReader().use { it.readText() }
                } ?: throw Exception("Could not open file")

                val jsonArray = JSONArray(content)
                val imported = mutableListOf<Reminder>()
                for (i in 0 until jsonArray.length()) {
                    imported.add(jsonObjectToReminder(jsonArray.getJSONObject(i)))
                }

                // Cancel existing scheduled alarms
                val currentReminders = repository.allReminders.first()
                for (rem in currentReminders) {
                    notificationHelper.cancelAlarm(rem.id)
                    repository.delete(rem)
                }

                // Insert all imported reminders and reschedule alarms
                for (rem in imported) {
                    val newId = repository.insert(rem.copy(id = 0L)) // 0L lets Room auto-generate a fresh, collision-free ID
                    notificationHelper.scheduleAlarm(rem.copy(id = newId))
                }

                Toast.makeText(context, "Imported ${imported.size} records successfully!", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to import data: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun calculateMillis(year: Int, month: Int, day: Int, hour: Int, minute: Int): Long {
        val calendar = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.YEAR, year)
            set(java.util.Calendar.MONTH, month - 1) // 0-indexed month
            set(java.util.Calendar.DAY_OF_MONTH, day)
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }
}

class ReminderViewModelFactory(
    private val repository: ReminderRepository,
    private val notificationHelper: NotificationHelper,
    private val context: Context
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ReminderViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ReminderViewModel(repository, notificationHelper, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
