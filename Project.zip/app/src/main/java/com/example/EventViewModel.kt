package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EventViewModel(application: Application) : AndroidViewModel(application) {
    private val eventDao = AppDatabase.getDatabase(application).eventDao()

    val allEvents: StateFlow<List<Event>> = eventDao.getAllEvents()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateEvent(event: Event) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            eventDao.updateEvent(event)
            AlarmScheduler.scheduleEventAlarm(getApplication(), event)
        }
    }

    fun deleteEvent(event: Event) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            eventDao.deleteEvent(event)
            AlarmScheduler.cancelEventAlarm(getApplication(), event)
        }
    }

    fun addEvent(event: Event) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val id = eventDao.insertEvent(event)
            val insertedEvent = event.copy(id = id.toInt())
            AlarmScheduler.scheduleEventAlarm(getApplication(), insertedEvent)
        }
    }
}
