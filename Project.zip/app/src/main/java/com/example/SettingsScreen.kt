package com.example

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.content.ComponentName
import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlinx.coroutines.launch
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, settingsViewModel: SettingsViewModel, reminderViewModel: ReminderViewModel) {
    val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
    val isAutoBackupEnabled by settingsViewModel.isAutoBackupEnabled.collectAsStateWithLifecycle()
    val reminders by reminderViewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }
    var pendingAction by remember { mutableStateOf("") } // "backup" or "restore"
    
    val fullBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    FullBackupManager.performBackup(context, it, passwordInput)
                    Toast.makeText(context, "Full Backup Successful", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Backup Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    val fullRestoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    val success = FullBackupManager.performRestore(context, it, passwordInput)
                    if (success) {
                        Toast.makeText(context, "Full Restore Successful", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Restore Failed (Invalid Password?)", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Restore Failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        val jsonArray = JSONArray()
                        reminders.forEach { r ->
                            val obj = JSONObject()
                            obj.put("taskTitle", r.taskTitle)
                            obj.put("category", r.category)
                            obj.put("taskDate", r.taskDate)
                            obj.put("taskTime", r.taskTime)
                            obj.put("reminder2Date", r.reminder2Date ?: JSONObject.NULL)
                            obj.put("reminder2Time", r.reminder2Time ?: JSONObject.NULL)
                            obj.put("reminder3Date", r.reminder3Date ?: JSONObject.NULL)
                            obj.put("reminder3Time", r.reminder3Time ?: JSONObject.NULL)
                            obj.put("isCompleted", r.isCompleted)
                            obj.put("location", r.location)
                            obj.put("amount", r.amount ?: JSONObject.NULL)
                            jsonArray.put(obj)
                        }
                        writer.write(jsonArray.toString(2))
                    }
                }
                Toast.makeText(context, "Data exported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    InputStreamReader(inputStream).use { reader ->
                        val jsonStr = reader.readText()
                        val jsonArray = JSONArray(jsonStr)
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.getJSONObject(i)
                            val reminder = Reminder(
                                taskTitle = obj.getString("taskTitle"),
                                category = obj.getString("category"),
                                taskDate = obj.getString("taskDate"),
                                taskTime = obj.getString("taskTime"),
                                reminder2Date = if (obj.isNull("reminder2Date")) null else obj.getString("reminder2Date"),
                                reminder2Time = if (obj.isNull("reminder2Time")) null else obj.getString("reminder2Time"),
                                reminder3Date = if (obj.isNull("reminder3Date")) null else obj.getString("reminder3Date"),
                                reminder3Time = if (obj.isNull("reminder3Time")) null else obj.getString("reminder3Time"),
                                isCompleted = obj.getBoolean("isCompleted"),
                                location = obj.optString("location", ""),
                                amount = if (obj.isNull("amount")) null else obj.getDouble("amount")
                            )
                            reminderViewModel.addReminder(reminder)
                        }
                    }
                }
                Toast.makeText(context, "Data imported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Import failed or invalid format", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Dark Mode", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = isDarkMode,
                    onCheckedChange = { settingsViewModel.setDarkMode(it) }
                )
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Enable Auto-Backup (Weekly)", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = isAutoBackupEnabled,
                    onCheckedChange = { settingsViewModel.setAutoBackup(it) }
                )
            }

            HorizontalDivider()

                        HorizontalDivider()
            var isSyncEnabled by remember { mutableStateOf(false) }
            val ipAddress = remember { com.example.PcSyncService.getLocalIpAddress() ?: "localhost" }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("PC Sync Dashboard", style = MaterialTheme.typography.titleMedium)
                    if (isSyncEnabled) {
                        Text("http://$ipAddress:8080/dashboard", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Switch(
                    checked = isSyncEnabled,
                    onCheckedChange = { 
                        isSyncEnabled = it
                        if (it) {
                            val intent = android.content.Intent(context, com.example.PcSyncService::class.java)
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                context.startForegroundService(intent)
                            } else {
                                context.startService(intent)
                            }
                        } else {
                            context.stopService(android.content.Intent(context, com.example.PcSyncService::class.java))
                        }
                    }
                )
            }

            Text("Full App Backup (Secure)", style = MaterialTheme.typography.titleMedium)
            
            Button(
                onClick = { 
                    pendingAction = "backup"
                    passwordInput = ""
                    showPasswordDialog = true 
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Backup All Data (.mbk)")
            }
            
            OutlinedButton(
                onClick = { 
                    pendingAction = "restore"
                    passwordInput = ""
                    showPasswordDialog = true 
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Restore All Data (.mbk)")
            }
            
            if (showPasswordDialog) {
                AlertDialog(
                    onDismissRequest = { showPasswordDialog = false },
                    title = { Text(if (pendingAction == "backup") "Secure Backup" else "Decrypt Backup") },
                    text = {
                        Column {
                            Text("Enter a password to encrypt/decrypt your backup.")
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text("Password") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            showPasswordDialog = false
                            if (passwordInput.isNotBlank()) {
                                if (pendingAction == "backup") {
                                    fullBackupLauncher.launch("MyBuddyBackup.mbk")
                                } else {
                                    fullRestoreLauncher.launch(arrayOf("*/*"))
                                }
                            }
                        }) {
                            Text("Confirm")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showPasswordDialog = false }) { Text("Cancel") }
                    }
                )
            }

        }
        }
    }
