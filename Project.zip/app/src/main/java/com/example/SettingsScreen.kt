package com.example

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, settingsViewModel: SettingsViewModel, reminderViewModel: ReminderViewModel) {
    val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
    val reminders by reminderViewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        val jsonArray = JSONArray()
                        reminders.forEach { r ->
                            val obj = JSONObject()
                            obj.put("taskTitle", r.taskTitle)
                            obj.put("category", r.category)
                            obj.put("taskDate", r.taskDate)
                            obj.put("taskTime", r.taskTime)
                            obj.put("reminder2Date", r.reminder2Date ?: JSONObject.NULL)
                            obj.put("reminder2Time", r.reminder2Time ?: JSONObject.NULL)
                            obj.put("reminder3Date", r.reminder3Date ?: JSONObject.NULL)
                            obj.put("reminder3Time", r.reminder3Time ?: JSONObject.NULL)
                            obj.put("isCompleted", r.isCompleted)
                            obj.put("location", r.location)
                            obj.put("amount", r.amount ?: JSONObject.NULL)
                            jsonArray.put(obj)
                        }
                        writer.write(jsonArray.toString(2))
                    }
                }
                Toast.makeText(context, "Data exported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    InputStreamReader(inputStream).use { reader ->
                        val jsonStr = reader.readText()
                        val jsonArray = JSONArray(jsonStr)
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.getJSONObject(i)
                            val reminder = Reminder(
                                taskTitle = obj.getString("taskTitle"),
                                category = obj.getString("category"),
                                taskDate = obj.getString("taskDate"),
                                taskTime = obj.getString("taskTime"),
                                reminder2Date = if (obj.isNull("reminder2Date")) null else obj.getString("reminder2Date"),
                                reminder2Time = if (obj.isNull("reminder2Time")) null else obj.getString("reminder2Time"),
                                reminder3Date = if (obj.isNull("reminder3Date")) null else obj.getString("reminder3Date"),
                                reminder3Time = if (obj.isNull("reminder3Time")) null else obj.getString("reminder3Time"),
                                isCompleted = obj.getBoolean("isCompleted"),
                                location = obj.optString("location", ""),
                                amount = if (obj.isNull("amount")) null else obj.getDouble("amount")
                            )
                            reminderViewModel.addReminder(reminder)
                        }
                    }
                }
                Toast.makeText(context, "Data imported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Import failed or invalid format", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Dark Mode", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = isDarkMode,
                    onCheckedChange = { settingsViewModel.setDarkMode(it) }
                )
            }

            HorizontalDivider()

            Text("Backup & Restore", style = MaterialTheme.typography.titleMedium)
            
            Button(
                onClick = { exportLauncher.launch("somnath_backup.json") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Export Data")
            }
            
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("application/json")) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Import Data")
            }
        }
    }
}
