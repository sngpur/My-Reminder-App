package com.example

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.content.ComponentName
import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlinx.coroutines.launch
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, settingsViewModel: SettingsViewModel, reminderViewModel: ReminderViewModel) {
    val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
    val isAutoBackupEnabled by settingsViewModel.isAutoBackupEnabled.collectAsStateWithLifecycle()
    val reminders by reminderViewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordInput by remember { mutableStateOf("") }
    var pendingAction by remember { mutableStateOf("") } // "backup" or "restore"
    var showSetBackupPasswordDialog by remember { mutableStateOf(false) }
    var newBackupPasswordInput by remember { mutableStateOf("") }
    var showRestartPromptDialog by remember { mutableStateOf(false) }
    
    val fullBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    FullBackupManager.performBackup(context, it, passwordInput)
                    Toast.makeText(context, "Full Backup Successful", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Backup Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    val fullRestoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    val success = FullBackupManager.performRestore(context, it, passwordInput)
                    if (success) {
                        showRestartPromptDialog = true
                    } else {
                        Toast.makeText(context, "Incorrect Backup Password", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Incorrect Backup Password", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        val jsonArray = JSONArray()
                        reminders.forEach { r ->
                            val obj = JSONObject()
                            obj.put("taskTitle", r.taskTitle)
                            obj.put("category", r.category)
                            obj.put("taskDate", r.taskDate)
                            obj.put("taskTime", r.taskTime)
                            obj.put("reminder2Date", r.reminder2Date ?: JSONObject.NULL)
                            obj.put("reminder2Time", r.reminder2Time ?: JSONObject.NULL)
                            obj.put("reminder3Date", r.reminder3Date ?: JSONObject.NULL)
                            obj.put("reminder3Time", r.reminder3Time ?: JSONObject.NULL)
                            obj.put("isCompleted", r.isCompleted)
                            obj.put("location", r.location)
                            obj.put("amount", r.amount ?: JSONObject.NULL)
                            jsonArray.put(obj)
                        }
                        writer.write(jsonArray.toString(2))
                    }
                }
                Toast.makeText(context, "Data exported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    InputStreamReader(inputStream).use { reader ->
                        val jsonStr = reader.readText()
                        val jsonArray = JSONArray(jsonStr)
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.getJSONObject(i)
                            val reminder = Reminder(
                                taskTitle = obj.getString("taskTitle"),
                                category = obj.getString("category"),
                                taskDate = obj.getString("taskDate"),
                                taskTime = obj.getString("taskTime"),
                                reminder2Date = if (obj.isNull("reminder2Date")) null else obj.getString("reminder2Date"),
                                reminder2Time = if (obj.isNull("reminder2Time")) null else obj.getString("reminder2Time"),
                                reminder3Date = if (obj.isNull("reminder3Date")) null else obj.getString("reminder3Date"),
                                reminder3Time = if (obj.isNull("reminder3Time")) null else obj.getString("reminder3Time"),
                                isCompleted = obj.getBoolean("isCompleted"),
                                location = obj.optString("location", ""),
                                amount = if (obj.isNull("amount")) null else obj.getDouble("amount")
                            )
                            reminderViewModel.addReminder(reminder)
                        }
                    }
                }
                Toast.makeText(context, "Data imported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Import failed or invalid format", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Dark Mode", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = isDarkMode,
                    onCheckedChange = { settingsViewModel.setDarkMode(it) }
                )
            }

            HorizontalDivider()

            Text("App Customization", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)

            val currentIconStyle by settingsViewModel.appIconStyle.collectAsStateWithLifecycle()
            var showIconDropdown by remember { mutableStateOf(false) }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showIconDropdown = true }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("App Icon Style", style = MaterialTheme.typography.titleMedium)
                    Text(currentIconStyle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    TextButton(onClick = { showIconDropdown = true }) {
                        Text("Change")
                    }
                    DropdownMenu(
                        expanded = showIconDropdown,
                        onDismissRequest = { showIconDropdown = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Default (Blue)") },
                            onClick = {
                                showIconDropdown = false
                                if (currentIconStyle != "Default (Blue)") {
                                    settingsViewModel.setAppIconStyle("Default (Blue)")
                                    changeAppIcon(context, "Default (Blue)")
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Dark Mode (Black/Grey)") },
                            onClick = {
                                showIconDropdown = false
                                if (currentIconStyle != "Dark Mode (Black/Grey)") {
                                    settingsViewModel.setAppIconStyle("Dark Mode (Black/Grey)")
                                    changeAppIcon(context, "Dark Mode (Black/Grey)")
                                }
                            }
                        )
                    }
                }
            }

            HorizontalDivider()

            Text("Notifications", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        try {
                            val intent = android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Cannot open settings: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Manage Alarm Sounds per Category", style = MaterialTheme.typography.titleMedium)
                    Text("Change ringtones for Birthdays, Tasks, and Finance", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            HorizontalDivider()

            Text("Automations", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)

            val isMorningBriefingEnabled by settingsViewModel.isMorningBriefingEnabled.collectAsStateWithLifecycle()

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Enable Morning Briefing", style = MaterialTheme.typography.titleMedium)
                    Text("Receive a daily overview at 7:00 AM", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = isMorningBriefingEnabled,
                    onCheckedChange = { settingsViewModel.setMorningBriefingEnabled(it) }
                )
            }

            OutlinedButton(
                onClick = {
                    try {
                        val intent = android.content.Intent(context, MorningBriefingActivity::class.java)
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(context, "Failed to test morning briefing: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Test Morning Briefing Now")
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Enable Auto-Backup (Weekly)", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = isAutoBackupEnabled,
                    onCheckedChange = { isChecked ->
                        if (isChecked) {
                            newBackupPasswordInput = ""
                            showSetBackupPasswordDialog = true
                        } else {
                            settingsViewModel.setAutoBackup(false)
                        }
                    }
                )
            }

            HorizontalDivider()

            Text("Full App Backup (Secure)", style = MaterialTheme.typography.titleMedium)
            
            Button(
                onClick = { 
                    pendingAction = "backup"
                    passwordInput = ""
                    showPasswordDialog = true 
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Backup All Data (.aes)")
            }
            
            OutlinedButton(
                onClick = { 
                    pendingAction = "restore"
                    passwordInput = ""
                    showPasswordDialog = true 
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Restore All Data (.aes)")
            }
            
            if (showPasswordDialog) {
                AlertDialog(
                    onDismissRequest = { showPasswordDialog = false },
                    title = { Text(if (pendingAction == "backup") "Secure Backup" else "Decrypt Backup") },
                    text = {
                        Column {
                            Text("Enter a password to encrypt/decrypt your backup.")
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text("Password") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            showPasswordDialog = false
                            if (passwordInput.isNotBlank()) {
                                if (pendingAction == "backup") {
                                    fullBackupLauncher.launch("MyBuddy_Backup.aes")
                                } else {
                                    fullRestoreLauncher.launch(arrayOf("*/*"))
                                }
                            }
                        }) {
                            Text("Confirm")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showPasswordDialog = false }) { Text("Cancel") }
                    }
                )
            }

            if (showSetBackupPasswordDialog) {
                AlertDialog(
                    onDismissRequest = {
                        showSetBackupPasswordDialog = false
                    },
                    title = { Text("Set a Backup Password") },
                    text = {
                        Column {
                            Text("Your backup contains secure vault data and must be encrypted. Please set a backup password:")
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newBackupPasswordInput,
                                onValueChange = { newBackupPasswordInput = it },
                                label = { Text("Password") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            if (newBackupPasswordInput.isNotBlank()) {
                                settingsViewModel.setBackupPassword(newBackupPasswordInput)
                                settingsViewModel.setAutoBackup(true)
                                showSetBackupPasswordDialog = false
                            } else {
                                Toast.makeText(context, "Password cannot be empty", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Text("Confirm")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            showSetBackupPasswordDialog = false
                        }) {
                            Text("Cancel")
                        }
                    }
                )
            }

            if (showRestartPromptDialog) {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Restore Successful") },
                    text = { Text("The database was successfully restored. Please restart the app to apply the changes.") },
                    confirmButton = {
                        Button(onClick = {
                            System.exit(0)
                        }) {
                            Text("Exit App")
                        }
                    }
                )
            }

        }
    }
}

private fun changeAppIcon(context: android.content.Context, style: String) {
    val pm = context.packageManager
    val defaultComponent = ComponentName(context, "${context.packageName}.AliasDefault")
    val darkComponent = ComponentName(context, "${context.packageName}.AliasDark")

    try {
        if (style == "Default (Blue)") {
            pm.setComponentEnabledSetting(
                defaultComponent,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            pm.setComponentEnabledSetting(
                darkComponent,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } else {
            pm.setComponentEnabledSetting(
                darkComponent,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            pm.setComponentEnabledSetting(
                defaultComponent,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        Toast.makeText(
            context,
            "App icon changed to $style! Please minimize the app to see the change on your home screen.",
            Toast.LENGTH_LONG
        ).show()
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Failed to change icon: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
