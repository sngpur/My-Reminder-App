package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MarkCompleteReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getIntExtra("id", 0)
        
        // Stop the alarm service if it's running
        val serviceIntent = Intent(context, AlarmService::class.java)
        context.stopService(serviceIntent)
        
        // Cancel the notification (both the standard and alarm ones just in case)
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        notificationManager.cancel(taskId)
        notificationManager.cancel(taskId + 10000)
        
        // Mark the task as complete in the DB
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
            try {
                val db = AppDatabase.getDatabase(context)
                val dao = db.reminderDao()
                dao.updateCompletionStatus(taskId, true)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
