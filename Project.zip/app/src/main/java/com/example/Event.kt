package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val eventType: String,
    val name: String,
    val relationship: String,
    val date: String,
    val time: String,
    val ringAlarm: Boolean
)
