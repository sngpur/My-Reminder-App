package com.example

import androidx.compose.runtime.Stable
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

@Entity(tableName = "events")
@Stable
data class Event(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val eventType: String,
    val name: String,
    val relationship: String,
    val date: String,
    val time: String,
    val ringAlarm: Boolean,
    val phoneNumber: String = "",
    val customMessage: String = ""
)

fun Event.calculateDaysLeft(today: LocalDate = LocalDate.now()): Long {
    val dateStr = this.date.trim()
    if (dateStr.isEmpty()) return Long.MAX_VALUE
    
    // Try parsing as "d MMM" or "d MMM yyyy" by appending current year if needed
    try {
        val formatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())
        val cleanDate = if (dateStr.matches(Regex(".*\\d{4}$"))) dateStr else "$dateStr ${today.year}"
        var eventDate = LocalDate.parse(cleanDate, formatter)
        if (eventDate.isBefore(today)) {
            eventDate = eventDate.plusYears(1)
        }
        return ChronoUnit.DAYS.between(today, eventDate)
    } catch (e: Exception) {
        // Fallback: Try standard ISO Local Date format (yyyy-MM-dd)
        try {
            val eventDateRaw = LocalDate.parse(dateStr)
            var eventDate = eventDateRaw.withYear(today.year)
            if (eventDate.isBefore(today)) {
                eventDate = eventDate.plusYears(1)
            }
            return ChronoUnit.DAYS.between(today, eventDate)
        } catch (e2: Exception) {
            return Long.MAX_VALUE
        }
    }
}

fun List<Event>.findNearest(eventType: String? = null, today: LocalDate = LocalDate.now()): Pair<Event, Long>? {
    val filtered = if (eventType != null) this.filter { it.eventType == eventType } else this
    if (filtered.isEmpty()) return null
    
    return filtered
        .map { event -> Pair(event, event.calculateDaysLeft(today)) }
        .filter { it.second != Long.MAX_VALUE }
        .minByOrNull { it.second }
}

