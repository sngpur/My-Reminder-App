package com.example

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import androidx.glance.material3.ColorProviders
import android.os.Build

class MyBuddyDashboardWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        // Fetch data
        val db = AppDatabase.getDatabase(context)
        
        val reminders = db.reminderDao().getAllReminders().first()
        val events = db.eventDao().getAllEvents().first()
        val carRecords = db.fuelRecordDao().getFuelRecords("Car").first()
        val bikeRecords = db.fuelRecordDao().getFuelRecords("Bike").first()
        
        // 1. Upcoming Task
        val upcomingTask = reminders
            .filter { !it.isCompleted }
            .sortedBy { 
                try {
                    LocalDateTime.of(LocalDate.parse(it.taskDate), LocalTime.parse(it.taskTime))
                } catch(e: Exception) {
                    LocalDateTime.MAX
                }
            }.firstOrNull()
            
        // 2. Finance Summary
        val totalPay = reminders.filter { it.category == "Upcoming Payment" && !it.isCompleted }.sumOf { it.amount ?: 0.0 }
        val totalLent = reminders.filter { it.category == "Money Lent (Udhar)" && !it.isCompleted }.sumOf { it.amount ?: 0.0 }
        
        // 3. Birthday & Anniversary
        val today = LocalDate.now()
        val upcomingBirthday = events.filter { it.eventType == "Birthday" }.minByOrNull {
            try {
                var nextDate = LocalDate.parse(it.date).withYear(today.year)
                if (nextDate.isBefore(today)) nextDate = nextDate.plusYears(1)
                ChronoUnit.DAYS.between(today, nextDate)
            } catch (e: Exception) {
                Long.MAX_VALUE
            }
        }
        val upcomingAnniversary = events.filter { it.eventType == "Anniversary" }.minByOrNull {
            try {
                var nextDate = LocalDate.parse(it.date).withYear(today.year)
                if (nextDate.isBefore(today)) nextDate = nextDate.plusYears(1)
                ChronoUnit.DAYS.between(today, nextDate)
            } catch (e: Exception) {
                Long.MAX_VALUE
            }
        }
        
        val bdayDaysLeft = upcomingBirthday?.let {
             try {
                var nextDate = LocalDate.parse(it.date).withYear(today.year)
                if (nextDate.isBefore(today)) nextDate = nextDate.plusYears(1)
                ChronoUnit.DAYS.between(today, nextDate)
            } catch (e: Exception) { -1L }
        }
        val annivDaysLeft = upcomingAnniversary?.let {
             try {
                var nextDate = LocalDate.parse(it.date).withYear(today.year)
                if (nextDate.isBefore(today)) nextDate = nextDate.plusYears(1)
                ChronoUnit.DAYS.between(today, nextDate)
            } catch (e: Exception) { -1L }
        }

        // 4. Mileage Tracker
        fun calcMileage(records: List<FuelRecord>): Double {
            if (records.size < 2) return 0.0
            val sorted = records.sortedBy { it.dateMillis }
            var totalKm = 0
            var totalLiters = 0.0
            for (i in 1 until sorted.size) {
                totalKm += (sorted[i].odometerKm - sorted[i-1].odometerKm)
                totalLiters += sorted[i-1].fuelLiters
            }
            return if (totalLiters > 0) totalKm / totalLiters else 0.0
        }
        val carMileage = calcMileage(carRecords)
        val bikeMileage = calcMileage(bikeRecords)

        provideContent {
            GlanceTheme {
                WidgetContent(
                    context = context,
                    upcomingTask = upcomingTask,
                    totalPay = totalPay,
                    totalLent = totalLent,
                    bdayInfo = if (upcomingBirthday != null) "${upcomingBirthday.name} ($bdayDaysLeft days)" else "None",
                    annivInfo = if (upcomingAnniversary != null) "${upcomingAnniversary.name} ($annivDaysLeft days)" else "None",
                    carMileage = String.format("%.1f", carMileage),
                    bikeMileage = String.format("%.1f", bikeMileage)
                )
            }
        }
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        MyBuddyDashboardWidget().update(context, glanceId)
    }
}

class ToggleTaskAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val taskId = parameters[ActionParameters.Key<Int>("taskId")]
        if (taskId != null) {
            val db = AppDatabase.getDatabase(context)
            val reminder = db.reminderDao().getReminderById(taskId)
            if (reminder != null) {
                db.reminderDao().updateCompletionStatus(taskId, !reminder.isCompleted)
                MyBuddyDashboardWidget().update(context, glanceId)
            }
        }
    }
}

@Composable
fun WidgetContent(
    context: Context,
    upcomingTask: Reminder?,
    totalPay: Double,
    totalLent: Double,
    bdayInfo: String,
    annivInfo: String,
    carMileage: String,
    bikeMileage: String
) {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(GlanceTheme.colors.background)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dashboard",
                style = TextStyle(
                    color = GlanceTheme.colors.onBackground,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = GlanceModifier.defaultWeight()
            )
            
            // Refresh Button
            Image(
                provider = ImageProvider(android.R.drawable.ic_popup_sync),
                contentDescription = "Refresh",
                modifier = GlanceModifier.clickable(onClick = actionRunCallback<RefreshAction>())
            )
            
            Spacer(modifier = GlanceModifier.width(16.dp))
            
            // Add Button (Launch MainActivity)
            Image(
                provider = ImageProvider(android.R.drawable.ic_menu_add),
                contentDescription = "Add Task",
                modifier = GlanceModifier.clickable(
                    onClick = actionStartActivity<MainActivity>()
                )
            )
        }
        
        Spacer(modifier = GlanceModifier.height(12.dp))
        
        // Upcoming Task Section
        Text(
            text = "Upcoming Task",
            style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        )
        if (upcomingTask != null) {
            Row(modifier = GlanceModifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                val toggleKey = ActionParameters.Key<Int>("taskId")
                Image(
                    provider = ImageProvider(android.R.drawable.checkbox_off_background),
                    contentDescription = "Complete",
                    modifier = GlanceModifier.clickable(
                        onClick = actionRunCallback<ToggleTaskAction>(actionParametersOf(toggleKey to upcomingTask.id))
                    )
                )
                Spacer(modifier = GlanceModifier.width(8.dp))
                Column {
                    Text(text = upcomingTask.taskTitle, style = TextStyle(color = GlanceTheme.colors.onBackground, fontSize = 14.sp))
                    Text(text = "${upcomingTask.taskDate} ${upcomingTask.taskTime}", style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 12.sp))
                }
            }
        } else {
            Text(text = "No upcoming tasks", style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 14.sp), modifier = GlanceModifier.padding(top = 4.dp))
        }
        
        Spacer(modifier = GlanceModifier.height(8.dp))
        
        // Finance & Bday Row
        Row(modifier = GlanceModifier.fillMaxWidth()) {
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(text = "Finance", style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 14.sp, fontWeight = FontWeight.Medium))
                Text(text = "Pay: $totalPay", style = TextStyle(color = GlanceTheme.colors.onBackground, fontSize = 12.sp))
                Text(text = "Lent: $totalLent", style = TextStyle(color = GlanceTheme.colors.onBackground, fontSize = 12.sp))
            }
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(text = "Events", style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 14.sp, fontWeight = FontWeight.Medium))
                Text(text = "Bday: $bdayInfo", style = TextStyle(color = GlanceTheme.colors.onBackground, fontSize = 12.sp))
                Text(text = "Anniv: $annivInfo", style = TextStyle(color = GlanceTheme.colors.onBackground, fontSize = 12.sp))
            }
        }
        
        Spacer(modifier = GlanceModifier.height(8.dp))
        
        // Mileage
        Text(text = "Mileage Tracker", style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 14.sp, fontWeight = FontWeight.Medium))
        Row(modifier = GlanceModifier.fillMaxWidth().padding(top = 4.dp)) {
            Text(text = "Car: $carMileage km/l", style = TextStyle(color = GlanceTheme.colors.onBackground, fontSize = 12.sp), modifier = GlanceModifier.defaultWeight())
            Text(text = "Bike: $bikeMileage km/l", style = TextStyle(color = GlanceTheme.colors.onBackground, fontSize = 12.sp), modifier = GlanceModifier.defaultWeight())
        }
    }
}
