package com.example

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.updateAll
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.CheckBox
import androidx.glance.background
import androidx.glance.unit.ColorProvider
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit

val taskIdKey = ActionParameters.Key<Int>("taskId")

class MyBuddyDashboardWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val db = AppDatabase.getDatabase(context)
        
        val reminders = db.reminderDao().getAllReminders().first()
        val events = db.eventDao().getAllEvents().first()
        val carRecords = db.fuelRecordDao().getFuelRecords("Car").first()
        val bikeRecords = db.fuelRecordDao().getFuelRecords("Bike").first()
        val carService = db.serviceRecordDao().getServiceRecord("Car").first()
        val bikeService = db.serviceRecordDao().getServiceRecord("Bike").first()
        
        // 1. Upcoming Task
        val upcomingTask = reminders
            .filter { !it.isCompleted }
            .sortedBy { 
                try {
                    LocalDateTime.of(LocalDate.parse(it.taskDate), LocalTime.parse(it.taskTime))
                } catch(e: Exception) {
                    LocalDateTime.MAX
                }
            }.firstOrNull()
            
        // 2. Finance Summary
        val totalPay = reminders.filter { it.category == "Upcoming Payment" && !it.isCompleted }.sumOf { it.amount ?: 0.0 }
        val totalLent = reminders.filter { it.category == "Money Lent (Udhar)" && !it.isCompleted }.sumOf { it.amount ?: 0.0 }
        
        // 3. Birthday & Anniversary
        val nearestBirthday = findNearestEvent(events, "Birthday")
        val nearestAnniversary = findNearestEvent(events, "Anniversary")
        
        // 4. Mileage Tracker
        val bikeMileage = calculateLatestMileage(bikeRecords)
        val carMileage = calculateLatestMileage(carRecords)

        val bikeServiceText = if (bikeService != null && bikeService.nextServiceDate != "Not set" && bikeService.nextServiceDate.isNotEmpty()) {
            bikeService.nextServiceDate to "Next service"
        } else if (bikeMileage != null) {
            "${String.format(java.util.Locale.US, "%.1f", bikeMileage)} km/l" to "Last refuel"
        } else {
            "Add details" to "No info"
        }

        val carServiceText = if (carService != null && carService.nextServiceDate != "Not set" && carService.nextServiceDate.isNotEmpty()) {
            carService.nextServiceDate to "Next service"
        } else if (carMileage != null) {
            "${String.format(java.util.Locale.US, "%.1f", carMileage)} km/l" to "Last refuel"
        } else {
            "Add details" to "No info"
        }

        val bikeMileageVal = calculateAverageMileage(bikeRecords)
        val carMileageVal = calculateAverageMileage(carRecords)

        val bikeMileageText = if (bikeMileageVal != null) {
            String.format(java.util.Locale.getDefault(), "%.1f km/l", bikeMileageVal)
        } else {
            "0.0 km/l"
        }

        val carMileageText = if (carMileageVal != null) {
            String.format(java.util.Locale.getDefault(), "%.1f km/l", carMileageVal)
        } else {
            "0.0 km/l"
        }

        provideContent {
            GlanceTheme {
                WidgetContent(
                    context = context,
                    upcomingTask = upcomingTask,
                    totalPay = totalPay,
                    totalLent = totalLent,
                    nearestBirthday = nearestBirthday,
                    nearestAnniversary = nearestAnniversary,
                    bikeServiceText = bikeServiceText,
                    carServiceText = carServiceText,
                    bikeMileageText = bikeMileageText,
                    carMileageText = carMileageText
                )
            }
        }
    }

    private fun findNearestEvent(events: List<Event>, eventType: String): Pair<Event, Long>? {
        return events.findNearest(eventType)
    }

    private fun calculateLatestMileage(records: List<FuelRecord>): Double? {
        val sorted = records.sortedByDescending { it.dateMillis }
        if (sorted.size >= 2) {
            val latest = sorted[0]
            val previous = sorted[1]
            val distance = latest.odometerKm - previous.odometerKm
            if (distance > 0 && latest.fuelLiters > 0) {
                return distance / latest.fuelLiters
            }
        }
        return null
    }

    private fun calculateAverageMileage(records: List<FuelRecord>): Double? {
        if (records.size < 2) return null
        val sorted = records.sortedBy { it.odometerKm }
        val distance = (sorted.last().odometerKm - sorted.first().odometerKm).toDouble()
        val fuel = sorted.dropLast(1).sumOf { it.fuelLiters }
        return if (fuel == 0.0) null else distance / fuel
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        MyBuddyDashboardWidget().update(context, glanceId)
    }
}

class CompleteTaskAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val id = parameters[taskIdKey] ?: return
        val db = AppDatabase.getDatabase(context)
        db.reminderDao().updateCompletionStatus(id, true)
        MyBuddyDashboardWidget().updateAll(context)
    }
}

@Composable
fun WidgetContent(
    context: Context,
    upcomingTask: Reminder?,
    totalPay: Double,
    totalLent: Double,
    nearestBirthday: Pair<Event, Long>?,
    nearestAnniversary: Pair<Event, Long>?,
    bikeServiceText: Pair<String, String>,
    carServiceText: Pair<String, String>,
    bikeMileageText: String,
    carMileageText: String
) {
    val routeKey = ActionParameters.Key<String>("route")

    val quickAddIntent = Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        putExtra("OPEN_QUICK_ADD", true)
    }

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(GlanceTheme.colors.background)
            .padding(12.dp)
    ) {
        // Header
        Row(
            modifier = GlanceModifier.fillMaxWidth().padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dashboard",
                style = TextStyle(
                    color = GlanceTheme.colors.onBackground,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = GlanceModifier.defaultWeight()
            )
            
            // Refresh Button
            Image(
                provider = ImageProvider(android.R.drawable.ic_popup_sync),
                contentDescription = "Refresh",
                modifier = GlanceModifier.clickable(onClick = actionRunCallback<RefreshAction>())
            )
            
            Spacer(modifier = GlanceModifier.width(16.dp))
            
            // Add Button (Launch MainActivity with Quick Add)
            Image(
                provider = ImageProvider(android.R.drawable.ic_menu_add),
                contentDescription = "Add Task",
                modifier = GlanceModifier.clickable(
                    onClick = androidx.glance.appwidget.action.actionStartActivity(quickAddIntent)
                )
            )
        }
        
        // 3x2 Grid using Row & Column
        Column(
            modifier = GlanceModifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Row 1: Upcoming Task | Finance
            Row(
                modifier = GlanceModifier.fillMaxWidth().defaultWeight().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Card 1: Upcoming Task (Cyan: 0xFFE0F7FA)
                Column(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .fillMaxHeight()
                        .background(ColorProvider(Color(0xFFE0F7FA)))
                        .cornerRadius(16.dp)
                        .padding(8.dp)
                        .clickable(actionStartActivity<MainActivity>(actionParametersOf(routeKey to "home"))),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "UPCOMING",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFF006064)),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = GlanceModifier.height(4.dp))
                    if (upcomingTask != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = GlanceModifier.fillMaxWidth()
                        ) {
                            CheckBox(
                                checked = false,
                                onCheckedChange = actionRunCallback<CompleteTaskAction>(
                                    actionParametersOf(taskIdKey to upcomingTask.id)
                                ),
                                modifier = GlanceModifier.padding(end = 4.dp)
                            )
                            Column(modifier = GlanceModifier.defaultWeight()) {
                                Text(
                                    text = upcomingTask.taskTitle,
                                    style = TextStyle(
                                        color = ColorProvider(Color(0xFF1C1B1F)),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    maxLines = 1
                                )
                                Text(
                                    text = "${upcomingTask.taskDate} • ${upcomingTask.taskTime}",
                                    style = TextStyle(
                                        color = ColorProvider(Color(0xFF49454F)),
                                        fontSize = 10.sp
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "No pending task",
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF757575)),
                                fontSize = 11.sp
                            )
                        )
                    }
                }
                
                Spacer(modifier = GlanceModifier.width(8.dp))
                
                // Card 2: Finance (Pastel Blue: 0xFFD2E3FC)
                Column(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .fillMaxHeight()
                        .background(ColorProvider(Color(0xFFD2E3FC)))
                        .cornerRadius(16.dp)
                        .padding(8.dp)
                        .clickable(actionStartActivity<MainActivity>(actionParametersOf(routeKey to "monthly_summary"))),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "FINANCE",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFF0D47A1)),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = GlanceModifier.height(4.dp))
                    Text(
                        text = "Pay: ₹${totalPay.toInt()}",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFF1C1B1F)),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "Lent: ₹${totalLent.toInt()}",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFF2E7D32)),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
            
            // Row 2: Birthday | Anniversary
            Row(
                modifier = GlanceModifier.fillMaxWidth().defaultWeight().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Card 3: Birthday (Pink: 0xFFFCE4EC)
                Column(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .fillMaxHeight()
                        .background(ColorProvider(Color(0xFFFCE4EC)))
                        .cornerRadius(16.dp)
                        .padding(8.dp)
                        .clickable(actionStartActivity<MainActivity>(actionParametersOf(routeKey to "birthday_anniversary"))),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "BIRTHDAY",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFC2185B)),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = GlanceModifier.height(4.dp))
                    if (nearestBirthday != null) {
                        Text(
                            text = nearestBirthday.first.name,
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF1C1B1F)),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "${nearestBirthday.first.date} (${nearestBirthday.second}d)",
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF49454F)),
                                fontSize = 10.sp
                            ),
                            maxLines = 1
                        )
                    } else {
                        Text(
                            text = "No upcoming",
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF757575)),
                                fontSize = 11.sp
                            )
                        )
                    }
                }
                
                Spacer(modifier = GlanceModifier.width(8.dp))
                
                // Card 4: Anniversary (Peach: 0xFFFFF3E0)
                Column(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .fillMaxHeight()
                        .background(ColorProvider(Color(0xFFFFF3E0)))
                        .cornerRadius(16.dp)
                        .padding(8.dp)
                        .clickable(actionStartActivity<MainActivity>(actionParametersOf(routeKey to "birthday_anniversary"))),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "ANNIVERSARY",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFE65100)),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = GlanceModifier.height(4.dp))
                    if (nearestAnniversary != null) {
                        Text(
                            text = nearestAnniversary.first.name,
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF1C1B1F)),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "${nearestAnniversary.first.date} (${nearestAnniversary.second}d)",
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF49454F)),
                                fontSize = 10.sp
                            ),
                            maxLines = 1
                        )
                    } else {
                        Text(
                            text = "No upcoming",
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF757575)),
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
            
            // Row 3: Bike | Car
            Row(
                modifier = GlanceModifier.fillMaxWidth().defaultWeight().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Card 5: Bike (Green: 0xFFE8F5E9)
                Column(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .fillMaxHeight()
                        .background(ColorProvider(Color(0xFFE8F5E9)))
                        .cornerRadius(16.dp)
                        .padding(8.dp)
                        .clickable(actionStartActivity<MainActivity>(actionParametersOf(routeKey to "milage_calculator"))),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.Start
                ) {
                    Row(
                        modifier = GlanceModifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = GlanceModifier.defaultWeight(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalAlignment = Alignment.Start
                        ) {
                            Text(
                                text = "BIKE",
                                style = TextStyle(
                                    color = ColorProvider(Color(0xFF2E7D32)),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = GlanceModifier.height(4.dp))
                            Text(
                                text = bikeServiceText.first,
                                style = TextStyle(
                                    color = ColorProvider(Color(0xFF1C1B1F)),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                maxLines = 1
                            )
                            Text(
                                text = bikeServiceText.second,
                                style = TextStyle(
                                    color = ColorProvider(Color(0xFF49454F)),
                                    fontSize = 10.sp
                                ),
                                maxLines = 1
                            )
                        }
                        Spacer(modifier = GlanceModifier.width(4.dp))
                        Text(
                            text = bikeMileageText,
                            style = TextStyle(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = ColorProvider(Color.Black)
                            )
                        )
                    }
                }
                
                Spacer(modifier = GlanceModifier.width(8.dp))
                
                // Card 6: Car (Lavender: 0xFFF3E5F5)
                Column(
                    modifier = GlanceModifier
                        .defaultWeight()
                        .fillMaxHeight()
                        .background(ColorProvider(Color(0xFFF3E5F5)))
                        .cornerRadius(16.dp)
                        .padding(8.dp)
                        .clickable(actionStartActivity<MainActivity>(actionParametersOf(routeKey to "milage_calculator"))),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.Start
                ) {
                    Row(
                        modifier = GlanceModifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = GlanceModifier.defaultWeight(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalAlignment = Alignment.Start
                        ) {
                            Text(
                                text = "CAR",
                                style = TextStyle(
                                    color = ColorProvider(Color(0xFF6A1B9A)),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = GlanceModifier.height(4.dp))
                            Text(
                                text = carServiceText.first,
                                style = TextStyle(
                                    color = ColorProvider(Color(0xFF1C1B1F)),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                maxLines = 1
                            )
                            Text(
                                text = carServiceText.second,
                                style = TextStyle(
                                    color = ColorProvider(Color(0xFF49454F)),
                                    fontSize = 10.sp
                                ),
                                maxLines = 1
                            )
                        }
                        Spacer(modifier = GlanceModifier.width(4.dp))
                        Text(
                            text = carMileageText,
                            style = TextStyle(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = ColorProvider(Color.Black)
                            )
                        )
                    }
                }
            }
        }
    }
}
