package com.example
import androidx.lifecycle.compose.collectAsStateWithLifecycle

import android.content.Intent
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import android.app.NotificationManager
import android.app.Application

class NotificationDetailsViewModel(
    val application: Application,
    val entityId: Int,
    val entityType: String
) : ViewModel() {

    private val db = AppDatabase.getDatabase(application)
    private val reminderDao = db.reminderDao()
    private val eventDao = db.eventDao()
    private val serviceRecordDao = db.serviceRecordDao()

    private val _itemTitle = MutableStateFlow("")
    val itemTitle = _itemTitle.asStateFlow()

    private val _itemDesc = MutableStateFlow("")
    val itemDesc = _itemDesc.asStateFlow()

    init {
        fetchDetails()
    }

    private fun fetchDetails() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            when (entityType) {
                "Task" -> {
                    val reminder = reminderDao.getReminderById(entityId)
                    _itemTitle.value = reminder?.taskTitle ?: "Unknown Task"
                    _itemDesc.value = reminder?.category ?: ""
                }
                "Birthday", "Anniversary" -> {
                    val event = eventDao.getEventById(entityId)
                    _itemTitle.value = "${event?.name}'s $entityType"
                    _itemDesc.value = "Date: ${event?.date}"
                }
                "Vehicle" -> {
                    // Vehicle service uses record ID
                    // Wait, we don't have getServiceRecordById yet, we'll need to fetch all or add getById
                    val record = serviceRecordDao.getServiceRecordById(entityId)
                    _itemTitle.value = "${record?.vehicleType} Servicing Due"
                    _itemDesc.value = "Scheduled for: ${record?.nextServiceDate}"
                }
            }
        }
    }

    fun markTaskComplete(onDone: () -> Unit) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            reminderDao.updateCompletionStatus(entityId, true)
            onDone()
        }
    }

    fun markServiceDone(onDone: () -> Unit) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val record = serviceRecordDao.getServiceRecordById(entityId)
            if (record != null) {
                serviceRecordDao.deleteServiceRecord(record)
            }
            onDone()
        }
    }
}

class NotificationDetailsViewModelFactory(
    private val application: Application,
    private val entityId: Int,
    private val entityType: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return NotificationDetailsViewModel(application, entityId, entityType) as T
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationDetailsScreen(
    navController: androidx.navigation.NavController,
    entityId: Int,
    entityType: String,
    initialIsAlarmRinging: Boolean
) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    
    val viewModel: NotificationDetailsViewModel = viewModel(
        factory = NotificationDetailsViewModelFactory(application, entityId, entityType)
    )

    val title by viewModel.itemTitle.collectAsStateWithLifecycle()
    val desc by viewModel.itemDesc.collectAsStateWithLifecycle()
    
    var isAlarmRinging by remember { mutableStateOf(initialIsAlarmRinging) }

    val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun stopAlarm() {
        if (entityType == "Task") {
            context.stopService(Intent(context, AlarmService::class.java))
        } else if (entityType == "Birthday" || entityType == "Anniversary") {
            context.stopService(Intent(context, BirthdayAlarmService::class.java))
        }
        isAlarmRinging = false
    }

    fun cancelNotification() {
        when (entityType) {
            "Task" -> {
                notificationManager.cancel(entityId)
                notificationManager.cancel(entityId + 10000)
            }
            "Birthday", "Anniversary" -> notificationManager.cancel(entityId + 30000)
            "Vehicle" -> notificationManager.cancel(entityId + 100000)
            else -> notificationManager.cancel(entityId)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notification Details") },
                actions = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = desc, style = MaterialTheme.typography.bodyLarge)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            if (isAlarmRinging) {
                Button(
                    onClick = { stopAlarm() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Turn Off Alarm")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            when (entityType) {
                "Task" -> {
                    Button(
                        onClick = {
                            stopAlarm()
                            viewModel.markTaskComplete {
                                cancelNotification()
                                navController.popBackStack()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Mark Complete")
                    }
                }
                "Birthday", "Anniversary" -> {
                    Button(
                        onClick = {
                            stopAlarm()
                            val msg = if (entityType == "Birthday") "Happy Birthday 🎂🎈" else "Happy Anniversary 🎉"
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, msg)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Send wishes via"))
                            cancelNotification()
                            navController.popBackStack()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Send Wishes")
                    }
                }
                "Vehicle" -> {
                    Button(
                        onClick = {
                            viewModel.markServiceDone {
                                cancelNotification()
                                navController.popBackStack()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Service Done")
                    }
                }
            }
        }
    }
}
