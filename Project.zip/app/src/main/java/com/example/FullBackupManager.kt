package com.example

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object FullBackupManager {

    private fun generateKey(password: String): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256")
        val key = digest.digest(password.toByteArray(Charsets.UTF_8))
        return SecretKeySpec(key, "AES")
    }

    suspend fun performBackup(context: Context, outputUri: Uri, password: String) {
        withContext(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(context)
            // Force checkpointing so all Write-Ahead Log (WAL) data is fully committed to main database file
            try {
                db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val dbFile = context.getDatabasePath("somnath_reminder_db")
            val dbBytes = if (dbFile.exists()) {
                dbFile.readBytes()
            } else {
                ByteArray(0)
            }

            val secretKey = generateKey(password)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val iv = ByteArray(12)
            SecureRandom().nextBytes(iv)
            val gcmSpec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec)

            val encryptedBytes = cipher.doFinal(dbBytes)

            context.contentResolver.openOutputStream(outputUri)?.use { os ->
                os.write(iv)
                os.write(encryptedBytes)
            }
        }
    }

    suspend fun performRestore(context: Context, inputUri: Uri, password: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val secretKey = generateKey(password)
                val inputStream = context.contentResolver.openInputStream(inputUri) ?: return@withContext false
                val bytes = inputStream.readBytes()
                inputStream.close()

                if (bytes.size < 12) {
                    return@withContext false
                }

                val iv = bytes.copyOfRange(0, 12)
                val encryptedBytes = bytes.copyOfRange(12, bytes.size)

                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                val gcmSpec = GCMParameterSpec(128, iv)
                cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)

                val decryptedBytes = cipher.doFinal(encryptedBytes)

                // Close existing database instance and release file locks
                AppDatabase.closeDatabase()

                val dbFile = context.getDatabasePath("somnath_reminder_db")
                val walFile = File(dbFile.path + "-wal")
                val shmFile = File(dbFile.path + "-shm")

                if (dbFile.exists()) dbFile.delete()
                if (walFile.exists()) walFile.delete()
                if (shmFile.exists()) shmFile.delete()

                dbFile.parentFile?.mkdirs()
                dbFile.writeBytes(decryptedBytes)

                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
}
