package com.example

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.spec.SecretKeySpec

object FullBackupManager {

    private fun generateKey(password: String): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256")
        val key = digest.digest(password.toByteArray(Charsets.UTF_8))
        return SecretKeySpec(key, "AES")
    }

    suspend fun performBackup(context: Context, outputUri: Uri, password: String) {
        withContext(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(context)
            val gson = Gson()
            
            // Gather all data
            val backupData = mapOf(
                "reminders" to db.reminderDao().getAllReminders().first(),
                "events" to db.eventDao().getAllEvents().first(),
                "fuel_records" to db.fuelRecordDao().getAllFuelRecords().first(),
                "service_records" to db.serviceRecordDao().getAllServiceRecords().first(),
                "notes" to db.noteDao().getAllNotes().first(),
                "scanned_texts" to db.scannedTextDao().getAllScannedTexts().first(),
                "scanned_docs" to db.scannedDocDao().getAllScannedDocs().first(),
                "qr_records" to db.qrRecordDao().getAllQrRecords().first(),
                "vault_records" to db.vaultRecordDao().getAllVaultRecords().first()
            )
            
            val jsonString = gson.toJson(backupData)
            val tempDir = File(context.cacheDir, "backup_temp")
            if (!tempDir.exists()) tempDir.mkdirs()
            
            val jsonFile = File(tempDir, "app_data.json")
            jsonFile.writeText(jsonString)
            
            val zipFile = File(tempDir, "backup.zip")
            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                zos.putNextEntry(ZipEntry("app_data.json"))
                jsonFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
                
                val filesDir = context.filesDir
                filesDir.walkTopDown().filter { it.isFile && it != jsonFile && it != zipFile }.forEach { file ->
                    val entryName = "files/" + file.toRelativeString(filesDir)
                    zos.putNextEntry(ZipEntry(entryName))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            
            val secretKey = generateKey(password)
            val cipher = Cipher.getInstance("AES")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            
            context.contentResolver.openOutputStream(outputUri)?.use { os ->
                CipherOutputStream(os, cipher).use { cos ->
                    FileInputStream(zipFile).use { fis ->
                        fis.copyTo(cos)
                    }
                }
            }
            
            jsonFile.delete()
            zipFile.delete()
        }
    }
    
    suspend fun performRestore(context: Context, inputUri: Uri, password: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val tempDir = File(context.cacheDir, "restore_temp")
                if (!tempDir.exists()) tempDir.mkdirs()
                
                val secretKey = generateKey(password)
                val cipher = Cipher.getInstance("AES")
                cipher.init(Cipher.DECRYPT_MODE, secretKey)
                
                val zipFile = File(tempDir, "restore.zip")
                context.contentResolver.openInputStream(inputUri)?.use { inputStream ->
                    CipherInputStream(inputStream, cipher).use { cis ->
                        FileOutputStream(zipFile).use { fos ->
                            cis.copyTo(fos)
                        }
                    }
                }
                
                var jsonString = ""
                ZipInputStream(FileInputStream(zipFile)).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (entry.name == "app_data.json") {
                            jsonString = zis.bufferedReader().readText()
                        } else if (entry.name.startsWith("files/")) {
                            val relPath = entry.name.removePrefix("files/")
                            val targetFile = File(context.filesDir, relPath)
                            targetFile.parentFile?.mkdirs()
                            FileOutputStream(targetFile).use { fos ->
                                zis.copyTo(fos)
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
                
                if (jsonString.isNotEmpty()) {
                    val db = AppDatabase.getDatabase(context)
                    val gson = Gson()
                    
                    val mapType = object : com.google.gson.reflect.TypeToken<Map<String, com.google.gson.JsonElement>>() {}.type
                    val backupData: Map<String, com.google.gson.JsonElement> = gson.fromJson(jsonString, mapType)
                    
                    if (backupData.containsKey("reminders")) {
                        val items: List<Reminder> = gson.fromJson(backupData["reminders"], object : com.google.gson.reflect.TypeToken<List<Reminder>>() {}.type)
                        items.forEach { db.reminderDao().insertReminder(it) }
                    }
                    if (backupData.containsKey("events")) {
                        val items: List<Event> = gson.fromJson(backupData["events"], object : com.google.gson.reflect.TypeToken<List<Event>>() {}.type)
                        items.forEach { 
                            val newId = db.eventDao().insertEvent(it)
                            AlarmScheduler.scheduleEventAlarm(context, it.copy(id = newId.toInt()))
                        }
                    }
                    if (backupData.containsKey("fuel_records")) {
                        val items: List<FuelRecord> = gson.fromJson(backupData["fuel_records"], object : com.google.gson.reflect.TypeToken<List<FuelRecord>>() {}.type)
                        items.forEach { db.fuelRecordDao().insertFuelRecord(it) }
                    }
                    if (backupData.containsKey("service_records")) {
                        val items: List<ServiceRecord> = gson.fromJson(backupData["service_records"], object : com.google.gson.reflect.TypeToken<List<ServiceRecord>>() {}.type)
                        items.forEach { db.serviceRecordDao().insertServiceRecord(it) }
                    }
                    if (backupData.containsKey("notes")) {
                        val items: List<Note> = gson.fromJson(backupData["notes"], object : com.google.gson.reflect.TypeToken<List<Note>>() {}.type)
                        items.forEach { db.noteDao().insertNote(it) }
                    }
                    if (backupData.containsKey("scanned_texts")) {
                        val items: List<ScannedText> = gson.fromJson(backupData["scanned_texts"], object : com.google.gson.reflect.TypeToken<List<ScannedText>>() {}.type)
                        items.forEach { db.scannedTextDao().insertScannedText(it) }
                    }
                    if (backupData.containsKey("scanned_docs")) {
                        val items: List<ScannedDoc> = gson.fromJson(backupData["scanned_docs"], object : com.google.gson.reflect.TypeToken<List<ScannedDoc>>() {}.type)
                        items.forEach { db.scannedDocDao().insertScannedDoc(it) }
                    }
                    if (backupData.containsKey("qr_records")) {
                        val items: List<QrRecord> = gson.fromJson(backupData["qr_records"], object : com.google.gson.reflect.TypeToken<List<QrRecord>>() {}.type)
                        items.forEach { db.qrRecordDao().insertQrRecord(it) }
                    }
                    if (backupData.containsKey("vault_records")) {
                        val items: List<VaultRecord> = gson.fromJson(backupData["vault_records"], object : com.google.gson.reflect.TypeToken<List<VaultRecord>>() {}.type)
                        items.forEach { db.vaultRecordDao().insertVaultRecord(it) }
                    }
                }
                
                zipFile.delete()
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
}
