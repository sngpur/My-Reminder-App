package com.example

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScannedDocDao {
    @Query("SELECT * FROM scanned_docs ORDER BY dateMillis DESC")
    fun getAllScannedDocs(): Flow<List<ScannedDoc>>

    @Insert
    suspend fun insertScannedDoc(doc: ScannedDoc)

    @Delete
    suspend fun deleteScannedDoc(doc: ScannedDoc)
}
