package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.foundation.background
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlySummaryScreen(navController: NavController, viewModel: ReminderViewModel) {
    val reminders by viewModel.uiState.collectAsStateWithLifecycle()
    
    var totalPayments = 0.0
    var totalLent = 0.0
    
    reminders.forEach { r ->
        if (r.amount != null) {
            if (r.category == "Upcoming Payment") totalPayments += r.amount
            else if (r.category == "Money Lent (Udhar)") totalLent += r.amount
        }
    }

    val pastMonthsSummary = reminders.filter { it.amount != null && (it.category == "Upcoming Payment" || it.category == "Money Lent (Udhar)") }
        .groupBy { YearMonth.from(LocalDate.parse(it.taskDate)) }
        .mapValues { (_, tasks) ->
            var payments = 0.0
            var lent = 0.0
            tasks.forEach { t ->
                if (t.category == "Upcoming Payment") payments += t.amount ?: 0.0
                if (t.category == "Money Lent (Udhar)") lent += t.amount ?: 0.0
            }
            Pair(payments, lent)
        }.toList().sortedByDescending { it.first }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Finance Summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(
                        onClick = { navController.navigateUp() },
                        modifier = Modifier.padding(start = 8.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.5f), shape = androidx.compose.foundation.shape.CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("TOTAL PAYMENTS", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE57373))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("₹${totalPayments.toInt()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("TOTAL LENT (UDHAR)", style = MaterialTheme.typography.labelSmall, color = Color(0xFF81C784))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("₹${totalLent.toInt()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            
            item {
                Text("MONTHLY BREAKDOWN", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 16.dp), letterSpacing = 1.sp)
            }
            
            items(pastMonthsSummary) { (month, data) ->
                val monthName = month.month.name.lowercase().replaceFirstChar { it.uppercase() }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("$monthName ${month.year}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Payments: ₹${data.first.toInt()}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFE57373))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Lent: ₹${data.second.toInt()}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF81C784))
                        }
                    }
                }
            }
        }
    }
}
