package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import java.time.LocalDate
import java.time.YearMonth
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlySummaryScreen(navController: NavController, viewModel: ReminderViewModel) {
    val reminders by viewModel.uiState.collectAsStateWithLifecycle()
    val currentMonthPay by viewModel.currentMonthPay.collectAsStateWithLifecycle()
    val currentMonthLent by viewModel.currentMonthLent.collectAsStateWithLifecycle()
    
    // Strict filter: Only sum the amounts of tasks where isCompleted == false and isDeleted == false
    val activeReminders = reminders.filter { !it.isCompleted && !it.isDeleted }
    
    var totalPayments = 0.0
    var totalLent = 0.0
    
    activeReminders.forEach { r ->
        if (r.amount != null) {
            if (r.category == "Upcoming Payment") totalPayments += r.amount
            else if (r.category == "Money Lent (Udhar)") totalLent += r.amount
        }
    }

    val pastMonthsSummary = activeReminders.filter { it.amount != null && (it.category == "Upcoming Payment" || it.category == "Money Lent (Udhar)") }
        .groupBy { YearMonth.from(LocalDate.parse(it.taskDate)) }
        .mapValues { (_, tasks) ->
            var payments = 0.0
            var lent = 0.0
            tasks.forEach { t ->
                if (t.category == "Upcoming Payment") payments += t.amount ?: 0.0
                if (t.category == "Money Lent (Udhar)") lent += t.amount ?: 0.0
            }
            Pair(payments, lent)
        }.toList().sortedBy { it.first }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Finance Summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(
                        onClick = { navController.navigateUp() },
                        modifier = Modifier.padding(start = 8.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.5f), shape = androidx.compose.foundation.shape.CircleShape)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            item {
                val totalAmount = totalPayments + totalLent
                val paySweep = if (totalAmount == 0.0) 0f else (totalPayments / totalAmount * 360).toFloat()
                val lentSweep = if (totalAmount == 0.0) 0f else (totalLent / totalAmount * 360).toFloat()
                
                val monthlyAmount = currentMonthPay + currentMonthLent
                val monthlyPaySweep = if (monthlyAmount == 0.0) 0f else (currentMonthPay / monthlyAmount * 360).toFloat()
                val monthlyLentSweep = if (monthlyAmount == 0.0) 0f else (currentMonthLent / monthlyAmount * 360).toFloat()
                
                val animationProgress = remember { Animatable(0f) }
                LaunchedEffect(totalAmount, monthlyAmount) {
                    animationProgress.animateTo(1f, animationSpec = tween(durationMillis = 1500))
                }

                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Monthly Distribution
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("MONTHLY DISTRIBUTION", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                Box(modifier = Modifier.size(110.dp), contentAlignment = Alignment.Center) {
                                    if (monthlyAmount == 0.0) {
                                        Text("No Data", style = MaterialTheme.typography.labelSmall)
                                    }
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val strokeWidth = 22.dp.toPx()
                                        val diameter = size.minDimension - strokeWidth
                                        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
                                        val canvasSize = Size(diameter, diameter)
                                        
                                        if (monthlyAmount > 0.0) {
                                            drawArc(
                                                color = Color(0xFFE57373),
                                                startAngle = -90f,
                                                sweepAngle = monthlyPaySweep * animationProgress.value,
                                                useCenter = false,
                                                topLeft = topLeft,
                                                size = canvasSize,
                                                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                            )
                                            drawArc(
                                                color = Color(0xFF81C784),
                                                startAngle = -90f + monthlyPaySweep * animationProgress.value,
                                                sweepAngle = monthlyLentSweep * animationProgress.value,
                                                useCenter = false,
                                                topLeft = topLeft,
                                                size = canvasSize,
                                                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                            )
                                        }
                                    }
                                }
                            }

                            // Overall Distribution
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("OVERALL DISTRIBUTION", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                Box(modifier = Modifier.size(110.dp), contentAlignment = Alignment.Center) {
                                    if (totalAmount == 0.0) {
                                        Text("No Data", style = MaterialTheme.typography.labelSmall)
                                    }
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val strokeWidth = 22.dp.toPx()
                                        val diameter = size.minDimension - strokeWidth
                                        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
                                        val canvasSize = Size(diameter, diameter)
                                        
                                        if (totalAmount > 0.0) {
                                            drawArc(
                                                color = Color(0xFFE57373),
                                                startAngle = -90f,
                                                sweepAngle = paySweep * animationProgress.value,
                                                useCenter = false,
                                                topLeft = topLeft,
                                                size = canvasSize,
                                                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                            )
                                            drawArc(
                                                color = Color(0xFF81C784),
                                                startAngle = -90f + paySweep * animationProgress.value,
                                                sweepAngle = lentSweep * animationProgress.value,
                                                useCenter = false,
                                                topLeft = topLeft,
                                                size = canvasSize,
                                                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(12.dp).background(Color(0xFFE57373), androidx.compose.foundation.shape.CircleShape))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Pay", style = MaterialTheme.typography.bodySmall)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(12.dp).background(Color(0xFF81C784), androidx.compose.foundation.shape.CircleShape))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Lent", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("MONTHLY PAYMENTS", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE57373))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("₹${currentMonthPay.toInt()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("MONTHLY LENT (UDHAR)", style = MaterialTheme.typography.labelSmall, color = Color(0xFF81C784))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("₹${currentMonthLent.toInt()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("TOTAL PAYMENTS", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE57373))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("₹${totalPayments.toInt()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("TOTAL LENT (UDHAR)", style = MaterialTheme.typography.labelSmall, color = Color(0xFF81C784))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("₹${totalLent.toInt()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            
            item {
                Text("ACTIVE PENDING TRANSACTIONS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 16.dp), letterSpacing = 1.sp)
            }
            
            val pendingFinanceTasks = activeReminders.filter {
                it.category == "Upcoming Payment" || it.category == "Money Lent (Udhar)"
            }.sortedBy { it.taskDate }

            if (pendingFinanceTasks.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("No pending payments or lent items!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(pendingFinanceTasks, key = { "pending_${it.id}" }) { task ->
                    val isUpcomingPayment = task.category == "Upcoming Payment"
                    val iconColor = if (isUpcomingPayment) Color(0xFFE57373) else Color(0xFF81C784)
                    val iconBg = iconColor.copy(alpha = 0.15f)
                    
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                navController.navigate("edit_reminder/${task.id}")
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Checkbox(
                                    checked = task.isCompleted,
                                    onCheckedChange = { isChecked ->
                                        viewModel.toggleCompletion(task.id, isChecked)
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(task.taskTitle, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = iconBg,
                                            shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = if (isUpcomingPayment) "PAYMENT" else "LENT",
                                                color = iconColor,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(task.taskDate, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                "₹${task.amount?.toInt() ?: 0}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = iconColor
                            )
                        }
                    }
                }
            }

            item {
                Text("MONTHLY BREAKDOWN", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 16.dp), letterSpacing = 1.sp)
            }
            
            items(pastMonthsSummary, key = { it.first }, contentType = { "summary" }) { (month, data) ->
                val monthName = month.month.name.lowercase().replaceFirstChar { it.uppercase() }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("$monthName ${month.year}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Payments: ₹${data.first.toInt()}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFE57373))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Lent: ₹${data.second.toInt()}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF81C784))
                        }
                    }
                }
            }
        }
    }
}
