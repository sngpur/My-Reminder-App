package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BirthdayAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val eventId = intent.getIntExtra("EVENT_ID", 0)
        val eventName = intent.getStringExtra("EVENT_NAME") ?: "Upcoming Event"
        val eventType = intent.getStringExtra("EVENT_TYPE") ?: "Birthday"
        val isAlarmEnabled = intent.getBooleanExtra("IS_ALARM_ENABLED", true)
        val initialPhone = intent.getStringExtra("PHONE_NUMBER") ?: ""
        val initialMsg = intent.getStringExtra("CUSTOM_MESSAGE") ?: ""

        val scope = CoroutineScope(Dispatchers.IO)
        scope.launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val event = db.eventDao().getEventById(eventId)
                val phoneNumber = event?.phoneNumber ?: initialPhone
                val customMessage = event?.customMessage ?: initialMsg

                withContext(Dispatchers.Main) {
                    processAlarm(context, eventId, eventName, eventType, isAlarmEnabled, phoneNumber, customMessage)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    processAlarm(context, eventId, eventName, eventType, isAlarmEnabled, initialPhone, initialMsg)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun processAlarm(
        context: Context,
        eventId: Int,
        eventName: String,
        eventType: String,
        isAlarmEnabled: Boolean,
        phoneNumber: String,
        customMessage: String
    ) {
        if (isAlarmEnabled) {
            // Start the loud looping continuous alarm service
            val serviceIntent = Intent(context, BirthdayAlarmService::class.java).apply {
                putExtra("EVENT_ID", eventId)
                putExtra("EVENT_NAME", eventName)
                putExtra("EVENT_TYPE", eventType)
                putExtra("PHONE_NUMBER", phoneNumber)
                putExtra("CUSTOM_MESSAGE", customMessage)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } else {
            // Show a standard notification with default notification sound (NOT silent!)
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "birthday_simple_channel"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channelName = "Event Reminders"
                val importance = NotificationManager.IMPORTANCE_DEFAULT
                val channel = NotificationChannel(channelId, channelName, importance).apply {
                    enableVibration(true)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("EXTRA_ENTITY_ID", eventId)
                putExtra("EXTRA_ENTITY_TYPE", eventType)
            }
            val pendingIntent = PendingIntent.getActivity(
                context, eventId, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val sendWishesIntent = Intent(context, BirthdayActionReceiver::class.java).apply {
                action = "ACTION_SEND_WISHES"
                putExtra("EVENT_ID", eventId)
                putExtra("EVENT_NAME", eventName)
                putExtra("EVENT_TYPE", eventType)
                putExtra("PHONE_NUMBER", phoneNumber)
                putExtra("CUSTOM_MESSAGE", customMessage)
            }
            val sendWishesPendingIntent = PendingIntent.getBroadcast(
                context, eventId + 50000, sendWishesIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notificationBuilder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(if (eventType == "Birthday") android.R.drawable.ic_menu_my_calendar else android.R.drawable.ic_menu_recent_history)
                .setContentTitle("It's $eventName's $eventType!")
                .setContentText("Don't forget to wish them!")
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .addAction(android.R.drawable.ic_menu_send, "Send Wishes", sendWishesPendingIntent)

            val notificationId = eventId + 30000
            notificationManager.notify(notificationId, notificationBuilder.build())
        }
    }
}
