package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BirthdayAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val eventId = intent.getIntExtra("EVENT_ID", 0)
        val eventName = intent.getStringExtra("EVENT_NAME") ?: "Event"
        val eventType = intent.getStringExtra("EVENT_TYPE") ?: "Birthday"

        val serviceIntent = Intent(context, BirthdayAlarmService::class.java).apply {
            putExtra("EVENT_ID", eventId)
            putExtra("EVENT_NAME", eventName)
            putExtra("EVENT_TYPE", eventType)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }
}
