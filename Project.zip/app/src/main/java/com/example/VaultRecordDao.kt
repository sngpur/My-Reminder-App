package com.example

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultRecordDao {
    @Query("SELECT * FROM vault_records ORDER BY dateMillis DESC")
    fun getAllVaultRecords(): Flow<List<VaultRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultRecord(record: VaultRecord)

    @Update
    suspend fun updateVaultRecord(record: VaultRecord)

    @Delete
    suspend fun deleteVaultRecord(record: VaultRecord)
}
