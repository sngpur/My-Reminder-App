package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DocumentScannerViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).scannedDocDao()

    val allScannedDocs: StateFlow<List<ScannedDoc>> = dao.getAllScannedDocs()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun insertScannedDoc(doc: ScannedDoc) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.insertScannedDoc(doc)
        }
    }

    fun deleteScannedDoc(doc: ScannedDoc) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.deleteScannedDoc(doc)
        }
    }
}
