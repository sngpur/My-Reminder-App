package com.example

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScannedTextDao {
    @Query("SELECT * FROM scanned_texts ORDER BY dateMillis DESC")
    fun getAllScannedTexts(): Flow<List<ScannedText>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScannedText(scannedText: ScannedText)

    @Delete
    suspend fun deleteScannedText(scannedText: ScannedText)
}
