package com.example

import androidx.compose.runtime.Stable

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_records")
@Stable
data class ServiceRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val vehicleType: String,
    val lastServiceDate: String,
    val nextServiceDate: String,
    val nextServiceMillis: Long
)
