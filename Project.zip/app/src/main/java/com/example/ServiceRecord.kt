package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "service_records")
data class ServiceRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val vehicleType: String,
    val lastServiceDate: String,
    val nextServiceDate: String,
    val nextServiceMillis: Long
)
