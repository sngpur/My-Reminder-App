package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DocumentExpiryViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val dao = db.documentExpiryDao()
    private val alarmScheduler = DocumentExpiryAlarmScheduler(application)

    val documents = dao.getAllDocuments().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addDocument(docName: String, type: String, expiryDateInMillis: Long) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val newDoc = DocumentExpiry(
                docName = docName,
                type = type,
                expiryDateInMillis = expiryDateInMillis
            )
            val id = dao.insertDocumentExpiry(newDoc)
            alarmScheduler.schedule(newDoc.copy(id = id.toInt()))
        }
    }

    fun deleteDocument(id: Int) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            alarmScheduler.cancel(id)
            dao.deleteDocument(id)
        }
    }

    fun updateDocument(id: Int, docName: String, type: String, expiryDateInMillis: Long) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            alarmScheduler.cancel(id)
            val updatedDoc = DocumentExpiry(
                id = id,
                docName = docName,
                type = type,
                expiryDateInMillis = expiryDateInMillis
            )
            if (id != 0) {
                dao.updateDocumentExpiry(updatedDoc)
            } else {
                dao.insertDocumentExpiry(updatedDoc)
            }
            alarmScheduler.schedule(updatedDoc)
        }
    }

    suspend fun getDocumentById(id: Int): DocumentExpiry? {
        return dao.getDocumentById(id)
    }
}
