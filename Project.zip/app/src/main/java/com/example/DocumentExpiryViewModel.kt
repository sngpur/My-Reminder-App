package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DocumentExpiryViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val dao = db.documentExpiryDao()
    private val alarmScheduler = DocumentExpiryAlarmScheduler(application)

    val documents = dao.getAllDocuments().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addDocument(docName: String, type: String, expiryDateInMillis: Long) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val newDoc = DocumentExpiry(
                docName = docName,
                type = type,
                expiryDateInMillis = expiryDateInMillis
            )
            val id = dao.insertDocumentExpiry(newDoc)
            alarmScheduler.schedule(newDoc.copy(id = id.toInt()))
        }
    }
}
