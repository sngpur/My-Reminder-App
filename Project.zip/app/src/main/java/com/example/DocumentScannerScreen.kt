package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_JPEG
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_PDF
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.SCANNER_MODE_FULL
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScannerScreen(navController: NavController, viewModel: DocumentScannerViewModel, openDrawer: () -> Unit) {
    val scannedDocs by viewModel.allScannedDocs.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var scanResult by remember { mutableStateOf<GmsDocumentScanningResult?>(null) }

    val scannerOptions = remember {
        GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(RESULT_FORMAT_JPEG, RESULT_FORMAT_PDF)
            .setScannerMode(SCANNER_MODE_FULL)
            .build()
    }

    val scannerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scanResult = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
        }
    }

    val launchScanner = {
        val client = GmsDocumentScanning.getClient(scannerOptions)
        val activity = context.findActivity()
        if (activity != null) {
            client.getStartScanIntent(activity)
                .addOnSuccessListener { intentSender ->
                    scannerLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Failed to start scanner: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(context, "Could not find Activity context", Toast.LENGTH_SHORT).show()
        }
    }

    if (scanResult != null) {
        var documentTitle by remember { mutableStateOf("") }
        var selectedFormat by remember { mutableStateOf("PDF") }
        var selectedQuality by remember { mutableStateOf("High") }
        
        AlertDialog(
            onDismissRequest = { scanResult = null },
            title = { Text("Save Document Settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    OutlinedTextField(
                        value = documentTitle,
                        onValueChange = { documentTitle = it },
                        label = { Text("Document Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Column {
                        Text("Format", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedFormat == "PDF",
                                onClick = { selectedFormat = "PDF" },
                                label = { Text("PDF") }
                            )
                            FilterChip(
                                selected = selectedFormat == "JPG",
                                onClick = { selectedFormat = "JPG" },
                                label = { Text("JPG") }
                            )
                        }
                    }
                    
                    if (selectedFormat == "JPG") {
                        Column {
                            Text("Quality/Resize", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = selectedQuality == "High",
                                    onClick = { selectedQuality = "High" },
                                    label = { Text("High") }
                                )
                                FilterChip(
                                    selected = selectedQuality == "Medium",
                                    onClick = { selectedQuality = "Medium" },
                                    label = { Text("Medium") }
                                )
                                FilterChip(
                                    selected = selectedQuality == "Low",
                                    onClick = { selectedQuality = "Low" },
                                    label = { Text("Low") }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val title = if (documentTitle.isNotBlank()) documentTitle else "Untitled"
                        coroutineScope.launch {
                            val savedPath = saveDocument(context, scanResult!!, selectedFormat, selectedQuality)
                            if (savedPath != null) {
                                viewModel.insertScannedDoc(
                                    ScannedDoc(
                                        title = title,
                                        fileUri = savedPath,
                                        format = selectedFormat,
                                        pageCount = scanResult?.pages?.size ?: 0,
                                        dateMillis = System.currentTimeMillis()
                                    )
                                )
                                Toast.makeText(context, "Saved to Documents/MyBuddyScanner", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Failed to save document", Toast.LENGTH_SHORT).show()
                            }
                            scanResult = null
                        }
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { scanResult = null }) { Text("Cancel") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Document Scanner", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = openDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Menu")
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Top Section - Action Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f)
                    .clickable { launchScanner() },
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DocumentScanner,
                        contentDescription = "Scan New Document",
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Scan New Document",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Auto-crop & Filters included",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }

            // Bottom Section - Saved Documents
            Text(
                text = "Saved Documents",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (scannedDocs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No saved documents",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(scannedDocs, key = { it.id }, contentType = { "doc_scan" }) { doc ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Icon for Format
                                    Icon(
                                        imageVector = if (doc.format == "PDF") Icons.Default.PictureAsPdf else Icons.Default.Image,
                                        contentDescription = doc.format,
                                        modifier = Modifier.size(40.dp),
                                        tint = if (doc.format == "PDF") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    
                                    // Details
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = doc.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = Instant.ofEpochMilli(doc.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "•",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "${doc.pageCount} Pages",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                // Actions
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    IconButton(onClick = {
                                        val uriString = doc.fileUri
                                        val uri = if (uriString.startsWith("content://")) {
                                            Uri.parse(uriString)
                                        } else {
                                            val file = File(uriString)
                                            if (file.exists()) FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file) else null
                                        }
                                        if (uri != null) {
                                            val mimeType = if (doc.format == "PDF") "application/pdf" else "image/jpeg"
                                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(uri, mimeType)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            try {
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "No app found to view this file", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }) {
                                        Icon(Icons.Default.Visibility, contentDescription = "View", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    
                                    IconButton(onClick = {
                                        val uriString = doc.fileUri
                                        val uri = if (uriString.startsWith("content://")) {
                                            Uri.parse(uriString)
                                        } else {
                                            val file = File(uriString)
                                            if (file.exists()) FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file) else null
                                        }
                                        if (uri != null) {
                                            val mimeType = if (doc.format == "PDF") "application/pdf" else "image/jpeg"
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = mimeType
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Share Document"))
                                        }
                                    }) {
                                        Icon(Icons.Default.Share, contentDescription = "Share", tint = MaterialTheme.colorScheme.secondary)
                                    }
                                    
                                    IconButton(onClick = {
                                        val uriString = doc.fileUri
                                        try {
                                            if (uriString.startsWith("content://")) {
                                                context.contentResolver.delete(Uri.parse(uriString), null, null)
                                            } else {
                                                File(uriString).delete()
                                            }
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                        }
                                        viewModel.deleteScannedDoc(doc)
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

suspend fun saveDocument(context: Context, scanResult: GmsDocumentScanningResult, format: String, quality: String): String? {
    return withContext(Dispatchers.IO) {
        try {
            if (format == "PDF") {
                val pdfUri = scanResult.pdf?.uri ?: return@withContext null
                val fileName = "Doc_${System.currentTimeMillis()}.pdf"
                val savedUri = MediaStoreHelper.saveToPublicDocuments(context, pdfUri, fileName, "application/pdf")
                savedUri?.toString()
            } else {
                val firstPageUri = scanResult.pages?.firstOrNull()?.imageUri ?: return@withContext null
                
                val compressQuality = when (quality) {
                    "High" -> 100
                    "Medium" -> 50
                    "Low" -> 20
                    else -> 100
                }
                
                val sourceUriToSave = if (compressQuality < 100) {
                    val inputStream = context.contentResolver.openInputStream(firstPageUri) ?: return@withContext null
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    val tempFile = File(context.cacheDir, "temp_compressed_${System.currentTimeMillis()}.jpg")
                    val outStream = java.io.FileOutputStream(tempFile)
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, compressQuality, outStream)
                    outStream.flush()
                    outStream.close()
                    Uri.fromFile(tempFile)
                } else {
                    firstPageUri
                }
                
                val fileName = "Doc_${System.currentTimeMillis()}.jpg"
                val savedUri = MediaStoreHelper.saveToPublicDocuments(context, sourceUriToSave, fileName, "image/jpeg")
                
                // Cleanup temp file if created
                if (compressQuality < 100) {
                    File(sourceUriToSave.path!!).delete()
                }
                
                savedUri?.toString()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
