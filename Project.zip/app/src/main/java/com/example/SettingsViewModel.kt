package com.example

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit


class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("somnath_settings", Context.MODE_PRIVATE)

    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("is_dark_mode", false))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode


    private val _isAutoBackupEnabled = MutableStateFlow(prefs.getBoolean("is_auto_backup_enabled", false))
    val isAutoBackupEnabled: StateFlow<Boolean> = _isAutoBackupEnabled

    init {
        if (_isAutoBackupEnabled.value) {
            scheduleAutoBackup()
        }
    }

    fun setAutoBackup(enabled: Boolean) {
        prefs.edit().putBoolean("is_auto_backup_enabled", enabled).apply()
        _isAutoBackupEnabled.value = enabled
        if (enabled) {
            scheduleAutoBackup()
        } else {
            cancelAutoBackup()
        }
    }

    private fun scheduleAutoBackup() {
        val constraints = androidx.work.Constraints.Builder()
            .setRequiresDeviceIdle(true)
            .setRequiresCharging(true)
            .build()
        val backupRequest = PeriodicWorkRequestBuilder<BackupWorker>(7, TimeUnit.DAYS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(getApplication()).enqueueUniquePeriodicWork(
            "WeeklyAutoBackup",
            ExistingPeriodicWorkPolicy.KEEP,
            backupRequest
        )
    }

    private fun cancelAutoBackup() {
        WorkManager.getInstance(getApplication()).cancelUniqueWork("WeeklyAutoBackup")
    }

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("is_dark_mode", enabled).apply()
        _isDarkMode.value = enabled
    }
}
