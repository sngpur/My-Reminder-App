package com.example

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("somnath_settings", Context.MODE_PRIVATE)

    fun setBackupPassword(password: String) {
        try {
            val masterKey = MasterKey.Builder(getApplication())
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            val sharedPreferences = EncryptedSharedPreferences.create(
                getApplication(),
                "secret_shared_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            sharedPreferences.edit().putString("backup_password", password).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("is_dark_mode", false))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode

    private val _appIconStyle = MutableStateFlow(prefs.getString("app_icon_style", "Default (Blue)") ?: "Default (Blue)")
    val appIconStyle: StateFlow<String> = _appIconStyle

    fun setAppIconStyle(style: String) {
        prefs.edit().putString("app_icon_style", style).apply()
        _appIconStyle.value = style
    }

    private val _isMorningBriefingEnabled = MutableStateFlow(prefs.getBoolean("is_morning_briefing_enabled", true))
    val isMorningBriefingEnabled: StateFlow<Boolean> = _isMorningBriefingEnabled

    fun setMorningBriefingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("is_morning_briefing_enabled", enabled).apply()
        _isMorningBriefingEnabled.value = enabled
    }


    private val _isAutoBackupEnabled = MutableStateFlow(prefs.getBoolean("is_auto_backup_enabled", false))
    val isAutoBackupEnabled: StateFlow<Boolean> = _isAutoBackupEnabled

    init {
        if (_isAutoBackupEnabled.value) {
            scheduleAutoBackup()
        }
    }

    fun setAutoBackup(enabled: Boolean) {
        prefs.edit().putBoolean("is_auto_backup_enabled", enabled).apply()
        _isAutoBackupEnabled.value = enabled
        if (enabled) {
            scheduleAutoBackup()
        } else {
            cancelAutoBackup()
        }
    }

    private fun scheduleAutoBackup() {
        val constraints = androidx.work.Constraints.Builder()
            .setRequiresDeviceIdle(true)
            .setRequiresCharging(true)
            .build()
        val backupRequest = PeriodicWorkRequestBuilder<BackupWorker>(7, TimeUnit.DAYS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(getApplication()).enqueueUniquePeriodicWork(
            "WeeklyAutoBackup",
            ExistingPeriodicWorkPolicy.KEEP,
            backupRequest
        )
    }

    private fun cancelAutoBackup() {
        WorkManager.getInstance(getApplication()).cancelUniqueWork("WeeklyAutoBackup")
    }

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("is_dark_mode", enabled).apply()
        _isDarkMode.value = enabled
    }
}
