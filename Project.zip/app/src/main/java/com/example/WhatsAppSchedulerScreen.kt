package com.example

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsAppSchedulerScreen(navController: NavController, viewModel: WhatsAppViewModel = viewModel()) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    val pendingSchedules by viewModel.pendingSchedules.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("WhatsApp Scheduler") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add Schedule")
            }
        }
    ) { padding ->
        if (pendingSchedules.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("No pending schedules")
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
                items(pendingSchedules, key = { it.id }) { schedule ->
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("To: ${schedule.phoneNumber}", style = MaterialTheme.typography.titleMedium)
                            Text("Message: ${schedule.message}", style = MaterialTheme.typography.bodyMedium)
                            val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")
                            val dateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(schedule.scheduledTimeInMillis), ZoneId.systemDefault())
                            Text("Scheduled for: ${dateTime.format(formatter)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var phoneNumber by remember { mutableStateOf("") }
        var message by remember { mutableStateOf("") }
        var scheduledDateTime by remember { mutableStateOf(LocalDateTime.now().plusMinutes(5)) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Schedule WhatsApp Message") },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { phoneNumber = it },
                        label = { Text("Phone Number (with country code)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("Message") },
                        modifier = Modifier.fillMaxWidth().height(100.dp)
                    )
                    Button(onClick = {
                        val datePickerDialog = DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                val timePickerDialog = TimePickerDialog(
                                    context,
                                    { _, hourOfDay, minute ->
                                        scheduledDateTime = LocalDateTime.of(year, month + 1, dayOfMonth, hourOfDay, minute)
                                    },
                                    scheduledDateTime.hour,
                                    scheduledDateTime.minute,
                                    false
                                )
                                timePickerDialog.show()
                            },
                            scheduledDateTime.year,
                            scheduledDateTime.monthValue - 1,
                            scheduledDateTime.dayOfMonth
                        )
                        datePickerDialog.show()
                    }) {
                        val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")
                        Text("Pick Time: ${scheduledDateTime.format(formatter)}")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (phoneNumber.isNotBlank() && message.isNotBlank()) {
                        viewModel.addSchedule(
                            phoneNumber = phoneNumber,
                            message = message,
                            scheduledTimeInMillis = scheduledDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        )
                        showAddDialog = false
                    }
                }) {
                    Text("Schedule")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
