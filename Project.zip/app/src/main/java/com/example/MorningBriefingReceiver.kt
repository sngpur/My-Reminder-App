package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.Instant
import java.time.ZoneId

class MorningBriefingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val scheduler = MorningBriefingScheduler(context)
        scheduler.scheduleDailyBriefing()

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
            val db = AppDatabase.getDatabase(context)
            val today = LocalDate.now().toString()
            val currentLocalDate = LocalDate.now()

            val tasks = db.reminderDao().getRemindersForDateSync(today)
            val taskCount = tasks.size

            val allEvents = db.eventDao().getAllEventsSync()
            var birthdayCount = 0
            for (e in allEvents) {
                try {
                    val eventDate = LocalDate.parse(e.date)
                    if (eventDate.monthValue == currentLocalDate.monthValue && eventDate.dayOfMonth == currentLocalDate.dayOfMonth) {
                        birthdayCount++
                    }
                } catch (ex: Exception) {
                    // Ignore parse errors
                }
            }

            val financeTasks = db.reminderDao().getFinanceRemindersSync()
            var pendingPayments = 0.0
            var pendingReceivables = 0.0
            for (t in financeTasks) {
                if (!t.isCompleted && t.amount != null) {
                    if (t.category == "Upcoming Payment") pendingPayments += t.amount
                    else if (t.category == "Money Lent (Udhar)") pendingReceivables += t.amount
                }
            }

            val activityIntent = Intent(context, MorningBriefingActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("TASK_COUNT", taskCount)
                putExtra("BIRTHDAY_COUNT", birthdayCount)
                putExtra("PAYMENTS", pendingPayments)
                putExtra("RECEIVABLES", pendingReceivables)
            }

            val pendingIntent = PendingIntent.getActivity(
                context, 0, activityIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            val notification = NotificationCompat.Builder(context, "Channel_Morning")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Good Morning, Buddy!")
                .setContentText("Tap to view your daily briefing")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setFullScreenIntent(pendingIntent, true)
                .setAutoCancel(true)
                .build()

            notificationManager.notify(9999, notification)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
