package com.example

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class BirthdayActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val eventId = intent.getIntExtra("EVENT_ID", 0)
        val eventName = intent.getStringExtra("EVENT_NAME") ?: "Event"
        val eventType = intent.getStringExtra("EVENT_TYPE") ?: "Birthday"
        val phoneNumber = intent.getStringExtra("PHONE_NUMBER") ?: ""
        val customMessage = intent.getStringExtra("CUSTOM_MESSAGE") ?: ""
        val notificationId = eventId + 30000

        // Always stop the foreground service (this stops the media player and vibrator)
        val serviceIntent = Intent(context, BirthdayAlarmService::class.java)
        context.stopService(serviceIntent)

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (action == "ACTION_STOP_ALARM") {
            // Keep the notification in the system tray, but remove the ongoing status and Stop Alarm action.
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("EXTRA_ENTITY_ID", eventId)
                putExtra("EXTRA_ENTITY_TYPE", eventType)
                putExtra("EXTRA_IS_RINGING", false)
                }
            val pendingIntent = PendingIntent.getActivity(
                context, eventId, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val sendWishesIntent = Intent(context, BirthdayActionReceiver::class.java).apply {
                this.action = "ACTION_SEND_WISHES"
                putExtra("EVENT_ID", eventId)
                putExtra("EVENT_NAME", eventName)
                putExtra("EVENT_TYPE", eventType)
                putExtra("PHONE_NUMBER", phoneNumber)
                putExtra("CUSTOM_MESSAGE", customMessage)
            }
            val sendWishesPendingIntent = PendingIntent.getBroadcast(
                context, eventId + 50000, sendWishesIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val channelId = "birthday_simple_channel"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val channel = android.app.NotificationChannel(
                    channelId,
                    "Event Reminders",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
                notificationManager.createNotificationChannel(channel)
            }

            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(if (eventType == "Birthday") android.R.drawable.ic_menu_my_calendar else android.R.drawable.ic_menu_recent_history)
                .setContentTitle("It's $eventName's $eventType!")
                .setContentText("Don't forget to wish them!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_menu_send, "Send Wishes", sendWishesPendingIntent)
                .build()

            // Post it again to replace the foreground notification
            notificationManager.notify(notificationId, notification)
        } else if (action == "ACTION_SEND_WISHES") {
            val messageToSend = if (customMessage.isNotBlank()) customMessage else {
                if (eventType == "Birthday") {
                    "Happy Birthday $eventName! 🎂🎈"
                } else {
                    "Happy Anniversary $eventName! 🎉"
                }
            }

            // Clean the phone number (remove +, spaces, ensure it is non-empty)
            val cleanedPhone = phoneNumber.filter { it.isDigit() }

            if (cleanedPhone.isNotBlank()) {
                val whatsappUri = android.net.Uri.parse("https://api.whatsapp.com/send?phone=$cleanedPhone&text=${android.net.Uri.encode(messageToSend)}")
                val whatsappIntent = Intent(Intent.ACTION_VIEW, whatsappUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(whatsappIntent)
                } catch (e: Exception) {
                    // Fallback to standard sharing if WhatsApp is not installed
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, messageToSend)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    val chooserIntent = Intent.createChooser(shareIntent, "Send wishes via").apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(chooserIntent)
                }
            } else {
                // Fallback to generic share chooser
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, messageToSend)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                val chooserIntent = Intent.createChooser(shareIntent, "Send wishes via").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(chooserIntent)
            }

            // Cancel the notification since we took action
            notificationManager.cancel(notificationId)
        }
    }
}
