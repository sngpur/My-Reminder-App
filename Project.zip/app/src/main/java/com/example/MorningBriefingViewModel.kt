package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import java.time.LocalDate

class MorningBriefingViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val reminderDao = db.reminderDao()
    private val eventDao = db.eventDao()
    private val serviceRecordDao = db.serviceRecordDao()

    val todayTasks: StateFlow<List<Reminder>> = reminderDao.getAllReminders()
        .map { reminders ->
            val todayStr = LocalDate.now().toString()
            reminders.filter { it.taskDate == todayStr && !it.isDeleted }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayEvents: StateFlow<List<Event>> = eventDao.getAllEvents()
        .map { events ->
            val currentLocalDate = LocalDate.now()
            events.filter { e ->
                try {
                    val eventDate = LocalDate.parse(e.date)
                    eventDate.monthValue == currentLocalDate.monthValue && eventDate.dayOfMonth == currentLocalDate.dayOfMonth
                } catch (ex: Exception) {
                    false
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayServicing: StateFlow<List<ServiceRecord>> = serviceRecordDao.getAllServiceRecords()
        .map { servicing ->
            val todayStr = LocalDate.now().toString()
            servicing.filter { it.nextServiceDate == todayStr }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingPayments: StateFlow<Double> = reminderDao.getAllReminders()
        .map { reminders ->
            reminders.filter { !it.isCompleted && !it.isDeleted && it.amount != null && it.category == "Upcoming Payment" }
                .sumOf { it.amount ?: 0.0 }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val pendingReceivables: StateFlow<Double> = reminderDao.getAllReminders()
        .map { reminders ->
            reminders.filter { !it.isCompleted && !it.isDeleted && it.amount != null && it.category == "Money Lent (Udhar)" }
                .sumOf { it.amount ?: 0.0 }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
}
