package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.LocalGasStation
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MilageCalculatorScreen(navController: NavController, viewModel: MilageViewModel, openDrawer: () -> Unit) {
    var showFuelDialog by remember { mutableStateOf(false) }
    var showServiceDialog by remember { mutableStateOf(false) }
    var logToEdit by remember { mutableStateOf<FuelRecord?>(null) }
    var serviceVehicleType by remember { mutableStateOf("Bike") }
    
    val bikeFuelRecords by viewModel.bikeFuelRecords.collectAsStateWithLifecycle()
    val carFuelRecords by viewModel.carFuelRecords.collectAsStateWithLifecycle()
    val bikeServiceRecord by viewModel.bikeServiceRecord.collectAsStateWithLifecycle()
    val carServiceRecord by viewModel.carServiceRecord.collectAsStateWithLifecycle()
    
    var selectedVehicleTab by remember { mutableStateOf("Bike") }
    val currentFuelRecords = if (selectedVehicleTab == "Bike") bikeFuelRecords else carFuelRecords

    val calculateAvg = { records: List<FuelRecord> ->
        if (records.size < 2) 0.0
        else {
            val sorted = records.sortedBy { it.odometerKm }
            val distance = (sorted.last().odometerKm - sorted.first().odometerKm).toDouble()
            val fuel = sorted.dropLast(1).sumOf { it.fuelLiters }
            if (fuel == 0.0) 0.0 else distance / fuel
        }
    }
    
    val bikeAvg = calculateAvg(bikeFuelRecords)
    val carAvg = calculateAvg(carFuelRecords)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Milage Calculator", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = openDrawer) {
                        Icon(Icons.Filled.Menu, contentDescription = "Menu")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showFuelDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Record")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                // Dashboard Layout (Two Bento Boxes)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Bike Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.TwoWheeler,
                                        contentDescription = "Bike",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                
                                Text(
                                    text = "Bike Avg",
                                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 16.sp),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                Text(
                                    text = String.format(Locale.getDefault(), "%.1f km/l", bikeAvg),
                                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 28.sp),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                            
                            IconButton(
                                onClick = { /* TODO: Reset Bike Data */ },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "Reset Bike Data",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    // Car Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.DirectionsCar,
                                        contentDescription = "Car",
                                        tint = MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                
                                Text(
                                    text = "Car Avg",
                                    style = MaterialTheme.typography.labelMedium.copy(fontSize = 16.sp),
                                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                Text(
                                    text = String.format(Locale.getDefault(), "%.1f km/l", carAvg),
                                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 28.sp),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                            
                            IconButton(
                                onClick = { /* TODO: Reset Car Data */ },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "Reset Car Data",
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
            }
            }

            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "SERVICING SCHEDULE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.TwoWheeler, contentDescription = "Bike", tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Bike Servicing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            val last = bikeServiceRecord?.lastServiceDate ?: "Not set"
                            val next = bikeServiceRecord?.nextServiceDate ?: "Not set"
                            Text("Last: $last • Next: $next", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { 
                            serviceVehicleType = "Bike"
                            showServiceDialog = true 
                        }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit Bike Service", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.DirectionsCar, contentDescription = "Car", tint = MaterialTheme.colorScheme.secondary)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Car Servicing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            val last = carServiceRecord?.lastServiceDate ?: "Not set"
                            val next = carServiceRecord?.nextServiceDate ?: "Not set"
                            Text("Last: $last • Next: $next", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { 
                            serviceVehicleType = "Car"
                            showServiceDialog = true 
                        }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit Car Service", tint = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }
            }

            item {
                Column(modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = selectedVehicleTab == "Bike",
                            onClick = { selectedVehicleTab = "Bike" },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                        ) {
                            Text("Bike History")
                        }
                        SegmentedButton(
                            selected = selectedVehicleTab == "Car",
                            onClick = { selectedVehicleTab = "Car" },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                        ) {
                            Text("Car History")
                        }
                    }
                }
            }

            if (currentFuelRecords.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No records found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                val sortedRecords = currentFuelRecords.sortedByDescending { it.dateMillis }
                itemsIndexed(sortedRecords) { index, record ->
                    val previousRecord = if (index + 1 < sortedRecords.size) sortedRecords[index + 1] else null
                    FuelRecordItem(
                        record = record,
                        previousRecord = previousRecord,
                        onEdit = {
                            logToEdit = record
                            showFuelDialog = true
                        },
                        onDelete = { viewModel.deleteFuelRecord(record) }
                    )
                }
            }
        }
    }

    if (showFuelDialog) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var fuelVehicleType by remember { mutableStateOf("Bike") }
        var odometerStr by remember { mutableStateOf(logToEdit?.odometerKm?.toString() ?: "") }
        var fuelLitersStr by remember { mutableStateOf(logToEdit?.fuelLiters?.toString() ?: "") }
        var dateMillis by remember { mutableStateOf(logToEdit?.dateMillis ?: System.currentTimeMillis()) }
        var showDatePicker by remember { mutableStateOf(false) }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = dateMillis)

        ModalBottomSheet(onDismissRequest = { showFuelDialog = false }, sheetState = sheetState) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Add Fuel Record", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(selected = fuelVehicleType == "Bike", onClick = { fuelVehicleType = "Bike" }, shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)) {
                        Text("Bike")
                    }
                    SegmentedButton(selected = fuelVehicleType == "Car", onClick = { fuelVehicleType = "Car" }, shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)) {
                        Text("Car")
                    }
                }

                OutlinedTextField(
                    value = Instant.ofEpochMilli(dateMillis).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")),
                    onValueChange = {},
                    label = { Text("Date") },
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true,
                    leadingIcon = { Icon(Icons.Outlined.CalendarToday, contentDescription = null) },
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }.also { interactionSource ->
                        LaunchedEffect(interactionSource) {
                            interactionSource.interactions.collect {
                                if (it is androidx.compose.foundation.interaction.PressInteraction.Release) showDatePicker = true
                            }
                        }
                    }
                )

                OutlinedTextField(
                    value = odometerStr,
                    onValueChange = { odometerStr = it },
                    label = { Text("Odometer Reading (km)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                OutlinedTextField(
                    value = fuelLitersStr,
                    onValueChange = { fuelLitersStr = it },
                    label = { Text("Fuel Added (Liters)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                Row(modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 24.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    OutlinedButton(onClick = { showFuelDialog = false }, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val odo = odometerStr.toIntOrNull()
                            val fuel = fuelLitersStr.toDoubleOrNull()
                            if (odo != null && fuel != null) {
                                if (logToEdit == null) {
                                    viewModel.addFuelRecord(FuelRecord(vehicleType = fuelVehicleType, dateMillis = dateMillis, odometerKm = odo, fuelLiters = fuel))
                                } else {
                                    viewModel.updateFuelRecord(logToEdit!!.copy(dateMillis = dateMillis, odometerKm = odo, fuelLiters = fuel))
                                }
                                showFuelDialog = false
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = odometerStr.isNotBlank() && fuelLitersStr.isNotBlank()
                    ) {
                        Text("Save")
                    }
                }
            }
        }

        if (showDatePicker) {
            DatePickerDialog(
                onDismissRequest = { showDatePicker = false },
                confirmButton = {
                    TextButton(onClick = {
                        datePickerState.selectedDateMillis?.let { dateMillis = it }
                        showDatePicker = false
                    }) { Text("OK") }
                },
                dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
            ) {
                DatePicker(state = datePickerState)
            }
        }
    }

    if (showServiceDialog) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        val currentRecord = if (serviceVehicleType == "Bike") bikeServiceRecord else carServiceRecord
        
        val defaultNextDate = LocalDate.now().plusMonths(3)
        var lastServiceStr by remember { mutableStateOf(currentRecord?.lastServiceDate ?: LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))) }
        var nextServiceStr by remember { mutableStateOf(currentRecord?.nextServiceDate ?: defaultNextDate.format(DateTimeFormatter.ofPattern("dd MMM yyyy"))) }
        val defaultNextMillis = defaultNextDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        var nextServiceMillis by remember { mutableStateOf(currentRecord?.nextServiceMillis ?: defaultNextMillis) }

        var showLastPicker by remember { mutableStateOf(false) }
        var showNextPicker by remember { mutableStateOf(false) }
        val lastPickerState = rememberDatePickerState(initialSelectedDateMillis = System.currentTimeMillis())
        val nextPickerState = rememberDatePickerState(initialSelectedDateMillis = nextServiceMillis)

        ModalBottomSheet(onDismissRequest = { showServiceDialog = false }, sheetState = sheetState) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Edit $serviceVehicleType Servicing", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = lastServiceStr,
                    onValueChange = {},
                    label = { Text("Last Service Date") },
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true,
                    leadingIcon = { Icon(Icons.Outlined.CalendarToday, contentDescription = null) },
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }.also { interactionSource ->
                        LaunchedEffect(interactionSource) {
                            interactionSource.interactions.collect {
                                if (it is androidx.compose.foundation.interaction.PressInteraction.Release) showLastPicker = true
                            }
                        }
                    }
                )

                OutlinedTextField(
                    value = nextServiceStr,
                    onValueChange = {},
                    label = { Text("Next Service Date") },
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true,
                    leadingIcon = { Icon(Icons.Outlined.CalendarToday, contentDescription = null) },
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }.also { interactionSource ->
                        LaunchedEffect(interactionSource) {
                            interactionSource.interactions.collect {
                                if (it is androidx.compose.foundation.interaction.PressInteraction.Release) showNextPicker = true
                            }
                        }
                    }
                )
                
                Text(
                    text = "Setting a Next Service Date will schedule a local notification with sound to remind you.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 24.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    OutlinedButton(onClick = { showServiceDialog = false }, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val record = currentRecord?.copy(lastServiceDate = lastServiceStr, nextServiceDate = nextServiceStr, nextServiceMillis = nextServiceMillis)
                                ?: ServiceRecord(vehicleType = serviceVehicleType, lastServiceDate = lastServiceStr, nextServiceDate = nextServiceStr, nextServiceMillis = nextServiceMillis)
                            viewModel.saveServiceRecord(record)
                            // TODO: Trigger AlarmManager for nextServiceMillis
                            showServiceDialog = false
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save")
                    }
                }
            }
        }

        if (showLastPicker) {
            DatePickerDialog(
                onDismissRequest = { showLastPicker = false },
                confirmButton = {
                    TextButton(onClick = {
                        lastPickerState.selectedDateMillis?.let {
                            lastServiceStr = Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
                        }
                        showLastPicker = false
                    }) { Text("OK") }
                },
                dismissButton = { TextButton(onClick = { showLastPicker = false }) { Text("Cancel") } }
            ) { DatePicker(state = lastPickerState) }
        }

        if (showNextPicker) {
            DatePickerDialog(
                onDismissRequest = { showNextPicker = false },
                confirmButton = {
                    TextButton(onClick = {
                        nextPickerState.selectedDateMillis?.let {
                            nextServiceMillis = it
                            nextServiceStr = Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
                        }
                        showNextPicker = false
                    }) { Text("OK") }
                },
                dismissButton = { TextButton(onClick = { showNextPicker = false }) { Text("Cancel") } }
            ) { DatePicker(state = nextPickerState) }
        }
    }
}


@Composable
fun FuelRecordItem(
    record: FuelRecord,
    previousRecord: FuelRecord?,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showDelete by remember { mutableStateOf(false) }
    
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete Record") },
            text = { Text("Are you sure you want to delete this fuel record?") },
            confirmButton = { TextButton(onClick = { showDelete = false; onDelete() }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }

    val distance = previousRecord?.let { record.odometerKm - it.odometerKm } ?: 0
    val milage = if (distance > 0 && previousRecord != null && previousRecord.fuelLiters > 0.0) distance.toDouble() / previousRecord.fuelLiters else 0.0
    val dayGap = previousRecord?.let { 
         ChronoUnit.DAYS.between(
            Instant.ofEpochMilli(it.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate(),
            Instant.ofEpochMilli(record.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        )
    } ?: 0

    Card(
        modifier = Modifier.fillMaxWidth().clickable { onEdit() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Instant.ofEpochMilli(record.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${record.odometerKm} km", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = { showDelete = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.LocalGasStation, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${record.fuelLiters} L", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
                if (previousRecord != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Speed, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(String.format(Locale.getDefault(), "%.1f km/l", milage), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text("+$distance km • $dayGap days", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
