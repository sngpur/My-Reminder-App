package com.example

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color

import androidx.compose.animation.animateColor
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import coil.compose.AsyncImage
import android.content.Intent


@Composable
fun MBBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFFFACC15), Color(0xFFF97316)))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "MB",
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun LiveColorBanner(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val infiniteTransition = rememberInfiniteTransition()
    val color1 by infiniteTransition.animateColor(
        initialValue = Color(0xFF6366F1), // Indigo
        targetValue = Color(0xFFEC4899), // Pink
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Reverse)
    )
    val color2 by infiniteTransition.animateColor(
        initialValue = Color(0xFF3B82F6), // Blue
        targetValue = Color(0xFF8B5CF6), // Purple
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Reverse)
    )
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(color1, color2))),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, viewModel: ReminderViewModel, settingsViewModel: SettingsViewModel) {
    val reminders by viewModel.uiState.collectAsStateWithLifecycle()
    val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
    val context = LocalContext.current
    
    var reminderToDelete by remember { mutableStateOf<Reminder?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showSyncMenu by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        val jsonArray = JSONArray()
                        reminders.forEach { r ->
                            val obj = JSONObject()
                            obj.put("taskTitle", r.taskTitle)
                            obj.put("category", r.category)
                            obj.put("taskDate", r.taskDate)
                            obj.put("taskTime", r.taskTime)
                            obj.put("reminder2Date", r.reminder2Date ?: JSONObject.NULL)
                            obj.put("reminder2Time", r.reminder2Time ?: JSONObject.NULL)
                            obj.put("reminder3Date", r.reminder3Date ?: JSONObject.NULL)
                            obj.put("reminder3Time", r.reminder3Time ?: JSONObject.NULL)
                            obj.put("isCompleted", r.isCompleted)
                            obj.put("location", r.location)
                            obj.put("amount", r.amount ?: JSONObject.NULL)
                            obj.put("repeatInterval", r.repeatInterval)
                            obj.put("imageUri", r.imageUri ?: JSONObject.NULL)
                            obj.put("tags", r.tags)
                            jsonArray.put(obj)
                        }
                        writer.write(jsonArray.toString(2))
                    }
                }
                Toast.makeText(context, "Data exported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    InputStreamReader(inputStream).use { reader ->
                        val jsonStr = reader.readText()
                        val jsonArray = JSONArray(jsonStr)
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.getJSONObject(i)
                            val reminder = Reminder(
                                taskTitle = obj.getString("taskTitle"),
                                category = obj.getString("category"),
                                taskDate = obj.getString("taskDate"),
                                taskTime = obj.getString("taskTime"),
                                reminder2Date = if (obj.isNull("reminder2Date")) null else obj.getString("reminder2Date"),
                                reminder2Time = if (obj.isNull("reminder2Time")) null else obj.getString("reminder2Time"),
                                reminder3Date = if (obj.isNull("reminder3Date")) null else obj.getString("reminder3Date"),
                                reminder3Time = if (obj.isNull("reminder3Time")) null else obj.getString("reminder3Time"),
                                isCompleted = obj.getBoolean("isCompleted"),
                                location = obj.optString("location", ""),
                                amount = if (obj.isNull("amount")) null else obj.getDouble("amount"),
                                repeatInterval = obj.optString("repeatInterval", "None"),
                                imageUri = if (obj.isNull("imageUri")) null else obj.getString("imageUri"),
                                tags = obj.optString("tags", "")
                            )
                            viewModel.addReminder(reminder)
                        }
                    }
                }
                Toast.makeText(context, "Data imported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Import failed or invalid format", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    var selectedFilter by remember { mutableStateOf("All") }
    
    val drawerState = androidx.compose.material3.rememberDrawerState(initialValue = androidx.compose.material3.DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    
    if (reminderToDelete != null) {
        AlertDialog(
            onDismissRequest = { reminderToDelete = null },
            title = { Text("Delete Task") },
            text = { Text("Are you sure you want to delete '${reminderToDelete?.taskTitle}'?") },
            confirmButton = {
                TextButton(onClick = { 
                    reminderToDelete?.let { viewModel.deleteReminder(it) }
                    reminderToDelete = null
                }) { Text("Yes", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { reminderToDelete = null }) { Text("No") }
            }
        )
    }
    
    androidx.compose.material3.ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            androidx.compose.material3.ModalDrawerSheet {
                // Drawer Header
                LiveColorBanner(modifier = Modifier.height(180.dp)) {
                    Column(
                        modifier = Modifier.padding(16.dp).align(Alignment.BottomStart)
                    ) {
                        MBBadge(modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "My Buddy",
                            color = Color.White,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                val menuItems = listOf(
                    "General Reminder" to androidx.compose.material.icons.Icons.Rounded.CheckCircle,
                    "Birthday & Anniversary" to androidx.compose.material.icons.Icons.Rounded.Cake,
                    "Milage Calculator" to androidx.compose.material.icons.Icons.Rounded.DirectionsCar,
                    "My Notes" to androidx.compose.material.icons.Icons.Rounded.EditNote,
                    "Age Calculator" to androidx.compose.material.icons.Icons.Rounded.HourglassEmpty,
                    "Photo Resizer" to androidx.compose.material.icons.Icons.Rounded.PhotoSizeSelectLarge,
                    "Text Scanner" to androidx.compose.material.icons.Icons.Rounded.DocumentScanner,
                    "Documents Scanner" to androidx.compose.material.icons.Icons.Rounded.DocumentScanner,
                    "QR & Barcode Scanner" to androidx.compose.material.icons.Icons.Rounded.QrCodeScanner,
                    "Secure Vault" to androidx.compose.material.icons.Icons.Rounded.Lock
                )

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(menuItems) { (title, icon) ->
                        val isSelected = title == "General Reminder"
                        androidx.compose.material3.NavigationDrawerItem(
                            icon = { Icon(icon, contentDescription = null, tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant) },
                            label = { Text(title, color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface) },
                            selected = isSelected,
                            colors = androidx.compose.material3.NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                unselectedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                            onClick = {
                                coroutineScope.launch { drawerState.close() }
                                if (title != "General Reminder") {
                                    if (title == "Birthday & Anniversary") {
                                        navController.navigate("birthday_anniversary")
                                    } else if (title == "Milage Calculator") {
                                        navController.navigate("milage_calculator")
                                    } else if (title == "My Notes") {
                                        navController.navigate("my_notes")
                                    } else if (title == "Age Calculator") {
                                        navController.navigate("age_calculator")
                                    } else if (title == "Photo Resizer") {
                                        navController.navigate("photo_resizer")
                                    } else if (title == "Text Scanner") {
                                        navController.navigate("text_scanner")
                                    } else if (title == "Documents Scanner") {
                                        navController.navigate("documents_scanner")
                                    } else if (title == "QR & Barcode Scanner") {
                                        navController.navigate("qr_barcode_scanner")
                                    } else if (title == "Secure Vault") {
                                        navController.navigate("secure_vault")
                                    } else {
                                        navController.navigate("placeholder/$title")
                                    }
                                }
                            },
                        )
                    }
                }
            }
        }
    ) {
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { navController.navigate("add_reminder") },
                    containerColor = MaterialTheme.colorScheme.onBackground,
                    contentColor = MaterialTheme.colorScheme.background,
                    modifier = Modifier.testTag("add_reminder_fab")
                ) {
                    Icon(Icons.Filled.Add, "Add Reminder")
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(androidx.compose.material.icons.Icons.Filled.Menu, contentDescription = "Open Drawer")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            LiveColorBanner(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .padding(vertical = 12.dp, horizontal = 16.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    MBBadge(modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("My Buddy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                        
                        // Dark Mode Toggle
                        IconButton(
                            onClick = { settingsViewModel.setDarkMode(!isDarkMode) },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.5f), shape = androidx.compose.foundation.shape.CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isDarkMode) androidx.compose.material.icons.Icons.Outlined.LightMode else androidx.compose.material.icons.Icons.Outlined.DarkMode,
                                contentDescription = "Toggle Dark Mode",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        // Sync Menu
                        Box {
                            IconButton(
                                onClick = { showSyncMenu = true },
                                modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.5f), shape = androidx.compose.foundation.shape.CircleShape)
                            ) {
                                Icon(Icons.Filled.Sync, "Data/Sync", tint = MaterialTheme.colorScheme.primary)
                            }
                            DropdownMenu(
                                expanded = showSyncMenu,
                                onDismissRequest = { showSyncMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Export Data (JSON)") },
                                    onClick = {
                                        showSyncMenu = false
                                        exportLauncher.launch("somnath_backup.json")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Import Data (JSON)") },
                                    onClick = {
                                        showSyncMenu = false
                                        importLauncher.launch(arrayOf("application/json"))
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Settings") },
                                    onClick = {
                                        showSyncMenu = false
                                        navController.navigate("settings")
                                    }
                                )
                            }
                        }
                    }
                }
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search tasks or locations...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true
                )
            }
            
            item {
                BentoDashboard(reminders, onMonthlySummaryClick = { navController.navigate("monthly_summary") })
            }
            
            item {
                val filters = listOf("All", "Upcoming Payment", "Udhar", "Personal Work")
                androidx.compose.foundation.lazy.LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filters.size) { index ->
                        val filter = filters[index]
                        val isSelected = selectedFilter == filter
                        Surface(
                            shape = androidx.compose.foundation.shape.CircleShape,
                            color = if (isSelected) MaterialTheme.colorScheme.onBackground else Color.Transparent,
                            border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.clickable { selectedFilter = filter }
                        ) {
                            Text(
                                text = filter,
                                color = if (isSelected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
            
            item {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("UPCOMING SCHEDULE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                    Text("View All (${reminders.size})", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
            }
            
            val filteredReminders = reminders.filter {
                val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                matchesSearch && matchesFilter
            }
            
            if (filteredReminders.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Text(if (searchQuery.isNotEmpty()) "No results found." else "No reminders yet. Add one to get started!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                val grouped = filteredReminders.groupBy { it.taskDate }
                val todayStr = LocalDate.now().toString()
                
                grouped.toSortedMap().forEach { (date, tasks) ->
                    val dateLabel = if (date == todayStr) "Today" else date
                    item {
                        Text(
                            text = dateLabel,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    items(tasks, key = { it.id }) { reminder ->
                        ReminderCard(
                            reminder = reminder,
                            onToggleCompletion = { viewModel.toggleCompletion(reminder.id, !reminder.isCompleted) },
                            onDelete = { reminderToDelete = reminder },
                            onClick = { navController.navigate("edit_reminder/${reminder.id}") }
                        )
                    }
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }
    }
}

@Composable
fun BentoDashboard(reminders: List<Reminder>, onMonthlySummaryClick: () -> Unit) {
    val now = LocalDateTime.now()
    val upcomingTasks = reminders.filter { !it.isCompleted }.filter {
        val dt = LocalDateTime.of(LocalDate.parse(it.taskDate), LocalTime.parse(it.taskTime))
        dt.isAfter(now)
    }.sortedBy { LocalDateTime.of(LocalDate.parse(it.taskDate), LocalTime.parse(it.taskTime)) }
    
    val nearestTask = upcomingTasks.firstOrNull()
    
    val currentYearMonth = YearMonth.now()
    var currentMonthPayment = 0.0
    var currentMonthLent = 0.0
    
    reminders.forEach { r ->
        val date = LocalDate.parse(r.taskDate)
        if (YearMonth.from(date) == currentYearMonth && r.amount != null) {
            if (r.category == "Upcoming Payment") currentMonthPayment += r.amount
            else if (r.category == "Money Lent (Udhar)") currentMonthLent += r.amount
        }
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        // Left Card: Nearest Upcoming
        Card(
            modifier = Modifier.weight(1f).aspectRatio(0.85f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                    Box(modifier = Modifier.size(36.dp).background(MaterialTheme.colorScheme.primary.copy(alpha=0.2f), shape = RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Icon(androidx.compose.material.icons.Icons.Outlined.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    }
                    Surface(color = MaterialTheme.colorScheme.primary.copy(alpha=0.15f), shape = RoundedCornerShape(16.dp)) {
                        Text("UPCOMING", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
                Spacer(modifier = Modifier.weight(1f))
                if (nearestTask != null) {
                    Text(nearestTask.taskTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("${nearestTask.taskDate} • ${nearestTask.taskTime}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                } else {
                    Text("No upcoming tasks", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        
        // Right Card: Finance
        Card(
            modifier = Modifier.weight(1f).aspectRatio(0.85f).clickable { onMonthlySummaryClick() },
            shape = RoundedCornerShape(24.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6))))) {
                Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Box(modifier = Modifier.size(36.dp).background(Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(androidx.compose.material.icons.Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Surface(color = Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(16.dp)) {
                            Text("FINANCE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    Text("Pay: ₹${currentMonthPayment.toInt()}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Lent: ₹${currentMonthLent.toInt()}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("View Breakdown →", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha=0.8f))
                }
            }
        }
    }
}

@Composable
fun ReminderCard(
    reminder: Reminder,
    onToggleCompletion: () -> Unit,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val categoryColor = when (reminder.category) {
        "Upcoming Payment" -> Color(0xFFE57373)
        "Money Lent (Udhar)" -> Color(0xFFFFB74D)
        "Personal Work" -> Color(0xFF64B5F6)
        else -> Color(0xFF9575CD) // Purple for Other
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.testTag("reminder_card_${reminder.id}")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left part: Radio button + Date
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = onToggleCompletion, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (reminder.isCompleted) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                        contentDescription = "Toggle completion",
                        tint = if (reminder.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                
                val dateStr = reminder.taskDate
                var monthStr = dateStr
                var dayStr = ""
                try {
                    val date = LocalDate.parse(dateStr)
                    monthStr = date.month.name.take(3).uppercase()
                    dayStr = String.format("%02d", date.dayOfMonth)
                } catch (e: Exception) {
                    // Ignore parsing error
                }
                
                if (dayStr.isNotEmpty()) {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(dayStr, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                } else {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall)
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Vertical Divider
            Box(modifier = Modifier.width(1.dp).height(80.dp).background(MaterialTheme.colorScheme.outlineVariant))
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Right part: Details
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = categoryColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = reminder.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = categoryColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (reminder.isAlarmEnabled) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = "Alarm On", modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = reminder.taskTime,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = reminder.taskTitle,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = if (reminder.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Delete task",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (reminder.tags.isNotBlank()) {
                        reminder.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).forEach { tag ->
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer, // red-ish background for tag in screenshot
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.padding(end = 6.dp)
                            ) {
                                Text(
                                    text = tag,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.weight(1f))
                    
                    if (reminder.amount != null) {
                        Text(
                            text = "₹${reminder.amount.toInt()}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error // red color for amount
                        )
                    }
                    
                    if (reminder.repeatInterval != "None") {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)) {
                                Icon(Icons.Filled.Sync, contentDescription = "Repeating", modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(reminder.repeatInterval, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    
                    if (reminder.category == "Money Lent (Udhar)" && reminder.amount != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                setPackage("com.whatsapp")
                                putExtra(Intent.EXTRA_TEXT, "Reminder: ₹${reminder.amount} is pending for ${reminder.taskTitle}.")
                            }
                            try {
                                context.startActivity(shareIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                            }
                        }, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = "Share to WhatsApp",
                                tint = Color(0xFF25D366), // WhatsApp Green
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                
                if (reminder.imageUri != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    AsyncImage(
                        model = reminder.imageUri,
                        contentDescription = "Attached Image",
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.LightGray)
                    )
                }
            }
        }
    }
}
