package com.example
import androidx.compose.material.icons.filled.FilterList

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color

import androidx.compose.animation.animateColor
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import coil.compose.AsyncImage
import android.content.Intent


@Composable
fun MBBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFFFACC15), Color(0xFFF97316)))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "MB",
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun LiveColorBanner(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val infiniteTransition = rememberInfiniteTransition()
    val color1 by infiniteTransition.animateColor(
        initialValue = Color(0xFF6366F1), // Indigo
        targetValue = Color(0xFFEC4899), // Pink
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Reverse)
    )
    val color2 by infiniteTransition.animateColor(
        initialValue = Color(0xFF3B82F6), // Blue
        targetValue = Color(0xFF8B5CF6), // Purple
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Reverse)
    )
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(color1, color2))),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, viewModel: ReminderViewModel, settingsViewModel: SettingsViewModel) {
    val remindersState = viewModel.uiState.collectAsStateWithLifecycle()

    val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
    val context = LocalContext.current
    
    var reminderToDelete by remember { mutableStateOf<Reminder?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showSyncMenu by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        val jsonArray = JSONArray()
                        remindersState.value.forEach { r ->
                            val obj = JSONObject()
                            obj.put("taskTitle", r.taskTitle)
                            obj.put("category", r.category)
                            obj.put("taskDate", r.taskDate)
                            obj.put("taskTime", r.taskTime)
                            obj.put("reminder2Date", r.reminder2Date ?: JSONObject.NULL)
                            obj.put("reminder2Time", r.reminder2Time ?: JSONObject.NULL)
                            obj.put("reminder3Date", r.reminder3Date ?: JSONObject.NULL)
                            obj.put("reminder3Time", r.reminder3Time ?: JSONObject.NULL)
                            obj.put("isCompleted", r.isCompleted)
                            obj.put("location", r.location)
                            obj.put("amount", r.amount ?: JSONObject.NULL)
                            obj.put("repeatInterval", r.repeatInterval)
                            obj.put("imageUri", r.imageUri ?: JSONObject.NULL)
                            obj.put("tags", r.tags)
                            jsonArray.put(obj)
                        }
                        writer.write(jsonArray.toString(2))
                    }
                }
                Toast.makeText(context, "Data exported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    InputStreamReader(inputStream).use { reader ->
                        val jsonStr = reader.readText()
                        val jsonArray = JSONArray(jsonStr)
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.getJSONObject(i)
                            val reminder = Reminder(
                                taskTitle = obj.getString("taskTitle"),
                                category = obj.getString("category"),
                                taskDate = obj.getString("taskDate"),
                                taskTime = obj.getString("taskTime"),
                                reminder2Date = if (obj.isNull("reminder2Date")) null else obj.getString("reminder2Date"),
                                reminder2Time = if (obj.isNull("reminder2Time")) null else obj.getString("reminder2Time"),
                                reminder3Date = if (obj.isNull("reminder3Date")) null else obj.getString("reminder3Date"),
                                reminder3Time = if (obj.isNull("reminder3Time")) null else obj.getString("reminder3Time"),
                                isCompleted = obj.getBoolean("isCompleted"),
                                location = obj.optString("location", ""),
                                amount = if (obj.isNull("amount")) null else obj.getDouble("amount"),
                                repeatInterval = obj.optString("repeatInterval", "None"),
                                imageUri = if (obj.isNull("imageUri")) null else obj.getString("imageUri"),
                                tags = obj.optString("tags", "")
                            )
                            viewModel.addReminder(reminder)
                        }
                    }
                }
                Toast.makeText(context, "Data imported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Import failed or invalid format", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    var selectedFilter by remember { mutableStateOf("All") }
    
    val drawerState = androidx.compose.material3.rememberDrawerState(initialValue = androidx.compose.material3.DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    
    if (reminderToDelete != null) {
        AlertDialog(
            onDismissRequest = { reminderToDelete = null },
            title = { Text("Delete Task") },
            text = { Text("Are you sure you want to delete '${reminderToDelete?.taskTitle}'?") },
            confirmButton = {
                TextButton(onClick = { 
                    reminderToDelete?.let { viewModel.deleteReminder(it) }
                    reminderToDelete = null
                }) { Text("Yes", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { reminderToDelete = null }) { Text("No") }
            }
        )
    }
    
    androidx.compose.material3.ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            androidx.compose.material3.ModalDrawerSheet {
                // Drawer Header
                LiveColorBanner(modifier = Modifier.height(180.dp)) {
                    Column(
                        modifier = Modifier.padding(16.dp).align(Alignment.BottomStart)
                    ) {
                        MBBadge(modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "My Buddy",
                            color = Color.White,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                val menuItems = listOf(
                    "General Reminder" to androidx.compose.material.icons.Icons.Rounded.CheckCircle,
                    "Birthday & Anniversary" to androidx.compose.material.icons.Icons.Rounded.Cake,
                    "Milage Calculator" to androidx.compose.material.icons.Icons.Rounded.DirectionsCar,
                    "My Notes" to androidx.compose.material.icons.Icons.Rounded.EditNote,
                    "Age Calculator" to androidx.compose.material.icons.Icons.Rounded.HourglassEmpty,
                    "Photo Resizer" to androidx.compose.material.icons.Icons.Rounded.PhotoSizeSelectLarge,
                    "Text Scanner" to androidx.compose.material.icons.Icons.Rounded.DocumentScanner,
                    "Documents Scanner" to androidx.compose.material.icons.Icons.Rounded.DocumentScanner,
                    "QR & Barcode Scanner" to androidx.compose.material.icons.Icons.Rounded.QrCodeScanner,
                    "Secure Vault" to androidx.compose.material.icons.Icons.Rounded.Lock
                )

        
        val filteredReminders by remember(searchQuery, selectedFilter) {
            androidx.compose.runtime.derivedStateOf {
                remindersState.value.filter {
                    val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                    val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                    matchesSearch && matchesFilter
                }
            }
        }
        val groupedAndSorted by remember(searchQuery, selectedFilter) {
            androidx.compose.runtime.derivedStateOf {
                filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }.toSortedMap()
            }
        }
        val todayStr = remember { LocalDate.now().toString() }
        
        LazyColumn(
modifier = Modifier.fillMaxSize()) {
                    items(menuItems, key = { it.first }, contentType = { "menu" }) { (title, icon) ->
                        val isSelected = title == "General Reminder"
                        androidx.compose.material3.NavigationDrawerItem(
                            icon = { Icon(icon, contentDescription = null, tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant) },
                            label = { Text(title, color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface) },
                            selected = isSelected,
                            colors = androidx.compose.material3.NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                unselectedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                            onClick = {
                                coroutineScope.launch { drawerState.close() }
                                if (title != "General Reminder") {
                                    if (title == "Birthday & Anniversary") {
                                        navController.navigate("birthday_anniversary")
                                    } else if (title == "Milage Calculator") {
                                        navController.navigate("milage_calculator")
                                    } else if (title == "My Notes") {
                                        navController.navigate("my_notes")
                                    } else if (title == "Age Calculator") {
                                        navController.navigate("age_calculator")
                                    } else if (title == "Photo Resizer") {
                                        navController.navigate("photo_resizer")
                                    } else if (title == "Text Scanner") {
                                        navController.navigate("text_scanner")
                                    } else if (title == "Documents Scanner") {
                                        navController.navigate("documents_scanner")
                                    } else if (title == "QR & Barcode Scanner") {
                                        navController.navigate("qr_barcode_scanner")
                                    } else if (title == "Secure Vault") {
                                        navController.navigate("secure_vault")
                                    } else if (title == "Document Expiry") {
                                        navController.navigate("document_expiry")
                                    } else {
                                        navController.navigate("placeholder/$title")
                                    }
                                }
                            },
                        )
                    }
                }
            }
        }
    ) {
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { navController.navigate("add_reminder") },
                    containerColor = MaterialTheme.colorScheme.onBackground,
                    contentColor = MaterialTheme.colorScheme.background,
                    modifier = Modifier.testTag("add_reminder_fab")
                ) {
                    Icon(Icons.Filled.Add, "Add Reminder")
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
    
        val filteredReminders by remember(searchQuery, selectedFilter) {
            androidx.compose.runtime.derivedStateOf {
                remindersState.value.filter {
                    val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                    val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                    matchesSearch && matchesFilter
                }
            }
        }
        val groupedAndSorted by remember(searchQuery, selectedFilter) {
            androidx.compose.runtime.derivedStateOf {
                filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }.toSortedMap()
            }
        }
        val todayStr = remember { LocalDate.now().toString() }
        
        LazyColumn(

                modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(androidx.compose.material.icons.Icons.Filled.Menu, contentDescription = "Open Drawer")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
                                Text("Hi Buddy", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                                Spacer(modifier = Modifier.width(8.dp))
                                
                                val infiniteTransition = rememberInfiniteTransition()
                                val rotation by infiniteTransition.animateFloat(
                                    initialValue = -10f,
                                    targetValue = 20f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(1000, easing = LinearEasing),
                                        repeatMode = RepeatMode.Reverse
                                    ),
                                    label = "WavingHand"
                                )
                                
                                Text(
                                    text = "👋",
                                    fontSize = 28.sp,
                                    modifier = Modifier.graphicsLayer(
                                        rotationZ = rotation,
                                        transformOrigin = TransformOrigin(0.7f, 0.7f)
                                    )
                                )
                            }
                        }
                        
                        IconButton(
                            onClick = { navController.navigate("global_search") },
                        ) {
                            Icon(Icons.Default.Search, "Search", tint = MaterialTheme.colorScheme.onSurface)
                        }
                        IconButton(
                            onClick = { settingsViewModel.setDarkMode(!isDarkMode) },
                        ) {
                            Icon(
                                imageVector = if (isDarkMode) androidx.compose.material.icons.Icons.Outlined.LightMode else androidx.compose.material.icons.Icons.Outlined.DarkMode,
                                contentDescription = "Toggle Dark Mode",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        IconButton(
                            onClick = { navController.navigate("whatsapp_scheduler") },
                        ) {
                            Icon(androidx.compose.material.icons.Icons.Default.Send, "WhatsApp Scheduler", tint = MaterialTheme.colorScheme.onSurface)
                        }
                        IconButton(
                            onClick = { navController.navigate("settings") },
                        ) {
                            Icon(Icons.Default.Settings, "Settings", tint = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            item {
                BentoDashboard(
                    remindersState = remindersState,
                    viewModel = viewModel,
                    onMonthlySummaryClick = { navController.navigate("monthly_summary") }
                )
            }
            
            item {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("UPCOMING SCHEDULE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("View All (${remindersState.value.size})", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { expanded = true }) {
                                Icon(Icons.Default.FilterList, contentDescription = "Filter")
                            }
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                listOf("All", "Upcoming Payment", "Udhar", "Personal Work", "Other").forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category) },
                                        onClick = { 
                                            selectedFilter = category
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            
            if (filteredReminders.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Text(if (searchQuery.isNotEmpty()) "No results found." else "No reminders yet. Add one to get started!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                groupedAndSorted.forEach { (date, tasks) ->
                    val dateLabel = if (date == todayStr) "Today" else date
                    item {
                        Text(
                            text = dateLabel,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    items(tasks, key = { it.id }, contentType = { "task" }) { reminder ->
                        ReminderCard(
                            reminder = reminder,
                            onToggleCompletion = { viewModel.toggleCompletion(reminder.id, !reminder.isCompleted) },
                            onDelete = { reminderToDelete = reminder },
                            onClick = { navController.navigate("edit_reminder/${reminder.id}") }
                        )
                    }
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }
    }
}

@Composable
fun BentoDashboard(
    remindersState: androidx.compose.runtime.State<List<Reminder>>,
    viewModel: ReminderViewModel,
    onMonthlySummaryClick: () -> Unit
) {
    val nearestBirthdayState by viewModel.nearestBirthday.collectAsStateWithLifecycle()
    val nearestAnniversaryState by viewModel.nearestAnniversary.collectAsStateWithLifecycle()
    val latestBikeMileageState by viewModel.latestBikeMileage.collectAsStateWithLifecycle()
    val latestCarMileageState by viewModel.latestCarMileage.collectAsStateWithLifecycle()
    
    val nearestBirthday = nearestBirthdayState
    val nearestAnniversary = nearestAnniversaryState
    val latestBikeMileage = latestBikeMileageState
    val latestCarMileage = latestCarMileageState
    val now = LocalDateTime.now()
    val bentoData by remember {
        androidx.compose.runtime.derivedStateOf {
            val remindersList = remindersState.value
            val upcomingTasks = remindersList.filter { !it.isCompleted }.filter {
                !it.getNextActiveReminder().isPassed
            }.sortedBy { it.getNextActiveReminder().dateTime }
            
            val firstTask = upcomingTasks.firstOrNull()
            
            val currentYearMonth = YearMonth.now()
            var payment = 0.0
            var lent = 0.0
            
            remindersList.forEach { r ->
                try {
                    val date = LocalDate.parse(r.taskDate)
                    if (YearMonth.from(date) == currentYearMonth && r.amount != null) {
                        if (r.category == "Upcoming Payment") payment += r.amount
                        else if (r.category == "Money Lent (Udhar)") lent += r.amount
                    }
                } catch (e: Exception) {}
            }
            Triple(firstTask, payment, lent)
        }
    }
    val nearestTask = bentoData.first
    val currentMonthPayment = bentoData.second
    val currentMonthLent = bentoData.third

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Row 1: Upcoming Task | Finance
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Nearest Upcoming
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Box(modifier = Modifier.size(28.dp).background(MaterialTheme.colorScheme.primary.copy(alpha=0.2f), shape = RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                            Icon(androidx.compose.material.icons.Icons.Outlined.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        }
                        Surface(color = MaterialTheme.colorScheme.primary.copy(alpha=0.15f), shape = RoundedCornerShape(12.dp)) {
                            Text("UPCOMING", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    if (nearestTask != null) {
                        Text(nearestTask.taskTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("${nearestTask.getNextActiveReminder().dateTime.toLocalDate()}", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                    } else {
                        Text("No upcoming tasks", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            
            // Right Card: Finance
            Card(
                modifier = Modifier.weight(1f).height(130.dp).clickable { onMonthlySummaryClick() },
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6))))) {
                    Column(modifier = Modifier.padding(12.dp).fillMaxSize()) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Box(modifier = Modifier.size(28.dp).background(Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                Icon(androidx.compose.material.icons.Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Surface(color = Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(12.dp)) {
                                Text("FINANCE", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        Text("Pay: ₹${currentMonthPayment.toInt()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("Lent: ₹${currentMonthLent.toInt()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("View Breakdown", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha=0.8f))
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.White.copy(alpha=0.8f), modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }
        
        // Row 2: Birthday | Anniversary
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Birthday
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.Cake, contentDescription = null, tint = Color(0xFFF43F5E), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Birthday", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (nearestBirthday != null) {
                        Text(nearestBirthday.first.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Text("${nearestBirthday.second} days left", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // Right Card: Anniversary
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.Favorite, contentDescription = null, tint = Color(0xFFEC4899), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Anniv.", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (nearestAnniversary != null) {
                        Text(nearestAnniversary.first.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Text("${nearestAnniversary.second} days left", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        
        // Row 3: Bike | Car
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Bike Mileage
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.TwoWheeler, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Bike", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (latestBikeMileage != null) {
                        Text("${String.format("%.1f", latestBikeMileage)} km/l", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Text("Last refuel", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // Right Card: Car Mileage
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.DirectionsCar, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Car", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (latestCarMileage != null) {
                        Text("${String.format("%.1f", latestCarMileage)} km/l", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Text("Last refuel", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
@Composable
fun ReminderCard(
    reminder: Reminder,
    onToggleCompletion: () -> Unit,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val categoryColor = when (reminder.category) {
        "Upcoming Payment" -> Color(0xFFE57373)
        "Money Lent (Udhar)" -> Color(0xFFFFB74D)
        "Personal Work" -> Color(0xFF64B5F6)
        else -> Color(0xFF9575CD) // Purple for Other
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.testTag("reminder_card_${reminder.id}")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val activeInfo = reminder.getNextActiveReminder()
            val dateStr = activeInfo.dateTime.toLocalDate().toString()
            val timeStr = String.format(java.util.Locale.getDefault(), "%02d:%02d", activeInfo.dateTime.hour, activeInfo.dateTime.minute)
            val alphaVal = if (activeInfo.isPassed) 0.4f else 1.0f

            // Left part: Radio button + Date
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = onToggleCompletion, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = if (reminder.isCompleted) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                        contentDescription = "Toggle completion",
                        tint = if (reminder.isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                
                val (monthStr, dayStr) = remember(dateStr) {
                    var mStr = dateStr
                    var dStr = ""
                    try {
                        val date = LocalDate.parse(dateStr)
                        mStr = date.month.name.take(3).uppercase()
                        dStr = String.format(java.util.Locale.getDefault(), "%02d", date.dayOfMonth)
                    } catch (e: Exception) {}
                    Pair(mStr, dStr)
                }
                
                if (dayStr.isNotEmpty()) {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal))
                    Text(dayStr, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alphaVal))
                } else {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alphaVal))
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Vertical Divider
            Box(modifier = Modifier.width(1.dp).height(80.dp).background(MaterialTheme.colorScheme.outlineVariant))
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Right part: Details
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = categoryColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = reminder.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = categoryColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (reminder.isAlarmEnabled) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = "Alarm On", modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = alphaVal))
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = timeStr,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = reminder.taskTitle,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = if (reminder.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Delete task",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (reminder.tags.isNotBlank()) {
                        reminder.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).forEach { tag ->
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer, // red-ish background for tag in screenshot
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.padding(end = 6.dp)
                            ) {
                                Text(
                                    text = tag,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.weight(1f))
                    
                    if (reminder.amount != null) {
                        Text(
                            text = "₹${reminder.amount.toInt()}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error // red color for amount
                        )
                    }
                    
                    if (reminder.repeatInterval != "None") {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)) {
                                Icon(Icons.Filled.Sync, contentDescription = "Repeating", modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(reminder.repeatInterval, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    
                    if (reminder.category == "Money Lent (Udhar)" && reminder.amount != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                setPackage("com.whatsapp")
                                putExtra(Intent.EXTRA_TEXT, "Reminder: ₹${reminder.amount} is pending for ${reminder.taskTitle}.")
                            }
                            try {
                                context.startActivity(shareIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                            }
                        }, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = "Share to WhatsApp",
                                tint = Color(0xFF25D366), // WhatsApp Green
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                
                if (reminder.imageUri != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    AsyncImage(
                        model = reminder.imageUri,
                        contentDescription = "Attached Image",
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.LightGray)
                    )
                }
            }
        }
    }
}
