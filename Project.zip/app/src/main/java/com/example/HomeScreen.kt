package com.example
import androidx.compose.material.icons.filled.FilterList

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color

import androidx.compose.animation.animateColor
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Lock
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import coil.compose.AsyncImage
import android.content.Intent


@Composable
fun MBBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFFFACC15), Color(0xFFF97316)))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "MB",
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun LiveColorBanner(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val infiniteTransition = rememberInfiniteTransition()
    val color1 by infiniteTransition.animateColor(
        initialValue = Color(0xFF6366F1), // Indigo
        targetValue = Color(0xFFEC4899), // Pink
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Reverse)
    )
    val color2 by infiniteTransition.animateColor(
        initialValue = Color(0xFF3B82F6), // Blue
        targetValue = Color(0xFF8B5CF6), // Purple
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Reverse)
    )
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(color1, color2))),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, viewModel: ReminderViewModel, settingsViewModel: SettingsViewModel, openDrawer: () -> Unit) {
    val remindersState = viewModel.uiState.collectAsStateWithLifecycle()

    val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
    val context = LocalContext.current
    
    var reminderToDelete by remember { mutableStateOf<Reminder?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showSyncMenu by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openOutputStream(it)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        val jsonArray = JSONArray()
                        remindersState.value.forEach { r ->
                            val obj = JSONObject()
                            obj.put("taskTitle", r.taskTitle)
                            obj.put("category", r.category)
                            obj.put("taskDate", r.taskDate)
                            obj.put("taskTime", r.taskTime)
                            obj.put("reminder2Date", r.reminder2Date ?: JSONObject.NULL)
                            obj.put("reminder2Time", r.reminder2Time ?: JSONObject.NULL)
                            obj.put("reminder3Date", r.reminder3Date ?: JSONObject.NULL)
                            obj.put("reminder3Time", r.reminder3Time ?: JSONObject.NULL)
                            obj.put("isCompleted", r.isCompleted)
                            obj.put("location", r.location)
                            obj.put("amount", r.amount ?: JSONObject.NULL)
                            obj.put("repeatInterval", r.repeatInterval)
                            obj.put("imageUri", r.imageUri ?: JSONObject.NULL)
                            obj.put("tags", r.tags)
                            jsonArray.put(obj)
                        }
                        writer.write(jsonArray.toString(2))
                    }
                }
                Toast.makeText(context, "Data exported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    InputStreamReader(inputStream).use { reader ->
                        val jsonStr = reader.readText()
                        val jsonArray = JSONArray(jsonStr)
                        for (i in 0 until jsonArray.length()) {
                            val obj = jsonArray.getJSONObject(i)
                            val reminder = Reminder(
                                taskTitle = obj.getString("taskTitle"),
                                category = obj.getString("category"),
                                taskDate = obj.getString("taskDate"),
                                taskTime = obj.getString("taskTime"),
                                reminder2Date = if (obj.isNull("reminder2Date")) null else obj.getString("reminder2Date"),
                                reminder2Time = if (obj.isNull("reminder2Time")) null else obj.getString("reminder2Time"),
                                reminder3Date = if (obj.isNull("reminder3Date")) null else obj.getString("reminder3Date"),
                                reminder3Time = if (obj.isNull("reminder3Time")) null else obj.getString("reminder3Time"),
                                isCompleted = obj.getBoolean("isCompleted"),
                                location = obj.optString("location", ""),
                                amount = if (obj.isNull("amount")) null else obj.getDouble("amount"),
                                repeatInterval = obj.optString("repeatInterval", "None"),
                                imageUri = if (obj.isNull("imageUri")) null else obj.getString("imageUri"),
                                tags = obj.optString("tags", "")
                            )
                            viewModel.addReminder(reminder)
                        }
                    }
                }
                Toast.makeText(context, "Data imported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Import failed or invalid format", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    var selectedFilter by remember { mutableStateOf("All") }
    
    if (reminderToDelete != null) {
        AlertDialog(
            onDismissRequest = { reminderToDelete = null },
            title = { Text("Delete Task") },
            text = { Text("Are you sure you want to delete '${reminderToDelete?.taskTitle}'?") },
            confirmButton = {
                TextButton(onClick = { 
                    reminderToDelete?.let { viewModel.deleteReminder(it) }
                    reminderToDelete = null
                }) { Text("Yes", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { reminderToDelete = null }) { Text("No") }
            }
        )
    }
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { navController.navigate("add_reminder") },
                    containerColor = MaterialTheme.colorScheme.onBackground,
                    contentColor = MaterialTheme.colorScheme.background,
                    modifier = Modifier.testTag("add_reminder_fab")
                ) {
                    Icon(Icons.Filled.Add, "Add Reminder")
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
    
        val filteredReminders by remember(searchQuery, selectedFilter, remindersState.value) {
            androidx.compose.runtime.derivedStateOf {
                remindersState.value.filter {
                    val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                    val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                    matchesSearch && matchesFilter
                }
            }
        }
        val activeTasks by remember(filteredReminders) {
            androidx.compose.runtime.derivedStateOf {
                filteredReminders.filter { !it.isCompleted }.sortedBy { it.getNextActiveReminder().dateTime }
            }
        }
        val completedTasks by remember(filteredReminders) {
            androidx.compose.runtime.derivedStateOf {
                filteredReminders.filter { it.isCompleted }.sortedByDescending { it.getNextActiveReminder().dateTime }
            }
        }
        val todayStr = remember { LocalDate.now().toString() }
        
        LazyColumn(

                modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = openDrawer,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Menu",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Hi Buddy", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            val infiniteTransition = rememberInfiniteTransition()
                            val rotation by infiniteTransition.animateFloat(
                                initialValue = -10f,
                                targetValue = 20f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1000, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "WavingHand"
                            )
                            
                            Text(
                                text = "👋",
                                fontSize = 28.sp,
                                modifier = Modifier.graphicsLayer(
                                    rotationZ = rotation,
                                    transformOrigin = TransformOrigin(0.7f, 0.7f)
                                )
                            )
                        }
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(0.dp)
                        ) {
                            IconButton(
                                onClick = { navController.navigate("global_search") },
                            ) {
                                Icon(Icons.Default.Search, "Search", tint = MaterialTheme.colorScheme.onSurface)
                            }
                            IconButton(
                                onClick = { navController.navigate("secure_vault") },
                            ) {
                                Icon(Icons.Default.Lock, "Secure Vault", tint = MaterialTheme.colorScheme.onSurface)
                            }
                            IconButton(
                                onClick = { navController.navigate("settings") },
                            ) {
                                Icon(Icons.Default.Settings, "Settings", tint = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            item {
                BentoDashboard(
                    remindersState = remindersState,
                    viewModel = viewModel,
                    onMonthlySummaryClick = { navController.navigate("monthly_summary") }
                )
            }
            
            item {
                val selectedCategory = selectedFilter
                val filteredTasks = filteredReminders
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("UPCOMING SCHEDULE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (selectedCategory == "All") "All (${filteredTasks.size})" else "$selectedCategory (${filteredTasks.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { expanded = true }) {
                                Icon(Icons.Default.FilterList, contentDescription = "Filter")
                            }
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                listOf("All", "Upcoming Payment", "Udhar", "Personal Work", "Other").forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category) },
                                        onClick = { 
                                            selectedFilter = category
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            
            if (filteredReminders.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Text(if (searchQuery.isNotEmpty()) "No results found." else "No reminders yet. Add one to get started!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                items(activeTasks, key = { it.id }, contentType = { "task" }) { reminder ->
                    ReminderCard(
                        reminder = reminder,
                        onToggleCompletion = { viewModel.toggleCompletion(reminder.id, !reminder.isCompleted) },
                        onDelete = { reminderToDelete = reminder },
                        onClick = { navController.navigate("edit_reminder/${reminder.id}") }
                    )
                }

                if (completedTasks.isNotEmpty()) {
                    item {
                        Text(
                            text = "Completed",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                        )
                    }
                    items(completedTasks, key = { it.id }, contentType = { "task" }) { reminder ->
                        ReminderCard(
                            reminder = reminder,
                            onToggleCompletion = { viewModel.toggleCompletion(reminder.id, !reminder.isCompleted) },
                            onDelete = { reminderToDelete = reminder },
                            onClick = { navController.navigate("edit_reminder/${reminder.id}") }
                        )
                    }
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
fun BentoDashboard(
    remindersState: androidx.compose.runtime.State<List<Reminder>>,
    viewModel: ReminderViewModel,
    onMonthlySummaryClick: () -> Unit
) {
    val nearestBirthdayState by viewModel.nearestBirthday.collectAsStateWithLifecycle()
    val nearestAnniversaryState by viewModel.nearestAnniversary.collectAsStateWithLifecycle()
    val latestBikeMileageState by viewModel.latestBikeMileage.collectAsStateWithLifecycle()
    val latestCarMileageState by viewModel.latestCarMileage.collectAsStateWithLifecycle()
    val bikeServiceRecordState by viewModel.bikeServiceRecord.collectAsStateWithLifecycle()
    val carServiceRecordState by viewModel.carServiceRecord.collectAsStateWithLifecycle()
    val currentMonthPayVal by viewModel.currentMonthPay.collectAsStateWithLifecycle()
    val currentMonthLentVal by viewModel.currentMonthLent.collectAsStateWithLifecycle()
    
    val nearestBirthday = nearestBirthdayState
    val nearestAnniversary = nearestAnniversaryState
    val latestBikeMileage = latestBikeMileageState
    val latestCarMileage = latestCarMileageState
    val bikeServiceRecord = bikeServiceRecordState
    val carServiceRecord = carServiceRecordState
    val now = LocalDateTime.now()
    val bentoData by remember(remindersState.value, currentMonthPayVal, currentMonthLentVal) {
        androidx.compose.runtime.derivedStateOf {
            val remindersList = remindersState.value
            val upcomingTasks = remindersList.filter { !it.isCompleted }.sortedBy { it.getNextActiveReminder().dateTime }
            
            val firstTask = upcomingTasks.firstOrNull()
            
            Triple(firstTask, currentMonthPayVal, currentMonthLentVal)
        }
    }
    val nearestTask = bentoData.first
    val totalPay = bentoData.second
    val totalLent = bentoData.third

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Row 1: Upcoming Task | Finance
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Nearest Upcoming
            Card(
                modifier = Modifier.weight(1f).height(160.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFF00B4DB), Color(0xFF0083B0))))) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.Top
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(28.dp).background(Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                Icon(androidx.compose.material.icons.Icons.Outlined.CalendarToday, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Surface(color = Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(12.dp)) {
                                Text("UPCOMING", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp)) // drastically reduced vertical gap/Spacer
                        
                        if (nearestTask != null) {
                            Column {
                                Text(
                                    text = nearestTask.taskTitle,
                                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 16.sp), // increased size
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 2,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                val activeReminder = nearestTask.getNextActiveReminder()
                                val localDate = activeReminder.dateTime.toLocalDate()
                                val localTime = activeReminder.dateTime.toLocalTime()
                                Text(
                                    text = "$localDate • $localTime",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp), // increased size
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        } else {
                            Text(
                                text = "No pending task",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp), // increased size
                                color = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
            
            // Right Card: Finance
            Card(
                modifier = Modifier.weight(1f).height(160.dp).clickable { onMonthlySummaryClick() },
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6))))) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.Top
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(28.dp).background(Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                Icon(androidx.compose.material.icons.Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Surface(color = Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(12.dp)) {
                                Text("FINANCE", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Column {
                            Text("Pay: ₹${totalPay.toInt()}", style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp), fontWeight = FontWeight.Bold, color = Color.White)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("Lent: ₹${totalLent.toInt()}", style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp), fontWeight = FontWeight.Bold, color = Color(0xFF69F0AE))
                        }
                        
                        Spacer(modifier = Modifier.weight(1f))
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("View Breakdown", style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp), color = Color.White.copy(alpha=0.9f))
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.White.copy(alpha=0.9f), modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }
        
        // Row 2: Birthday | Anniversary
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Birthday
            Card(
                modifier = Modifier.weight(1f).height(160.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFFEC4899), Color(0xFFBE185D))))) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.Top,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(androidx.compose.material.icons.Icons.Rounded.Cake, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Birthday", style = MaterialTheme.typography.labelSmall.copy(fontSize = 22.sp), fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        if (nearestBirthday != null) {
                            val event = nearestBirthday.first
                            val daysLeft = nearestBirthday.second
                            val daysText = if (daysLeft == 0L) "🎉 Today" else "$daysLeft Days Left"
                            val daysColor = if (daysLeft == 0L) Color(0xFFFFEB3B) else Color.White
                            
                            Text(
                                text = event.name,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 16.sp), // increased Name font size
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = event.relationship,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = Color.White.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = event.date,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp), // increased Date font size
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.9f),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = daysText,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                fontWeight = FontWeight.Bold,
                                color = daysColor,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "No upcoming",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp),
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.7f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            // Right Card: Anniversary
            Card(
                modifier = Modifier.weight(1f).height(160.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFFFF9800), Color(0xFFF4511E))))) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.Top,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(androidx.compose.material.icons.Icons.Rounded.Favorite, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Anniversary", style = MaterialTheme.typography.labelSmall.copy(fontSize = 22.sp), fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        if (nearestAnniversary != null) {
                            val event = nearestAnniversary.first
                            val daysLeft = nearestAnniversary.second
                            val daysText = if (daysLeft == 0L) "🎉 Today" else "$daysLeft Days Left"
                            val daysColor = if (daysLeft == 0L) Color(0xFFFFEB3B) else Color.White
                            
                            Text(
                                text = event.name,
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 16.sp), // increased Name font size
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = event.relationship,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = Color.White.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = event.date,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp), // increased Date font size
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.9f),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = daysText,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                fontWeight = FontWeight.Bold,
                                color = daysColor,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "No upcoming",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp),
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.7f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        
        // Row 3: Bike | Car
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Bike Mileage
            Card(
                modifier = Modifier.weight(1f).height(160.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFF10B981), Color(0xFF059669))))) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(androidx.compose.material.icons.Icons.Rounded.TwoWheeler, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Bike", style = MaterialTheme.typography.labelSmall.copy(fontSize = 22.sp), fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.weight(1f)
                        ) {
                            val mileageText = if (latestBikeMileage != null) {
                                String.format(java.util.Locale.getDefault(), "%.1f km/l", latestBikeMileage)
                            } else {
                                "0.0 km/l"
                            }
                            Text(
                                text = mileageText,
                                style = MaterialTheme.typography.titleLarge.copy(fontSize = 24.sp),
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val serviceDateText = if (bikeServiceRecord != null && bikeServiceRecord.nextServiceDate != "Not set" && bikeServiceRecord.nextServiceDate.isNotEmpty()) {
                                "Next service: ${bikeServiceRecord.nextServiceDate}"
                            } else {
                                "No service set"
                            }
                            Text(
                                text = serviceDateText,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                                color = Color.White.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
            // Right Card: Car Mileage
            Card(
                modifier = Modifier.weight(1f).height(160.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFF9C27B0), Color(0xFF6A1B9A))))) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(androidx.compose.material.icons.Icons.Rounded.DirectionsCar, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Car", style = MaterialTheme.typography.labelSmall.copy(fontSize = 22.sp), fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.weight(1f)
                        ) {
                            val mileageText = if (latestCarMileage != null) {
                                String.format(java.util.Locale.getDefault(), "%.1f km/l", latestCarMileage)
                            } else {
                                "0.0 km/l"
                            }
                            Text(
                                text = mileageText,
                                style = MaterialTheme.typography.titleLarge.copy(fontSize = 24.sp),
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val serviceDateText = if (carServiceRecord != null && carServiceRecord.nextServiceDate != "Not set" && carServiceRecord.nextServiceDate.isNotEmpty()) {
                                "Next service: ${carServiceRecord.nextServiceDate}"
                            } else {
                                "No service set"
                            }
                            Text(
                                text = serviceDateText,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                                color = Color.White.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun ReminderCard(
    reminder: Reminder,
    onToggleCompletion: () -> Unit,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val categoryColor = when (reminder.category) {
        "Upcoming Payment" -> Color(0xFFE57373)
        "Money Lent (Udhar)" -> Color(0xFFFFB74D)
        "Personal Work" -> Color(0xFF64B5F6)
        else -> Color(0xFF9575CD) // Purple for Other
    }

    val isOverdue = remember(reminder) {
        !reminder.isCompleted && try {
            val scheduledDt = java.time.LocalDateTime.of(
                java.time.LocalDate.parse(reminder.taskDate),
                java.time.LocalTime.parse(reminder.taskTime)
            )
            val scheduledMillis = scheduledDt.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
            scheduledMillis < System.currentTimeMillis()
        } catch (e: Exception) {
            false
        }
    }

    val cardBgColor = if (isOverdue) Color(0xFFFFEBEE) else MaterialTheme.colorScheme.surfaceVariant

    Card(
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (reminder.isCompleted) Modifier.alpha(0.5f) else Modifier)
            .clickable { onClick() }
            .testTag("reminder_card_${reminder.id}")
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .then(if (isOverdue) Modifier.alpha(0.5f) else Modifier),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val activeInfo = reminder.getNextActiveReminder()
            val dateStr = activeInfo.dateTime.toLocalDate().toString()
            val timeStr = String.format(java.util.Locale.getDefault(), "%02d:%02d", activeInfo.dateTime.hour, activeInfo.dateTime.minute)
            val alphaVal = if (activeInfo.isPassed) 0.4f else 1.0f

            // Left part: Checkbox + Date
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Checkbox(
                    checked = reminder.isCompleted,
                    onCheckedChange = { onToggleCompletion() },
                    modifier = Modifier.size(32.dp).testTag("reminder_checkbox_${reminder.id}")
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                val (monthStr, dayStr) = remember(dateStr) {
                    var mStr = dateStr
                    var dStr = ""
                    try {
                        val date = LocalDate.parse(dateStr)
                        mStr = date.month.name.take(3).uppercase()
                        dStr = String.format(java.util.Locale.getDefault(), "%02d", date.dayOfMonth)
                    } catch (e: Exception) {}
                    Pair(mStr, dStr)
                }
                
                if (dayStr.isNotEmpty()) {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal))
                    Text(dayStr, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alphaVal))
                } else {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alphaVal))
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Vertical Divider
            Box(modifier = Modifier.width(1.dp).height(80.dp).background(MaterialTheme.colorScheme.outlineVariant))
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Right part: Details
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = categoryColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = reminder.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = categoryColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (reminder.isAlarmEnabled) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = "Alarm On", modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = alphaVal))
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = timeStr,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = reminder.taskTitle,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = if (reminder.isCompleted) Color.Gray else MaterialTheme.colorScheme.onSurface,
                        textDecoration = if (reminder.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Delete task",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (reminder.tags.isNotBlank()) {
                        reminder.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).forEach { tag ->
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer, // red-ish background for tag in screenshot
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.padding(end = 6.dp)
                            ) {
                                Text(
                                    text = tag,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.weight(1f))
                    
                    if (reminder.amount != null) {
                        Text(
                            text = "₹${reminder.amount.toInt()}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (reminder.category == "Money Lent (Udhar)") Color(0xFF4CAF50) else MaterialTheme.colorScheme.error
                        )
                    }
                    
                    if (reminder.repeatInterval != "None") {
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)) {
                                Icon(Icons.Filled.Sync, contentDescription = "Repeating", modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(reminder.repeatInterval, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    
                    if (reminder.category == "Money Lent (Udhar)" && reminder.amount != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                setPackage("com.whatsapp")
                                putExtra(Intent.EXTRA_TEXT, "Reminder: ₹${reminder.amount} is pending for ${reminder.taskTitle}.")
                            }
                            try {
                                context.startActivity(shareIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                            }
                        }, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = "Share to WhatsApp",
                                tint = Color(0xFF25D366), // WhatsApp Green
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                
                if (reminder.imageUri != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    AsyncImage(
                        model = reminder.imageUri,
                        contentDescription = "Attached Image",
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.LightGray)
                    )
                }
            }
        }
    }
}
