package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class DocumentExpiryAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        val wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "SecureVault:DocExpiryWakeLock")
        wakeLock.acquire(5 * 1000L)
        try {
            val docName = intent.getStringExtra("docName") ?: return
            val docId = intent.getIntExtra("docId", -1)
            val daysLeft = intent.getIntExtra("daysLeft", -1)

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "Channel_Document_Expiry"

            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "Document Expiry Alerts",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "High priority audible alerts for expiring documents"
                    setSound(soundUri, null)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(1000, 1000, 1000, 1000, 1000)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val (title, text) = when (daysLeft) {
                0 -> "DOCUMENT EXPIRING TODAY!" to "Your document '$docName' expires today! Please renew it immediately."
                1 -> "Document Expiring Tomorrow" to "Your document '$docName' expires tomorrow. Please ensure renewal is in progress."
                7 -> "Document Expiring in 7 Days" to "Your document '$docName' will expire in 7 days."
                else -> "Document Expiry Alert" to "Your document '$docName' is expiring soon."
            }

            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(soundUri)
                .setVibrate(longArrayOf(1000, 1000, 1000, 1000, 1000))
                .setAutoCancel(true)
                .build()

            notificationManager.notify(docId, notification)
        } finally {
            try {
                if (wakeLock.isHeld) {
                    wakeLock.release()
                }
            } catch (e: Exception) {}
        }
    }
}
