package com.example

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders WHERE isDeleted = 1 ORDER BY taskDate ASC, taskTime ASC")
    fun getTrashedReminders(): Flow<List<Reminder>>
    @Query("SELECT * FROM reminders WHERE isDeleted = 0 ORDER BY taskDate ASC, taskTime ASC")
    fun getAllReminders(): Flow<List<Reminder>>
    @Query("SELECT * FROM reminders WHERE taskDate = :date AND isDeleted = 0")
    fun getRemindersForDateSync(date: String): List<Reminder>

    @Query("SELECT * FROM reminders WHERE isDeleted = 0 AND isCompleted = 0 AND (category = 'Upcoming Payment' OR category = 'Money Lent (Udhar)')")
    fun getFinanceRemindersSync(): List<Reminder>


    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun getReminderById(id: Int): Reminder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: Reminder): Long

    @androidx.room.Update
    suspend fun updateReminder(reminder: Reminder)

    @Query("UPDATE reminders SET isCompleted = :isCompleted WHERE id = :id")
    suspend fun updateCompletionStatus(id: Int, isCompleted: Boolean)

    @Query("UPDATE reminders SET isDeleted = 1 WHERE id = :id")
    suspend fun deleteReminderById(id: Int)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun permanentlyDeleteReminderById(id: Int)

    @Query("UPDATE reminders SET isDeleted = 0 WHERE id = :id")
    suspend fun restoreReminderById(id: Int)
}
