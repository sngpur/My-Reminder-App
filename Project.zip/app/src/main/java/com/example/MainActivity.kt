package com.example

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import com.example.MorningBriefingScheduler
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.foundation.layout.padding
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue

import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        // handle permission granted or not
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MorningBriefingScheduler(this).scheduleDailyBriefing()
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        
        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !powerManager.isIgnoringBatteryOptimizations(packageName)) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Allow Background Activity")
                .setMessage("To ensure alarms ring precisely on time, please allow My Buddy to run in the background.")
                .setPositiveButton("OK") { _, _ ->
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = android.net.Uri.parse("package:$packageName")
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }


        setContent {
            val settingsViewModel: SettingsViewModel = viewModel { SettingsViewModel(application) }
            val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()

            MyApplicationTheme(isDarkModeOverride = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SomnathReminderApp(settingsViewModel)
                }
            }
        }
    }
}

@Composable
fun SomnathReminderApp(settingsViewModel: SettingsViewModel) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val db = AppDatabase.getDatabase(context)
    val repository = ReminderRepository(db.reminderDao())
    
    val factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return ReminderViewModel(application, repository) as T
        }
    }
    
    val viewModel: ReminderViewModel = viewModel(factory = factory)
    val initialRoute = (context as? android.app.Activity)?.intent?.getStringExtra("route") ?: "home"
    val navController = rememberNavController()

        androidx.compose.runtime.LaunchedEffect(initialRoute) {
        if (initialRoute != "home") {
            navController.navigate(initialRoute)
        }
    }

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(navController = navController, viewModel = viewModel, settingsViewModel = settingsViewModel)
        }
        composable("global_search") {
            GlobalSearchScreen(navController = navController)
        }
        composable("add_reminder") {
            AddReminderScreen(navController = navController, viewModel = viewModel)
        }
        composable("edit_reminder/{id}") { backStackEntry ->
            val idStr = backStackEntry.arguments?.getString("id")
            val id = idStr?.toIntOrNull()
            AddReminderScreen(navController = navController, viewModel = viewModel, reminderId = id)
        }
        composable("monthly_summary") {
            MonthlySummaryScreen(navController = navController, viewModel = viewModel)
        }
        composable("settings") {
            SettingsScreen(navController = navController, settingsViewModel = settingsViewModel, reminderViewModel = viewModel)
        }
        composable("birthday_anniversary") {
            val eventViewModel: EventViewModel = viewModel { EventViewModel(application) }
            BirthdayAnniversaryScreen(navController = navController, eventViewModel = eventViewModel)
        }
        composable("milage_calculator") {
            val milageViewModel: MilageViewModel = viewModel { MilageViewModel(application) }
            MilageCalculatorScreen(navController = navController, viewModel = milageViewModel)
        }
        composable("my_notes") {
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            MyNotesScreen(navController = navController, viewModel = noteViewModel)
        }
        composable(
            "note_editor_text?noteId={noteId}",
            arguments = listOf(androidx.navigation.navArgument("noteId") { type = androidx.navigation.NavType.StringType; nullable = true })
        ) { backStackEntry ->
            val noteIdStr = backStackEntry.arguments?.getString("noteId")
            val noteId = noteIdStr?.toIntOrNull()
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteTextEditorScreen(navController = navController, viewModel = noteViewModel, noteId = noteId)
        }


        composable(
            "note_editor_drawing?noteId={noteId}",
            arguments = listOf(androidx.navigation.navArgument("noteId") { type = androidx.navigation.NavType.StringType; nullable = true })
        ) { backStackEntry ->
            val noteIdStr = backStackEntry.arguments?.getString("noteId")
            val noteId = noteIdStr?.toIntOrNull()
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteDrawingEditorScreen(navController = navController, viewModel = noteViewModel, noteId = noteId)
        }
        composable("age_calculator") {
            AgeCalculatorScreen(navController = navController)
        }
        composable("photo_resizer") {
            PhotoResizerScreen(navController = navController)
        }
        composable("documents_scanner") {
            val documentScannerViewModel: DocumentScannerViewModel = viewModel { DocumentScannerViewModel(application) }
            DocumentScannerScreen(navController = navController, viewModel = documentScannerViewModel)
        }
        composable("text_scanner") {
            val scannedTextViewModel: ScannedTextViewModel = viewModel { ScannedTextViewModel(application) }
            TextScannerScreen(navController = navController, viewModel = scannedTextViewModel)
        }
        composable("qr_barcode_scanner") {
            val qrBarcodeViewModel: QrBarcodeViewModel = viewModel { QrBarcodeViewModel(application) }
            QrBarcodeScreen(navController = navController, viewModel = qrBarcodeViewModel)
        }
        composable("secure_vault") {
            val secureVaultViewModel: SecureVaultViewModel = viewModel { SecureVaultViewModel(application) }
            SecureVaultScreen(navController = navController, viewModel = secureVaultViewModel)
        }
        composable("whatsapp_scheduler") {
            val whatsappViewModel: WhatsAppViewModel = viewModel { WhatsAppViewModel(application) }
            WhatsAppSchedulerScreen(navController = navController, viewModel = whatsappViewModel)
        }
        composable("document_expiry") {
            val docViewModel: DocumentExpiryViewModel = viewModel { DocumentExpiryViewModel(application) }
            DocumentExpiryScreen(navController = navController, viewModel = docViewModel)
        }
        composable("placeholder/{title}") { backStackEntry ->
            val title = backStackEntry.arguments?.getString("title") ?: "Coming Soon"
            PlaceholderScreen(navController = navController, title = title)
        }
        composable(
            "notification_details/{entityType}/{entityId}?isAlarmRinging={isAlarmRinging}",
            arguments = listOf(
                androidx.navigation.navArgument("entityType") { type = androidx.navigation.NavType.StringType },
                androidx.navigation.navArgument("entityId") { type = androidx.navigation.NavType.IntType },
                androidx.navigation.navArgument("isAlarmRinging") { type = androidx.navigation.NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val entityType = backStackEntry.arguments?.getString("entityType") ?: ""
            val entityId = backStackEntry.arguments?.getInt("entityId") ?: 0
            val isAlarmRinging = backStackEntry.arguments?.getBoolean("isAlarmRinging") ?: false
            NotificationDetailsScreen(
                navController = navController,
                entityId = entityId,
                entityType = entityType,
                initialIsAlarmRinging = isAlarmRinging
            )
        }
    }
}

@Composable
fun PlaceholderScreen(navController: androidx.navigation.NavController, title: String) {
    androidx.compose.material3.Scaffold(
        topBar = {
            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
            androidx.compose.material3.TopAppBar(
                title = { androidx.compose.material3.Text(title) },
                navigationIcon = {
                    androidx.compose.material3.IconButton(onClick = { navController.navigateUp() }) {
                        androidx.compose.material3.Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            androidx.compose.material3.Text(
                text = "Coming Soon",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
