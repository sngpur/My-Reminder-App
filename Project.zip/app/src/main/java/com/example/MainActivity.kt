package com.example

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import com.example.MorningBriefingScheduler
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.rounded.*
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.lazy.items
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue

import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {

    private val showQuickAddMenu = androidx.compose.runtime.mutableStateOf(false)
    private val routeToNavigate = androidx.compose.runtime.mutableStateOf<String?>(null)

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        // handle permission granted or not
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("OPEN_QUICK_ADD", false)) {
            showQuickAddMenu.value = true
        }
        intent.getStringExtra("route")?.let {
            routeToNavigate.value = it
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MorningBriefingScheduler(this).scheduleDailyBriefing()
        enableEdgeToEdge()

        if (intent.getBooleanExtra("OPEN_QUICK_ADD", false)) {
            showQuickAddMenu.value = true
        }
        intent.getStringExtra("route")?.let {
            routeToNavigate.value = it
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        
        val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !powerManager.isIgnoringBatteryOptimizations(packageName)) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Allow Background Activity")
                .setMessage("To ensure alarms ring precisely on time, please allow My Buddy to run in the background.")
                .setPositiveButton("OK") { _, _ ->
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = android.net.Uri.parse("package:$packageName")
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }


        setContent {
            val settingsViewModel: SettingsViewModel = viewModel { SettingsViewModel(application) }
            val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()

            MyApplicationTheme(isDarkModeOverride = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SomnathReminderApp(
                        settingsViewModel = settingsViewModel,
                        showQuickAdd = showQuickAddMenu.value,
                        onDismissQuickAdd = { showQuickAddMenu.value = false },
                        routeToNavigate = routeToNavigate.value,
                        onRouteHandled = { routeToNavigate.value = null }
                    )
                }
            }
        }
    }
}

@Composable
fun SomnathReminderApp(
    settingsViewModel: SettingsViewModel,
    showQuickAdd: Boolean = false,
    onDismissQuickAdd: () -> Unit = {},
    routeToNavigate: String? = null,
    onRouteHandled: () -> Unit = {}
) {
    val context = LocalContext.current
    val application = context.applicationContext as Application
    val db = AppDatabase.getDatabase(context)
    val repository = ReminderRepository(db.reminderDao())
    
    val factory = object : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return ReminderViewModel(application, repository) as T
        }
    }
    
    val viewModel: ReminderViewModel = viewModel(factory = factory)
    val initialRoute = (context as? android.app.Activity)?.intent?.getStringExtra("route") ?: "home"
    val navController = rememberNavController()

    androidx.compose.runtime.LaunchedEffect(initialRoute) {
        if (initialRoute != "home") {
            navController.navigate(initialRoute)
        }
    }

    androidx.compose.runtime.LaunchedEffect(routeToNavigate) {
        if (routeToNavigate != null && routeToNavigate != "home") {
            navController.navigate(routeToNavigate) {
                launchSingleTop = true
            }
            onRouteHandled()
        }
    }

    if (showQuickAdd) {
        QuickAddMenuDialog(
            onDismiss = onDismissQuickAdd,
            onNavigate = { route ->
                onDismissQuickAdd()
                navController.navigate(route)
            }
        )
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val openDrawer: () -> Unit = { coroutineScope.launch { drawerState.open() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                com.example.LiveColorBanner(modifier = Modifier.height(180.dp)) {
                    Column(
                        modifier = Modifier.padding(16.dp).align(Alignment.BottomStart)
                    ) {
                        com.example.MBBadge(modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "My Buddy",
                            color = Color.White,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                val menuItems = listOf(
                    "General Reminder" to Icons.Rounded.CheckCircle,
                    "Birthday & Anniversary" to Icons.Rounded.Cake,
                    "Milage Calculator" to Icons.Rounded.DirectionsCar,
                    "My Notes" to Icons.Rounded.EditNote,
                    "Document Expiry" to Icons.Rounded.Timer,
                    "Age Calculator" to Icons.Rounded.HourglassEmpty,
                    "Photo Resizer" to Icons.Rounded.PhotoSizeSelectLarge,
                    "Text Scanner" to Icons.Rounded.DocumentScanner,
                    "Documents Scanner" to Icons.Rounded.DocumentScanner,
                    "QR & Barcode Scanner" to Icons.Rounded.QrCodeScanner,
                    "Secure Vault" to Icons.Rounded.Lock
                )

                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(menuItems, key = { it.first }) { (title, icon) ->
                        val isSelected = when (title) {
                            "General Reminder" -> currentRoute == "home"
                            "Birthday & Anniversary" -> currentRoute == "birthday_anniversary"
                            "Milage Calculator" -> currentRoute == "milage_calculator"
                            "My Notes" -> currentRoute == "my_notes"
                            "Age Calculator" -> currentRoute == "age_calculator"
                            "Photo Resizer" -> currentRoute == "photo_resizer"
                            "Text Scanner" -> currentRoute == "text_scanner"
                            "Documents Scanner" -> currentRoute == "documents_scanner"
                            "QR & Barcode Scanner" -> currentRoute == "qr_barcode_scanner"
                            "Secure Vault" -> currentRoute == "secure_vault"
                            "Document Expiry" -> currentRoute == "document_expiry"
                            else -> false
                        }
                        NavigationDrawerItem(
                            icon = { Icon(icon, contentDescription = null, tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant) },
                            label = { Text(title, color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface) },
                            selected = isSelected,
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                unselectedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                            onClick = {
                                coroutineScope.launch { drawerState.close() }
                                if (title == "General Reminder") {
                                    if (currentRoute != "home") {
                                        navController.navigate("home") {
                                            popUpTo("home") { inclusive = true }
                                        }
                                    }
                                } else {
                                    val route = when (title) {
                                        "Birthday & Anniversary" -> "birthday_anniversary"
                                        "Milage Calculator" -> "milage_calculator"
                                        "My Notes" -> "my_notes"
                                        "Age Calculator" -> "age_calculator"
                                        "Photo Resizer" -> "photo_resizer"
                                        "Text Scanner" -> "text_scanner"
                                        "Documents Scanner" -> "documents_scanner"
                                        "QR & Barcode Scanner" -> "qr_barcode_scanner"
                                        "Secure Vault" -> "secure_vault"
                                        "Document Expiry" -> "document_expiry"
                                        else -> "placeholder/$title"
                                    }
                                    if (currentRoute != route) {
                                        navController.navigate(route) {
                                            popUpTo("home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) {
        NavHost(navController = navController, startDestination = "home") {
            composable("home") {
                HomeScreen(navController = navController, viewModel = viewModel, settingsViewModel = settingsViewModel, openDrawer = openDrawer)
            }
            composable("global_search") {
                val searchViewModel: GlobalSearchViewModel = viewModel { GlobalSearchViewModel(application) }
                GlobalSearchScreen(navController = navController, viewModel = searchViewModel)
            }
            composable("add_reminder") {
                AddReminderScreen(navController = navController, viewModel = viewModel)
            }
            composable("edit_reminder/{id}") { backStackEntry ->
                val idStr = backStackEntry.arguments?.getString("id")
                val id = idStr?.toIntOrNull()
                AddReminderScreen(navController = navController, viewModel = viewModel, reminderId = id)
            }
            composable("monthly_summary") {
                MonthlySummaryScreen(navController = navController, viewModel = viewModel)
            }
            composable("settings") {
                SettingsScreen(navController = navController, settingsViewModel = settingsViewModel, reminderViewModel = viewModel)
            }
            composable("birthday_anniversary") {
                val eventViewModel: EventViewModel = viewModel { EventViewModel(application) }
                BirthdayAnniversaryScreen(navController = navController, eventViewModel = eventViewModel, openDrawer = openDrawer)
            }
            composable("milage_calculator") {
                val milageViewModel: MilageViewModel = viewModel { MilageViewModel(application) }
                MilageCalculatorScreen(navController = navController, viewModel = milageViewModel, openDrawer = openDrawer)
            }
            composable("my_notes") {
                val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
                MyNotesScreen(navController = navController, viewModel = noteViewModel, openDrawer = openDrawer)
            }
            composable(
                "note_editor_text?noteId={noteId}",
                arguments = listOf(androidx.navigation.navArgument("noteId") { type = androidx.navigation.NavType.StringType; nullable = true })
            ) { backStackEntry ->
                val noteIdStr = backStackEntry.arguments?.getString("noteId")
                val noteId = noteIdStr?.toIntOrNull()
                val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
                NoteTextEditorScreen(navController = navController, viewModel = noteViewModel, noteId = noteId)
            }


            composable(
                "note_editor_drawing?noteId={noteId}",
                arguments = listOf(androidx.navigation.navArgument("noteId") { type = androidx.navigation.NavType.StringType; nullable = true })
            ) { backStackEntry ->
                val noteIdStr = backStackEntry.arguments?.getString("noteId")
                val noteId = noteIdStr?.toIntOrNull()
                val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
                NoteDrawingEditorScreen(navController = navController, viewModel = noteViewModel, noteId = noteId)
            }
            composable("age_calculator") {
                AgeCalculatorScreen(navController = navController, openDrawer = openDrawer)
            }
            composable("photo_resizer") {
                PhotoResizerScreen(navController = navController, openDrawer = openDrawer)
            }
            composable("documents_scanner") {
                val documentScannerViewModel: DocumentScannerViewModel = viewModel { DocumentScannerViewModel(application) }
                DocumentScannerScreen(navController = navController, viewModel = documentScannerViewModel, openDrawer = openDrawer)
            }
            composable("text_scanner") {
                val scannedTextViewModel: ScannedTextViewModel = viewModel { ScannedTextViewModel(application) }
                TextScannerScreen(navController = navController, viewModel = scannedTextViewModel, openDrawer = openDrawer)
            }
            composable("qr_barcode_scanner") {
                val qrBarcodeViewModel: QrBarcodeViewModel = viewModel { QrBarcodeViewModel(application) }
                QrBarcodeScreen(navController = navController, viewModel = qrBarcodeViewModel, openDrawer = openDrawer)
            }
            composable("secure_vault") {
                val secureVaultViewModel: SecureVaultViewModel = viewModel { SecureVaultViewModel(application) }
                SecureVaultScreen(navController = navController, viewModel = secureVaultViewModel, openDrawer = openDrawer)
            }
            composable("whatsapp_scheduler") {
                val whatsappViewModel: WhatsAppViewModel = viewModel { WhatsAppViewModel(application) }
                WhatsAppSchedulerScreen(navController = navController, viewModel = whatsappViewModel)
            }
            composable("document_expiry") {
                val docViewModel: DocumentExpiryViewModel = viewModel { DocumentExpiryViewModel(application) }
                DocumentExpiryScreen(navController = navController, viewModel = docViewModel, openDrawer = openDrawer)
            }
            composable(
                "add_edit_document/{documentId}",
                arguments = listOf(androidx.navigation.navArgument("documentId") { type = androidx.navigation.NavType.IntType })
            ) { backStackEntry ->
                val documentId = backStackEntry.arguments?.getInt("documentId") ?: -1
                val docViewModel: DocumentExpiryViewModel = viewModel { DocumentExpiryViewModel(application) }
                AddEditDocumentScreen(navController = navController, viewModel = docViewModel, documentId = documentId)
            }
            composable("placeholder/{title}") { backStackEntry ->
                val title = backStackEntry.arguments?.getString("title") ?: "Coming Soon"
                PlaceholderScreen(navController = navController, title = title)
            }
            composable(
                "notification_details/{entityType}/{entityId}?isAlarmRinging={isAlarmRinging}",
                arguments = listOf(
                    androidx.navigation.navArgument("entityType") { type = androidx.navigation.NavType.StringType },
                    androidx.navigation.navArgument("entityId") { type = androidx.navigation.NavType.IntType },
                    androidx.navigation.navArgument("isAlarmRinging") { type = androidx.navigation.NavType.BoolType; defaultValue = false }
                )
            ) { backStackEntry ->
                val entityType = backStackEntry.arguments?.getString("entityType") ?: ""
                val entityId = backStackEntry.arguments?.getInt("entityId") ?: 0
                val isAlarmRinging = backStackEntry.arguments?.getBoolean("isAlarmRinging") ?: false
                NotificationDetailsScreen(
                    navController = navController,
                    entityId = entityId,
                    entityType = entityType,
                    initialIsAlarmRinging = isAlarmRinging
                )
            }
        }
    }
}

@Composable
fun PlaceholderScreen(navController: androidx.navigation.NavController, title: String) {
    androidx.compose.material3.Scaffold(
        topBar = {
            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
            androidx.compose.material3.TopAppBar(
                title = { androidx.compose.material3.Text(title) },
                navigationIcon = {
                    androidx.compose.material3.IconButton(onClick = { navController.navigateUp() }) {
                        androidx.compose.material3.Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            androidx.compose.material3.Text(
                text = "Coming Soon",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun QuickAddMenuDialog(
    onDismiss: () -> Unit,
    onNavigate: (String) -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "What do you want to add?",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 20.dp)
                )
                
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickAddOptionRow(
                        icon = androidx.compose.material.icons.Icons.Filled.Edit,
                        iconColor = MaterialTheme.colorScheme.primary,
                        iconBgColor = MaterialTheme.colorScheme.primaryContainer,
                        title = "General Reminder",
                        description = "Set tasks, bill payments, or custom alerts",
                        onClick = {
                            onNavigate("add_reminder")
                        }
                    )
                    
                    QuickAddOptionRow(
                        icon = androidx.compose.material.icons.Icons.Filled.Cake,
                        iconColor = Color(0xFFC2185B),
                        iconBgColor = Color(0xFFFCE4EC),
                        title = "Birthday & Anniversary",
                        description = "Save birthdays and events with reminders",
                        onClick = {
                            onNavigate("birthday_anniversary")
                        }
                    )
                    
                    QuickAddOptionRow(
                        icon = androidx.compose.material.icons.Icons.Filled.DirectionsCar,
                        iconColor = Color(0xFF2E7D32),
                        iconBgColor = Color(0xFFE8F5E9),
                        title = "Mileage Log",
                        description = "Calculate fuel mileage & service history",
                        onClick = {
                            onNavigate("milage_calculator")
                        }
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Cancel")
                }
            }
        }
    }
}

@Composable
fun QuickAddOptionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    iconBgColor: Color,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(iconBgColor, shape = RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
