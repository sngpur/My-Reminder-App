package com.example

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.firstOrNull

class ServicingActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val recordId = intent.getIntExtra("RECORD_ID", 0)
        val vehicleType = intent.getStringExtra("VEHICLE_TYPE") ?: "Vehicle"
        val notificationId = recordId + 100000

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (action == "ACTION_SERVICE_DONE") {
            // Cancel notification
            notificationManager.cancel(notificationId)

            val db = AppDatabase.getDatabase(context)
            val serviceRecordDao = db.serviceRecordDao()

            // Update Room database
            val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                try {
                    val recordFlow = serviceRecordDao.getServiceRecord(vehicleType)
                    val record = recordFlow.firstOrNull()
                    if (record != null) {
                        // Mark as done by clearing the next service date
                        serviceRecordDao.deleteServiceRecord(record)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } finally {
                pendingResult.finish()
            }
        }
        }
    }
}
