package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class ServicingAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val recordId = intent.getIntExtra("RECORD_ID", 0)
        val vehicleType = intent.getStringExtra("VEHICLE_TYPE") ?: "Vehicle"
        val notificationId = recordId + 100000

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "servicing_alarm_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Vehicle Servicing Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alarms for vehicle servicing"
                enableVibration(true)
                val audioAttributes = android.media.AudioAttributes.Builder()
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                    .build()
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), audioAttributes)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", recordId)
            putExtra("EXTRA_ENTITY_TYPE", "Vehicle")
            putExtra("EXTRA_IS_RINGING", false)
            }
        val pendingIntent = PendingIntent.getActivity(
            context, recordId, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val serviceDoneIntent = Intent(context, ServicingActionReceiver::class.java).apply {
            action = "ACTION_SERVICE_DONE"
            putExtra("RECORD_ID", recordId)
            putExtra("VEHICLE_TYPE", vehicleType)
        }
        val serviceDonePendingIntent = PendingIntent.getBroadcast(
            context, recordId + 200000, serviceDoneIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle("Vehicle Servicing Due!")
            .setContentText("Your $vehicleType is due for servicing today.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(false) // Keep it persistent until interacted with
            .setOngoing(false) // Not ongoing like a foreground service, but doesn't auto dismiss
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            .setDefaults(NotificationCompat.DEFAULT_VIBRATE)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_preferences, "Service Done", serviceDonePendingIntent)
            .build()

        notificationManager.notify(notificationId, notification)
    }
}
