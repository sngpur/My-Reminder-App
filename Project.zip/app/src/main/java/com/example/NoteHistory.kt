package com.example

import androidx.compose.runtime.Stable

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "note_history")
@Stable
data class NoteHistory(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val noteId: Int,
    val content: String,
    val timestampInMillis: Long
)
