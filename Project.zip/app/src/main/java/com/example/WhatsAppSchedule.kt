package com.example

import androidx.compose.runtime.Stable

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "whatsapp_schedules")
@Stable
data class WhatsAppSchedule(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val phoneNumber: String,
    val message: String,
    val scheduledTimeInMillis: Long,
    val isSent: Boolean = false
)
