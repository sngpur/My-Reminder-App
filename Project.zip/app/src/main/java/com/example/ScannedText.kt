package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scanned_texts")
data class ScannedText(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val extractedText: String = "",
    val dateMillis: Long,
    val pdfUri: String? = null,
    val pageCount: Int = 0
)
