package com.example

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object AlarmScheduler {
    fun scheduleEventAlarm(context: Context, event: Event) {
        if (!event.ringAlarm) {
            cancelEventAlarm(context, event)
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, BirthdayAlarmReceiver::class.java).apply {
            putExtra("EVENT_ID", event.id)
            putExtra("EVENT_NAME", event.name)
            putExtra("EVENT_TYPE", event.eventType)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            event.id, // Use event ID as request code for uniqueness
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            val formatter = java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy", java.util.Locale.getDefault())
            val eventDate = LocalDate.parse("${event.date} ${LocalDateTime.now().year}", formatter)
            val eventTime = try { LocalTime.parse(event.time) } catch (e: Exception) { LocalTime.MIDNIGHT }
            val now = LocalDateTime.now()
            
            var nextAlarmTime = LocalDateTime.of(now.year, eventDate.month, eventDate.dayOfMonth, eventTime.hour, eventTime.minute)
            if (nextAlarmTime.isBefore(now)) {
                nextAlarmTime = nextAlarmTime.plusYears(1)
            }

            val triggerTimeMillis = nextAlarmTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTimeMillis, pendingIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelEventAlarm(context: Context, event: Event) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, BirthdayAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            event.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
