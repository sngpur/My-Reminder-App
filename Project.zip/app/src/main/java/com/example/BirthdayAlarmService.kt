package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class BirthdayAlarmService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SomnathBirthday::AlarmWakeLock")
        wakeLock?.acquire(10 * 60 * 1000L /*10 minutes*/)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val eventId = intent?.getIntExtra("EVENT_ID", 0) ?: 0
        val eventName = intent?.getStringExtra("EVENT_NAME") ?: "Event"
        val eventType = intent?.getStringExtra("EVENT_TYPE") ?: "Birthday"
        val phoneNumber = intent?.getStringExtra("PHONE_NUMBER") ?: ""
        val customMessage = intent?.getStringExtra("CUSTOM_MESSAGE") ?: ""
        
        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        
        try {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
                mediaPlayer?.release()
                mediaPlayer = null
            }
            mediaPlayer = MediaPlayer().apply {
                setDataSource(applicationContext, alarmSound)
                setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "Channel_Birthday"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Birthdays & Anniversaries Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Continuous alarms for birthdays and anniversaries"
                setSound(null, null)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", eventId)
            putExtra("EXTRA_ENTITY_TYPE", "Task")
            putExtra("EXTRA_IS_RINGING", true)
            }
        val pendingIntent = PendingIntent.getActivity(
            this, eventId, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, BirthdayActionReceiver::class.java).apply {
            action = "ACTION_STOP_ALARM"
            putExtra("EVENT_ID", eventId)
            putExtra("EVENT_NAME", eventName)
            putExtra("EVENT_TYPE", eventType)
            putExtra("PHONE_NUMBER", phoneNumber)
            putExtra("CUSTOM_MESSAGE", customMessage)
        }
        val stopPendingIntent = PendingIntent.getBroadcast(
            this, eventId, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val sendWishesIntent = Intent(this, BirthdayActionReceiver::class.java).apply {
            action = "ACTION_SEND_WISHES"
            putExtra("EVENT_ID", eventId)
            putExtra("EVENT_NAME", eventName)
            putExtra("EVENT_TYPE", eventType)
            putExtra("PHONE_NUMBER", phoneNumber)
            putExtra("CUSTOM_MESSAGE", customMessage)
        }
        val sendWishesPendingIntent = PendingIntent.getBroadcast(
            this, eventId + 50000, sendWishesIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(if (eventType == "Birthday") android.R.drawable.ic_menu_my_calendar else android.R.drawable.ic_menu_recent_history)
            .setContentTitle("It's $eventName's $eventType!")
            .setContentText("Don't forget to wish them!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pendingIntent, true)
            .addAction(android.R.drawable.ic_media_pause, "Stop Alarm", stopPendingIntent)
            .addAction(android.R.drawable.ic_menu_send, "Send Wishes", sendWishesPendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(eventId + 30000, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(eventId + 30000, notification)
        }

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
    }
}
