package com.example

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

@Dao
interface FuelRecordDao {
    @Insert
    suspend fun insertFuelRecord(record: FuelRecord)

    @Query("SELECT * FROM fuel_records WHERE vehicleType = :vehicleType ORDER BY dateMillis DESC")
    fun getFuelRecords(vehicleType: String): Flow<List<FuelRecord>>
    
    @Query("DELETE FROM fuel_records WHERE vehicleType = :vehicleType")
    suspend fun deleteFuelRecords(vehicleType: String)

    @Update
    suspend fun updateFuelRecord(record: FuelRecord)

    @Delete
    suspend fun deleteFuelRecord(record: FuelRecord)
}
