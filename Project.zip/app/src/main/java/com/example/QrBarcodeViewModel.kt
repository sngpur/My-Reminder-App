package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class QrBarcodeViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).qrRecordDao()
    
    val allRecords: StateFlow<List<QrRecord>> = dao.getAllQrRecords()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun insertRecord(record: QrRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.insertQrRecord(record)
        }
    }

    fun deleteRecord(record: QrRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.deleteQrRecord(record)
        }
    }
}
