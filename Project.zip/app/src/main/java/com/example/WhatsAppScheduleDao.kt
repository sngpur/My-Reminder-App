package com.example

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WhatsAppScheduleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: WhatsAppSchedule): Long

    @Query("SELECT * FROM whatsapp_schedules WHERE isSent = 0 ORDER BY scheduledTimeInMillis ASC")
    fun getPendingSchedules(): Flow<List<WhatsAppSchedule>>

    @Query("SELECT * FROM whatsapp_schedules WHERE isSent = 0")
    fun getPendingSchedulesSync(): List<WhatsAppSchedule>
    
    @Query("SELECT * FROM whatsapp_schedules WHERE id = :id")
    suspend fun getScheduleById(id: Int): WhatsAppSchedule?

    @Query("UPDATE whatsapp_schedules SET isSent = 1 WHERE id = :id")
    suspend fun markAsSent(id: Int)
}
