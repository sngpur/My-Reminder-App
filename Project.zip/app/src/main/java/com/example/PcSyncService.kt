package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import io.ktor.http.ContentType
import java.net.InetAddress
import java.net.NetworkInterface

class PcSyncService : Service() {
    private var server: NettyApplicationEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
        startKtorServer()
    }

    private fun startForegroundService() {
        val channelId = "pc_sync_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "PC Sync Server",
                NotificationManager.IMPORTANCE_LOW
            )
            notificationManager.createNotificationChannel(channel)
        }

        val ip = getLocalIpAddress() ?: "localhost"

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("PC Sync Server Running")
            .setContentText("Access dashboard at http://$ip:8080/dashboard")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(9090, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(9090, notification)
        }
    }

    private fun startKtorServer() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                server = embeddedServer(Netty, port = 8080) {
                    routing {
                        get("/dashboard") {
                            val db = AppDatabase.getDatabase(this@PcSyncService)
                            val tasks = db.reminderDao().getRemindersForDateSync(java.time.LocalDate.now().toString())
                            val finances = db.reminderDao().getFinanceRemindersSync()
                            
                            var html = "<html><head><title>MyBuddy Dashboard</title><style>body{font-family: Arial, sans-serif; padding: 20px;} table{width: 100%; border-collapse: collapse; margin-bottom: 20px;} th, td{border: 1px solid #ddd; padding: 8px;} th{background-color: #f2f2f2;} h1{color: #333;}</style></head><body>"
                            html += "<h1>Welcome to MyBuddy PC Sync</h1>"
                            
                            html += "<h2>Today's Tasks</h2>"
                            html += "<table><tr><th>Title</th><th>Category</th><th>Time</th><th>Status</th></tr>"
                            for (t in tasks) {
                                html += "<tr><td>${t.taskTitle}</td><td>${t.category}</td><td>${t.taskTime}</td><td>${if (t.isCompleted) "Done" else "Pending"}</td></tr>"
                            }
                            html += "</table>"
                            
                            html += "<h2>Finance Reminders</h2>"
                            html += "<table><tr><th>Title</th><th>Type</th><th>Amount</th><th>Status</th></tr>"
                            for (t in finances) {
                                html += "<tr><td>${t.taskTitle}</td><td>${t.category}</td><td>Rs. ${t.amount}</td><td>${if (t.isCompleted) "Settled" else "Pending"}</td></tr>"
                            }
                            html += "</table>"
                            
                            html += "</body></html>"
                            
                            call.respondText(html, ContentType.Text.Html)
                        }
                    }
                }.start(wait = false)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        CoroutineScope(Dispatchers.IO).launch {
            server?.stop(1000, 2000)
        }
    }

    companion object {
        fun getLocalIpAddress(): String? {
            try {
                val interfaces = NetworkInterface.getNetworkInterfaces()
                while (interfaces.hasMoreElements()) {
                    val intf = interfaces.nextElement()
                    val addrs = intf.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val addr = addrs.nextElement()
                        if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                            return addr.hostAddress
                        }
                    }
                }
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return null
        }
    }
}
