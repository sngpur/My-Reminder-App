package com.example

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface QrRecordDao {
    @Query("SELECT * FROM qr_records ORDER BY dateMillis DESC")
    fun getAllQrRecords(): Flow<List<QrRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQrRecord(record: QrRecord)

    @Delete
    suspend fun deleteQrRecord(record: QrRecord)
}
