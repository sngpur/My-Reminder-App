package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_records")
data class VaultRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // "Password", "Card", or "Note"
    val title: String,
    val secretData: String,
    val extraInfo: String,
    val dateMillis: Long = System.currentTimeMillis()
)
