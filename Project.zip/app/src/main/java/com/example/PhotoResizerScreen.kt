package com.example

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.MediaStore
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoResizerScreen(navController: NavController) {
    val context = LocalContext.current
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    
    // Settings state
    var selectedRatio by remember { mutableStateOf("Original") }
    var targetSize by remember { mutableStateOf("") }
    var sizeUnit by remember { mutableStateOf("KB") }

    var expandedRatio by remember { mutableStateOf(false) }
    val ratios = listOf("Original", "1:1", "4:3", "3:4", "16:9")

    var expandedUnit by remember { mutableStateOf(false) }
    val units = listOf("KB", "MB")

    val coroutineScope = rememberCoroutineScope()
    var isProcessing by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> selectedImageUri = uri }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Photo Resizer", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Image Selection Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                onClick = {
                    photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedImageUri != null) {
                        AsyncImage(
                            model = selectedImageUri,
                            contentDescription = "Selected Photo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AddPhotoAlternate,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Upload Photo",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Settings Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left Card - Aspect Ratio
                Card(
                    modifier = Modifier.weight(1f).aspectRatio(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("Aspect Ratio", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f))
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        ExposedDropdownMenuBox(
                            expanded = expandedRatio,
                            onExpandedChange = { expandedRatio = !expandedRatio }
                        ) {
                            OutlinedTextField(
                                value = selectedRatio,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedRatio) },
                                modifier = Modifier.menuAnchor(),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                                    focusedBorderColor = MaterialTheme.colorScheme.secondary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.5f)
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = expandedRatio,
                                onDismissRequest = { expandedRatio = false }
                            ) {
                                ratios.forEach { ratio ->
                                    DropdownMenuItem(
                                        text = { Text(ratio) },
                                        onClick = {
                                            selectedRatio = ratio
                                            expandedRatio = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Right Card - Target Size
                Card(
                    modifier = Modifier.weight(1f).aspectRatio(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("Target Size", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f))
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = targetSize,
                                onValueChange = { targetSize = it },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                                    focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.5f)
                                )
                            )
                            
                            ExposedDropdownMenuBox(
                                expanded = expandedUnit,
                                onExpandedChange = { expandedUnit = !expandedUnit },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = sizeUnit,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedUnit) },
                                    modifier = Modifier.menuAnchor(),
                                    textStyle = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                                        focusedBorderColor = MaterialTheme.colorScheme.tertiary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.5f)
                                    )
                                )
                                ExposedDropdownMenu(
                                    expanded = expandedUnit,
                                    onDismissRequest = { expandedUnit = false }
                                ) {
                                    units.forEach { unit ->
                                        DropdownMenuItem(
                                            text = { Text(unit) },
                                            onClick = {
                                                sizeUnit = unit
                                                expandedUnit = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))

            // Action Button
            Button(
                onClick = {
                    if (selectedImageUri == null) return@Button
                    val targetSizeNum = targetSize.toDoubleOrNull()
                    if (targetSizeNum == null || targetSizeNum <= 0) {
                        Toast.makeText(context, "Please enter a valid target size", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val targetBytes = if (sizeUnit == "MB") {
                        (targetSizeNum * 1024 * 1024).toLong()
                    } else {
                        (targetSizeNum * 1024).toLong()
                    }
                    isProcessing = true
                    coroutineScope.launch {
                        try {
                            val resultSize = withContext(Dispatchers.IO) {
                                resizeAndSaveImage(
                                    context = context,
                                    uri = selectedImageUri!!,
                                    aspectRatio = selectedRatio,
                                    targetBytes = targetBytes
                                )
                            }
                            if (resultSize != null) {
                                val finalSizeKb = resultSize / 1024
                                Toast.makeText(context, "Saved to My Buddy Resizer: $finalSizeKb KB", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Failed to process image", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                        } finally {
                            isProcessing = false
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(16.dp),
                enabled = selectedImageUri != null && !isProcessing
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("Resize & Save Photo", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

suspend fun resizeAndSaveImage(
    context: android.content.Context,
    uri: Uri,
    aspectRatio: String,
    targetBytes: Long
): Long? {
    val inputStream = context.contentResolver.openInputStream(uri) ?: return null
    var bitmap = BitmapFactory.decodeStream(inputStream)
    inputStream.close()
    if (bitmap == null) return null

    // 1. Crop to Aspect Ratio
    if (aspectRatio != "Original") {
        val targetRatio = when (aspectRatio) {
            "1:1" -> 1f
            "4:3" -> 4f / 3f
            "3:4" -> 3f / 4f
            "16:9" -> 16f / 9f
            else -> 1f
        }
        val currentRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        
        if (abs(currentRatio - targetRatio) > 0.01f) {
            val newWidth: Int
            val newHeight: Int
            if (currentRatio > targetRatio) {
                newHeight = bitmap.height
                newWidth = (newHeight * targetRatio).toInt()
            } else {
                newWidth = bitmap.width
                newHeight = (newWidth / targetRatio).toInt()
            }
            val xOffset = (bitmap.width - newWidth) / 2
            val yOffset = (bitmap.height - newHeight) / 2
            
            val cropped = Bitmap.createBitmap(bitmap, xOffset, yOffset, newWidth, newHeight)
            if (cropped != bitmap) {
                bitmap.recycle()
                bitmap = cropped
            }
        }
    }

    // 2. Compress to Target Size
    var quality = 100
    var scale = 1.0f
    var stream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
    var byteArr = stream.toByteArray()

    // Reduce quality first
    while (byteArr.size > targetBytes && quality > 30) {
        stream.reset()
        quality -= 10
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
        byteArr = stream.toByteArray()
    }

    // If still too large, scale down image dimensions
    var currentBitmap = bitmap
    while (byteArr.size > targetBytes && scale > 0.1f) {
        scale -= 0.1f
        val newWidth = (bitmap.width * scale).toInt()
        val newHeight = (bitmap.height * scale).toInt()
        if (newWidth <= 0 || newHeight <= 0) break
        
        val scaled = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
        stream.reset()
        scaled.compress(Bitmap.CompressFormat.JPEG, quality, stream)
        byteArr = stream.toByteArray()
        if (scaled != currentBitmap && currentBitmap != bitmap) {
            currentBitmap.recycle()
        }
        currentBitmap = scaled
    }

    // 3. Save to MediaStore
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "Resized_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/My Buddy Resizer")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
    }

    val collection = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    } else {
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }

    val itemUri = context.contentResolver.insert(collection, values) ?: return null
    context.contentResolver.openOutputStream(itemUri)?.use { out ->
        out.write(byteArr)
    }

    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        context.contentResolver.update(itemUri, values, null, null)
    }

    if (currentBitmap != bitmap) currentBitmap.recycle()
    bitmap.recycle()

    return byteArr.size.toLong()
}
