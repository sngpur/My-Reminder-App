package com.example

import kotlinx.coroutines.flow.Flow

class ReminderRepository(private val reminderDao: ReminderDao) {
    val allReminders: Flow<List<Reminder>> = reminderDao.getAllReminders()

    suspend fun insert(reminder: Reminder): Long {
        return reminderDao.insertReminder(reminder)
    }

    suspend fun update(reminder: Reminder) {
        reminderDao.updateReminder(reminder)
    }

    suspend fun updateCompletionStatus(id: Int, isCompleted: Boolean) {
        reminderDao.updateCompletionStatus(id, isCompleted)
    }

    suspend fun deleteById(id: Int) {
        reminderDao.deleteReminderById(id)
    }
}
