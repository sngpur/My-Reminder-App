package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ScannedTextViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).scannedTextDao()

    val allScannedTexts: StateFlow<List<ScannedText>> = dao.getAllScannedTexts()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun insertScannedText(scannedText: ScannedText) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.insertScannedText(scannedText)
        }
    }

    fun deleteScannedText(scannedText: ScannedText) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.deleteScannedText(scannedText)
        }
    }
}
