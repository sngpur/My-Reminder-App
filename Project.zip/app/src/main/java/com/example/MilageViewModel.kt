package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MilageViewModel(application: Application) : AndroidViewModel(application) {
    private val fuelRecordDao = AppDatabase.getDatabase(application).fuelRecordDao()
    private val serviceRecordDao = AppDatabase.getDatabase(application).serviceRecordDao()

    val bikeFuelRecords: StateFlow<List<FuelRecord>> = fuelRecordDao.getFuelRecords("Bike")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val carFuelRecords: StateFlow<List<FuelRecord>> = fuelRecordDao.getFuelRecords("Car")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bikeServiceRecord: StateFlow<ServiceRecord?> = serviceRecordDao.getServiceRecord("Bike")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val carServiceRecord: StateFlow<ServiceRecord?> = serviceRecordDao.getServiceRecord("Car")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun updateFuelRecord(record: FuelRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            fuelRecordDao.updateFuelRecord(record)
        }
    }

    fun deleteFuelRecord(record: FuelRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            fuelRecordDao.deleteFuelRecord(record)
        }
    }

    fun addFuelRecord(record: FuelRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            fuelRecordDao.insertFuelRecord(record)
        }
    }

    fun deleteBikeFuelRecords() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            fuelRecordDao.deleteFuelRecords("Bike")
        }
    }

    fun deleteCarFuelRecords() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            fuelRecordDao.deleteFuelRecords("Car")
        }
    }

    fun deleteServiceRecord(record: ServiceRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            serviceRecordDao.deleteServiceRecord(record)
            ServicingAlarmScheduler.cancelServicingAlarm(getApplication(), record)
        }
    }

    fun saveServiceRecord(record: ServiceRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val id = serviceRecordDao.insertServiceRecord(record)
            val updatedRecord = record.copy(id = id.toInt())
            ServicingAlarmScheduler.scheduleServicingAlarm(getApplication(), updatedRecord)
        }
    }
}
