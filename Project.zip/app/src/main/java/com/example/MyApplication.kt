package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            // Channel_Birthday
            val birthdayChannel = NotificationChannel(
                "Channel_Birthday",
                "Birthdays & Anniversaries",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for Birthdays and Anniversaries"
                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                setSound(soundUri, audioAttributes)
                enableVibration(true)
            }

            // Channel_Finance
            val financeChannel = NotificationChannel(
                "Channel_Finance",
                "Finance & Bills",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for Financial Reminders"
                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                setSound(soundUri, audioAttributes)
                enableVibration(true)
            }

            // Channel_Tasks
            val tasksChannel = NotificationChannel(
                "Channel_Tasks",
                "Tasks & General",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for General Tasks"
                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                setSound(soundUri, audioAttributes)
            }
            
            // Morning Briefing
            val morningChannel = NotificationChannel(
                "Channel_Morning",
                "Morning Briefing",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily Morning Briefing"
            }

            notificationManager.createNotificationChannel(birthdayChannel)
            notificationManager.createNotificationChannel(financeChannel)
            notificationManager.createNotificationChannel(tasksChannel)
            notificationManager.createNotificationChannel(morningChannel)
        }
    }
}
