package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scanned_docs")
data class ScannedDoc(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val fileUri: String,
    val format: String,
    val pageCount: Int,
    val dateMillis: Long
)
