package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WhatsAppViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val dao = db.whatsappScheduleDao()
    private val alarmScheduler = WhatsAppAlarmScheduler(application)

    val pendingSchedules = dao.getPendingSchedules().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addSchedule(phoneNumber: String, message: String, scheduledTimeInMillis: Long) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val newSchedule = WhatsAppSchedule(
                phoneNumber = phoneNumber,
                message = message,
                scheduledTimeInMillis = scheduledTimeInMillis
            )
            val id = dao.insertSchedule(newSchedule)
            alarmScheduler.schedule(newSchedule.copy(id = id.toInt()))
        }
    }
}
