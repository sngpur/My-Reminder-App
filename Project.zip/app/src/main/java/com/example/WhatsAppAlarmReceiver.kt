package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WhatsAppAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        val wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "SecureVault:WhatsAppAlarmWakeLock")
        wakeLock.acquire(10 * 1000L)

        val scheduleId = intent.getIntExtra("scheduleId", -1)
        if (scheduleId == -1) {
            try {
                if (wakeLock.isHeld) {
                    wakeLock.release()
                }
            } catch (e: Exception) {}
            return
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
            val db = AppDatabase.getDatabase(context)
            val schedule = db.whatsappScheduleDao().getScheduleById(scheduleId)
            
            schedule?.let {
                if (!it.isSent) {
                    showNotification(context, it)
                }
            }
            } finally {
                try {
                    if (wakeLock.isHeld) {
                        wakeLock.release()
                    }
                } catch (e: Exception) {}
                pendingResult.finish()
            }
        }
    }

    private fun showNotification(context: Context, schedule: WhatsAppSchedule) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "whatsapp_scheduler_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "WhatsApp Scheduler",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val sendIntent = Intent(context, WhatsAppActionReceiver::class.java).apply {
            putExtra("scheduleId", schedule.id)
            putExtra("phoneNumber", schedule.phoneNumber)
            putExtra("message", schedule.message)
        }

        val pendingSendIntent = PendingIntent.getBroadcast(
            context,
            schedule.id,
            sendIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Scheduled WhatsApp Ready")
            .setContentText("To: ${schedule.phoneNumber}\nMsg: ${schedule.message}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_send, "Send Now", pendingSendIntent)
            .build()

        notificationManager.notify(schedule.id, notification)
    }
}
