package com.example

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

class DocumentExpiryAlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun schedule(doc: DocumentExpiry) {
        // 7 days before
        val sevenDaysBefore = doc.expiryDateInMillis - 7 * 24 * 60 * 60 * 1000L
        val oneDayBefore = doc.expiryDateInMillis - 1 * 24 * 60 * 60 * 1000L

        scheduleAlarm(doc, sevenDaysBefore, doc.id * 10 + 7)
        scheduleAlarm(doc, oneDayBefore, doc.id * 10 + 1)
    }

    private fun scheduleAlarm(doc: DocumentExpiry, timeInMillis: Long, requestCode: Int) {
        if (timeInMillis <= System.currentTimeMillis()) return
        
        val intent = Intent(context, DocumentExpiryAlarmReceiver::class.java).apply {
            putExtra("docId", doc.id)
            putExtra("docName", doc.docName)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
