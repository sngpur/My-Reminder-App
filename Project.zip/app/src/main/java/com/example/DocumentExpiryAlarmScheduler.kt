package com.example

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

class DocumentExpiryAlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun schedule(doc: DocumentExpiry) {
        // 7 days before
        val sevenDaysBefore = doc.expiryDateInMillis - 7 * 24 * 60 * 60 * 1000L
        val oneDayBefore = doc.expiryDateInMillis - 1 * 24 * 60 * 60 * 1000L

        // Exact expiry day at 9:00 AM
        val zoneId = java.time.ZoneId.systemDefault()
        val expiryLocalDate = java.time.Instant.ofEpochMilli(doc.expiryDateInMillis)
            .atZone(zoneId)
            .toLocalDate()
        val expiryDay9AM = expiryLocalDate.atTime(9, 0)
            .atZone(zoneId)
            .toInstant()
            .toEpochMilli()

        scheduleAlarm(doc, sevenDaysBefore, doc.id * 10 + 7, 7)
        scheduleAlarm(doc, oneDayBefore, doc.id * 10 + 1, 1)
        scheduleAlarm(doc, expiryDay9AM, doc.id * 10 + 0, 0)
    }

    fun cancel(id: Int) {
        val intent = Intent(context, DocumentExpiryAlarmReceiver::class.java)
        listOf(id * 10 + 7, id * 10 + 1, id * 10 + 0).forEach { requestCode ->
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        }
    }

    private fun scheduleAlarm(doc: DocumentExpiry, timeInMillis: Long, requestCode: Int, daysLeft: Int) {
        if (timeInMillis <= System.currentTimeMillis()) return
        
        val intent = Intent(context, DocumentExpiryAlarmReceiver::class.java).apply {
            putExtra("docId", doc.id)
            putExtra("docName", doc.docName)
            putExtra("daysLeft", daysLeft)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                } catch (se: SecurityException) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                }
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
