package com.example

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentExpiryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocumentExpiry(doc: DocumentExpiry): Long

    @Update
    suspend fun updateDocumentExpiry(doc: DocumentExpiry)

    @Query("SELECT * FROM document_expiry ORDER BY expiryDateInMillis ASC")
    fun getAllDocuments(): Flow<List<DocumentExpiry>>

    @Query("SELECT * FROM document_expiry")
    fun getAllDocumentsSync(): List<DocumentExpiry>

    @Query("SELECT * FROM document_expiry WHERE id = :id")
    suspend fun getDocumentById(id: Int): DocumentExpiry?
    
    @Query("DELETE FROM document_expiry WHERE id = :id")
    suspend fun deleteDocument(id: Int)
}
