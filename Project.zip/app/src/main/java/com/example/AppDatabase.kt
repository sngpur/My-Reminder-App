package com.example

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase


@Database(entities = [Reminder::class, Event::class, FuelRecord::class, ServiceRecord::class, Note::class, ScannedText::class, ScannedDoc::class, QrRecord::class, VaultRecord::class, WhatsAppSchedule::class, DocumentExpiry::class, NoteHistory::class], version = 19, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun reminderDao(): ReminderDao
    abstract fun eventDao(): EventDao
    abstract fun fuelRecordDao(): FuelRecordDao
    abstract fun serviceRecordDao(): ServiceRecordDao
    abstract fun noteDao(): NoteDao
    abstract fun scannedTextDao(): ScannedTextDao
    abstract fun scannedDocDao(): ScannedDocDao
    abstract fun qrRecordDao(): QrRecordDao
    abstract fun vaultRecordDao(): VaultRecordDao
    abstract fun whatsappScheduleDao(): WhatsAppScheduleDao
    abstract fun documentExpiryDao(): DocumentExpiryDao
    abstract fun noteHistoryDao(): NoteHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

val migrations = (1..18).map { startVersion ->
            object : Migration(startVersion, 19) {
                override fun migrate(db: SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE IF NOT EXISTS `events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `eventType` TEXT NOT NULL, `name` TEXT NOT NULL, `relationship` TEXT NOT NULL, `date` TEXT NOT NULL, `time` TEXT NOT NULL, `ringAlarm` INTEGER NOT NULL, `phoneNumber` TEXT NOT NULL DEFAULT '', `customMessage` TEXT NOT NULL DEFAULT '')")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `fuel_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `vehicleType` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `odometerKm` INTEGER NOT NULL, `fuelLiters` REAL NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `service_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `vehicleType` TEXT NOT NULL, `lastServiceDate` TEXT NOT NULL, `nextServiceDate` TEXT NOT NULL, `nextServiceMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `notes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `noteType` TEXT NOT NULL, `content` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `scanned_texts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `extractedText` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `pdfUri` TEXT, `pageCount` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `scanned_docs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `fileUri` TEXT NOT NULL, `format` TEXT NOT NULL, `pageCount` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `qr_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `type` TEXT NOT NULL, `data` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `vault_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `category` TEXT NOT NULL, `title` TEXT NOT NULL, `secretData` TEXT NOT NULL, `extraInfo` TEXT NOT NULL, `username` TEXT, `pin` TEXT, `dateMillis` INTEGER NOT NULL)")
                    
                    db.execSQL("CREATE TABLE IF NOT EXISTS `whatsapp_schedules` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `phoneNumber` TEXT NOT NULL, `message` TEXT NOT NULL, `scheduledTimeInMillis` INTEGER NOT NULL, `isSent` INTEGER NOT NULL)")
                    try { db.execSQL("CREATE TABLE IF NOT EXISTS `document_expiry` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `docName` TEXT NOT NULL, `expiryDateInMillis` INTEGER NOT NULL, `type` TEXT NOT NULL)") } catch (e: Exception) {}
                    try { db.execSQL("CREATE TABLE IF NOT EXISTS `note_history` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `noteId` INTEGER NOT NULL, `content` TEXT NOT NULL, `timestampInMillis` INTEGER NOT NULL)") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE reminders ADD COLUMN isAlarmEnabled INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE notes ADD COLUMN noteType TEXT NOT NULL DEFAULT 'Text'") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE notes ADD COLUMN dateMillis INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE reminders ADD COLUMN isDeleted INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE notes ADD COLUMN isDeleted INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE events ADD COLUMN phoneNumber TEXT NOT NULL DEFAULT ''") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE events ADD COLUMN customMessage TEXT NOT NULL DEFAULT ''") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE vault_records ADD COLUMN username TEXT") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE vault_records ADD COLUMN pin TEXT") } catch (e: Exception) {}
                }
            }
        }.toTypedArray()

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "somnath_reminder_db"
                ).addMigrations(*migrations)
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        fun closeDatabase() {
            INSTANCE?.close()
            INSTANCE = null
        }
    }
}
