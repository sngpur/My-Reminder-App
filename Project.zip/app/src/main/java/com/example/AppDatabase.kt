package com.example

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Reminder::class, Event::class, FuelRecord::class, ServiceRecord::class, Note::class, ScannedText::class, ScannedDoc::class, QrRecord::class, VaultRecord::class], version = 12, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun reminderDao(): ReminderDao
    abstract fun eventDao(): EventDao
    abstract fun fuelRecordDao(): FuelRecordDao
    abstract fun serviceRecordDao(): ServiceRecordDao
    abstract fun noteDao(): NoteDao
    abstract fun scannedTextDao(): ScannedTextDao
    abstract fun scannedDocDao(): ScannedDocDao
    abstract fun qrRecordDao(): QrRecordDao
    abstract fun vaultRecordDao(): VaultRecordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "somnath_reminder_db"
                ).fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
