package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow

class NoteViewModel(application: Application) : AndroidViewModel(application) {
    private val noteDao = AppDatabase.getDatabase(application).noteDao()

    val allNotes: StateFlow<List<Note>> = noteDao.getAllNotes()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        
    val trashedNotes: StateFlow<List<Note>> = noteDao.getTrashedNotes()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    
    fun getHistoryForNote(noteId: Int): Flow<List<NoteHistory>> {
        return AppDatabase.getDatabase(getApplication()).noteHistoryDao().getHistoryForNote(noteId)
    }

    fun addNote(note: Note) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            noteDao.insertNote(note)
        }
    }

    fun updateNote(note: Note) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val oldNote = noteDao.getNoteById(note.id)
            oldNote?.let {
                val history = NoteHistory(
                    noteId = note.id,
                    content = it.content,
                    timestampInMillis = System.currentTimeMillis()
                )
                AppDatabase.getDatabase(getApplication()).noteHistoryDao().insertNoteHistory(history)
            }
            noteDao.updateNote(note)
        }
    }

    fun permanentlyDeleteNote(note: Note) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) { noteDao.deleteNote(note) }
    }
    
    fun restoreNote(id: Int) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) { noteDao.restoreNoteById(id) }
    }
    
    fun deleteNote(note: Note) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            noteDao.softDeleteNoteById(note.id)
        }
    }
}
