package com.example.data

import kotlinx.coroutines.flow.Flow

class ReminderRepository(private val reminderDao: ReminderDao) {
    val allReminders: Flow<List<Reminder>> = reminderDao.getAllReminders()
    val activeReminders: Flow<List<Reminder>> = reminderDao.getActiveReminders()

    suspend fun getReminderById(id: Long): Reminder? = reminderDao.getReminderById(id)

    suspend fun insert(reminder: Reminder): Long = reminderDao.insertReminder(reminder)

    suspend fun update(reminder: Reminder) = reminderDao.updateReminder(reminder)

    suspend fun delete(reminder: Reminder) = reminderDao.deleteReminder(reminder)
}
