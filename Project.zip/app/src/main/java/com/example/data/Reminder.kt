package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONObject

@Entity(tableName = "Reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskTitle: String,
    val category: String, // "Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other"
    val taskDate: String, // E.g., "YYYY-MM-DD" or formatted "03 Jul 2026"
    val taskTime: String, // E.g., "HH:mm" or formatted "10:30 AM"
    val isCompleted: Boolean = false,
    val location: String = "",
    val amount: Double = 0.0,
    val dateTimeMillis: Long = 0L, // Absolute epoch timestamp for exact sorting and alarm trigger comparison
    
    // Multi-Reminder fields (Up to 3 per task)
    val reminder1Date: String,
    val reminder1Time: String,
    val reminder1Millis: Long = 0L,
    
    val reminder2Date: String = "",
    val reminder2Time: String = "",
    val reminder2Millis: Long = 0L,
    
    val reminder3Date: String = "",
    val reminder3Time: String = "",
    val reminder3Millis: Long = 0L
) {
    // Utility to convert to org.json.JSONObject for seamless import/export
    fun toJsonObject(): JSONObject {
        val json = JSONObject()
        json.put("id", id)
        json.put("taskTitle", taskTitle)
        json.put("category", category)
        json.put("taskDate", taskDate)
        json.put("taskTime", taskTime)
        json.put("isCompleted", isCompleted)
        json.put("location", location)
        json.put("amount", amount)
        json.put("dateTimeMillis", dateTimeMillis)
        
        json.put("reminder1Date", reminder1Date)
        json.put("reminder1Time", reminder1Time)
        json.put("reminder1Millis", reminder1Millis)
        
        json.put("reminder2Date", reminder2Date)
        json.put("reminder2Time", reminder2Time)
        json.put("reminder2Millis", reminder2Millis)
        
        json.put("reminder3Date", reminder3Date)
        json.put("reminder3Time", reminder3Time)
        json.put("reminder3Millis", reminder3Millis)
        return json
    }
}

// Global utility for decoding json objects safely
fun jsonObjectToReminder(json: JSONObject): Reminder {
    val tDate = json.optString("taskDate", "")
    val tTime = json.optString("taskTime", "")
    val tMillis = json.optLong("dateTimeMillis", 0L)

    return Reminder(
        id = json.optLong("id", 0L),
        taskTitle = json.optString("taskTitle", ""),
        category = json.optString("category", "Other"),
        taskDate = tDate,
        taskTime = tTime,
        isCompleted = json.optBoolean("isCompleted", false),
        location = json.optString("location", ""),
        amount = json.optDouble("amount", 0.0),
        dateTimeMillis = tMillis,
        
        reminder1Date = json.optString("reminder1Date", tDate),
        reminder1Time = json.optString("reminder1Time", tTime),
        reminder1Millis = json.optLong("reminder1Millis", tMillis),
        
        reminder2Date = json.optString("reminder2Date", ""),
        reminder2Time = json.optString("reminder2Time", ""),
        reminder2Millis = json.optLong("reminder2Millis", 0L),
        
        reminder3Date = json.optString("reminder3Date", ""),
        reminder3Time = json.optString("reminder3Time", ""),
        reminder3Millis = json.optLong("reminder3Millis", 0L)
    )
}
