package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskTitle: String,
    val category: String, // "Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other"
    val taskDate: String, // E.g., "YYYY-MM-DD" or formatted "03 Jul 2026"
    val taskTime: String, // E.g., "HH:mm" or formatted "10:30 AM"
    val isCompleted: Boolean = false,
    val location: String = "",
    val dateTimeMillis: Long = 0L // Absolute epoch timestamp for exact sorting and alarm trigger comparison
)
