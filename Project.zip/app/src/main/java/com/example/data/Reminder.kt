package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONObject

@Entity(tableName = "Reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskTitle: String,
    val category: String, // "Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other"
    val taskDate: String, // E.g., "YYYY-MM-DD" or formatted "03 Jul 2026"
    val taskTime: String, // E.g., "HH:mm" or formatted "10:30 AM"
    val isCompleted: Boolean = false,
    val location: String = "",
    val amount: Double = 0.0,
    val dateTimeMillis: Long = 0L, // Absolute epoch timestamp for exact sorting and alarm trigger comparison
    
    // Multi-Reminder fields (Up to 3 per task)
    val reminder1Date: String,
    val reminder1Time: String,
    val reminder1Millis: Long = 0L,
    
    val reminder2Date: String = "",
    val reminder2Time: String = "",
    val reminder2Millis: Long = 0L,
    
    val reminder3Date: String = "",
    val reminder3Time: String = "",
    val reminder3Millis: Long = 0L,
    
    // Repeating & Custom tags fields (Added in Part 2)
    val repeatInterval: String = "None", // "None", "Daily", "Weekly", "Monthly"
    val tags: String = "", // Comma-separated tags (e.g. "Jenny Farm, Construction, Nifty SIP")
    
    // Media attachment field (Added in Part 3)
    val imageUri: String = ""
) {
    // Utility to convert to org.json.JSONObject for seamless import/export
    fun toJsonObject(): JSONObject {
        val json = JSONObject()
        json.put("id", id)
        json.put("taskTitle", taskTitle)
        json.put("category", category)
        json.put("taskDate", taskDate)
        json.put("taskTime", taskTime)
        json.put("isCompleted", isCompleted)
        json.put("location", location)
        json.put("amount", amount)
        json.put("dateTimeMillis", dateTimeMillis)
        
        json.put("reminder1Date", reminder1Date)
        json.put("reminder1Time", reminder1Time)
        json.put("reminder1Millis", reminder1Millis)
        
        json.put("reminder2Date", reminder2Date)
        json.put("reminder2Time", reminder2Time)
        json.put("reminder2Millis", reminder2Millis)
        
        json.put("reminder3Date", reminder3Date)
        json.put("reminder3Time", reminder3Time)
        json.put("reminder3Millis", reminder3Millis)

        json.put("repeatInterval", repeatInterval)
        json.put("tags", tags)
        json.put("imageUri", imageUri)
        return json
    }
}

// Global utility for decoding json objects safely
fun jsonObjectToReminder(json: JSONObject): Reminder {
    val tDate = json.optString("taskDate", "")
    val tTime = json.optString("taskTime", "")
    val tMillis = json.optLong("dateTimeMillis", 0L)

    return Reminder(
        id = json.optLong("id", 0L),
        taskTitle = json.optString("taskTitle", ""),
        category = json.optString("category", "Other"),
        taskDate = tDate,
        taskTime = tTime,
        isCompleted = json.optBoolean("isCompleted", false),
        location = json.optString("location", ""),
        amount = json.optDouble("amount", 0.0),
        dateTimeMillis = tMillis,
        
        reminder1Date = json.optString("reminder1Date", tDate),
        reminder1Time = json.optString("reminder1Time", tTime),
        reminder1Millis = json.optLong("reminder1Millis", tMillis),
        
        reminder2Date = json.optString("reminder2Date", ""),
        reminder2Time = json.optString("reminder2Time", ""),
        reminder2Millis = json.optLong("reminder2Millis", 0L),
        
        reminder3Date = json.optString("reminder3Date", ""),
        reminder3Time = json.optString("reminder3Time", ""),
        reminder3Millis = json.optLong("reminder3Millis", 0L),

        repeatInterval = json.optString("repeatInterval", "None"),
        tags = json.optString("tags", ""),
        imageUri = json.optString("imageUri", "")
    )
}

fun calculateNextOccurrence(reminder: Reminder): Reminder {
    val interval = reminder.repeatInterval
    if (interval == "None") return reminder

    val field = when (interval) {
        "Daily" -> java.util.Calendar.DAY_OF_YEAR
        "Weekly" -> java.util.Calendar.WEEK_OF_YEAR
        "Monthly" -> java.util.Calendar.MONTH
        else -> java.util.Calendar.DAY_OF_YEAR
    }
    val amount = 1
    val now = System.currentTimeMillis()

    // Calculate primary/dateTimeMillis
    val nextCal = java.util.Calendar.getInstance().apply {
        timeInMillis = if (reminder.dateTimeMillis > 0L) reminder.dateTimeMillis else now
    }
    while (nextCal.timeInMillis <= now) {
        nextCal.add(field, amount)
    }

    val dateFormatter = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
    val timeFormatter = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())

    val nextDate = dateFormatter.format(nextCal.time)
    val nextTime = timeFormatter.format(nextCal.time)
    val nextMillis = nextCal.timeInMillis

    // For multi-reminders, shift them as well
    val nextR1Cal = java.util.Calendar.getInstance().apply {
        timeInMillis = if (reminder.reminder1Millis > 0L) reminder.reminder1Millis else now
    }
    while (nextR1Cal.timeInMillis <= now) {
        nextR1Cal.add(field, amount)
    }
    val r1Date = dateFormatter.format(nextR1Cal.time)
    val r1Time = timeFormatter.format(nextR1Cal.time)
    val r1Millis = nextR1Cal.timeInMillis

    var r2Date = ""
    var r2Time = ""
    var r2Millis = 0L
    if (reminder.reminder2Millis > 0L) {
        val nextR2Cal = java.util.Calendar.getInstance().apply {
            timeInMillis = reminder.reminder2Millis
        }
        while (nextR2Cal.timeInMillis <= now) {
            nextR2Cal.add(field, amount)
        }
        r2Date = dateFormatter.format(nextR2Cal.time)
        r2Time = timeFormatter.format(nextR2Cal.time)
        r2Millis = nextR2Cal.timeInMillis
    }

    var r3Date = ""
    var r3Time = ""
    var r3Millis = 0L
    if (reminder.reminder3Millis > 0L) {
        val nextR3Cal = java.util.Calendar.getInstance().apply {
            timeInMillis = reminder.reminder3Millis
        }
        while (nextR3Cal.timeInMillis <= now) {
            nextR3Cal.add(field, amount)
        }
        r3Date = dateFormatter.format(nextR3Cal.time)
        r3Time = timeFormatter.format(nextR3Cal.time)
        r3Millis = nextR3Cal.timeInMillis
    }

    return reminder.copy(
        taskDate = r1Date,
        taskTime = r1Time,
        dateTimeMillis = r1Millis,
        reminder1Date = r1Date,
        reminder1Time = r1Time,
        reminder1Millis = r1Millis,
        reminder2Date = r2Date,
        reminder2Time = r2Time,
        reminder2Millis = r2Millis,
        reminder3Date = r3Date,
        reminder3Time = r3Time,
        reminder3Millis = r3Millis,
        isCompleted = false,
        imageUri = reminder.imageUri
    )
}

