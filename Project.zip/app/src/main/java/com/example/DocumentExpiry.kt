package com.example

import androidx.compose.runtime.Stable

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "document_expiry")
@Stable
data class DocumentExpiry(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val docName: String,
    val expiryDateInMillis: Long,
    val type: String
)
