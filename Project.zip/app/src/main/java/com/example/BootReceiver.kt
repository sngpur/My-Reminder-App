package com.example

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || 
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED) {
            
            val db = AppDatabase.getDatabase(context)
            val pendingResult = goAsync()
            
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    // 1. Reschedule Morning Briefing
                    try {
                        val morningScheduler = MorningBriefingScheduler(context)
                        morningScheduler.scheduleDailyBriefing()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    // 2. Reschedule Events (Birthdays/Anniversaries)
                    try {
                        val events = db.eventDao().getAllEventsSync()
                        events?.forEach { event ->
                            if (event.ringAlarm) {
                                AlarmScheduler.scheduleEventAlarm(context, event)
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    // 3. Reschedule Vehicle Servicing Reminders
                    try {
                        val serviceRecords = db.serviceRecordDao().getAllServiceRecordsSync()
                        serviceRecords?.forEach { record ->
                            ServicingAlarmScheduler.scheduleServicingAlarm(context, record)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    // 4. Reschedule Document Expirations
                    try {
                        val documents = db.documentExpiryDao().getAllDocumentsSync()
                        val docScheduler = DocumentExpiryAlarmScheduler(context)
                        documents?.forEach { doc ->
                            docScheduler.schedule(doc)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    // 5. Reschedule WhatsApp Schedules
                    try {
                        val pendingWhatsApp = db.whatsappScheduleDao().getPendingSchedulesSync()
                        val waScheduler = WhatsAppAlarmScheduler(context)
                        pendingWhatsApp?.forEach { schedule ->
                            waScheduler.schedule(schedule)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    // 6. Reschedule Tasks/Reminders
                    try {
                        val reminders = db.reminderDao().getAllRemindersSync()
                        reminders?.forEach { reminder ->
                            if (!reminder.isCompleted && !reminder.isDeleted) {
                                scheduleReminderNotification(context, reminder)
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }

    private fun scheduleReminderNotification(context: Context, reminder: Reminder) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val timesToSchedule = mutableListOf<Pair<Int, Long>>()
        
        try {
            val date1 = LocalDate.parse(reminder.taskDate)
            val time1 = LocalTime.parse(reminder.taskTime)
            val timeInMillis1 = LocalDateTime.of(date1, time1).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            timesToSchedule.add(Pair(reminder.id * 10 + 1, timeInMillis1))

            if (reminder.reminder2Date != null && reminder.reminder2Time != null) {
                val date2 = LocalDate.parse(reminder.reminder2Date)
                val time2 = LocalTime.parse(reminder.reminder2Time)
                val timeInMillis2 = LocalDateTime.of(date2, time2).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                timesToSchedule.add(Pair(reminder.id * 10 + 2, timeInMillis2))
            }

            if (reminder.reminder3Date != null && reminder.reminder3Time != null) {
                val date3 = LocalDate.parse(reminder.reminder3Date)
                val time3 = LocalTime.parse(reminder.reminder3Time)
                val timeInMillis3 = LocalDateTime.of(date3, time3).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                timesToSchedule.add(Pair(reminder.id * 10 + 3, timeInMillis3))
            }

            for ((alarmId, timeInMillis) in timesToSchedule) {
                if (timeInMillis > System.currentTimeMillis()) {
                    val intent = Intent(context, NotificationReceiver::class.java).apply {
                        putExtra("title", reminder.taskTitle)
                        putExtra("category", reminder.category)
                        putExtra("id", reminder.id)
                        putExtra("isAlarmEnabled", reminder.isAlarmEnabled)
                    }
                    
                    val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        alarmId,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                        } catch (se: SecurityException) {
                            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                        }
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
