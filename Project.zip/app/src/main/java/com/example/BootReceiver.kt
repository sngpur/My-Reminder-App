package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.firstOrNull

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val db = AppDatabase.getDatabase(context)
            val eventDao = db.eventDao()
            
            val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                try {
                    val events = eventDao.getAllEventsSync()
                    events?.forEach { event ->
                        AlarmScheduler.scheduleEventAlarm(context, event)
                    }

                    val serviceRecords = db.serviceRecordDao().getAllServiceRecordsSync()
                    serviceRecords?.forEach { record ->
                        ServicingAlarmScheduler.scheduleServicingAlarm(context, record)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } finally {
                pendingResult.finish()
            }
        }
        }
    }
}
