package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationManager
import android.app.NotificationChannel
import androidx.core.app.NotificationCompat
import android.app.PendingIntent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Reminder"
        val category = intent.getStringExtra("category") ?: ""
        val id = intent.getIntExtra("id", 0)
        val isAlarmEnabled = intent.getBooleanExtra("isAlarmEnabled", false)

        if (isAlarmEnabled) {
            val serviceIntent = Intent(context, AlarmService::class.java).apply {
                putExtra("title", title)
                putExtra("category", category)
                putExtra("id", id)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } else {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "standard_reminder_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "Standard Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Task reminders without full-screen alarm"
                }
                notificationManager.createNotificationChannel(channel)
            }
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context, id, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(category)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent)
                .build()
            notificationManager.notify(id, notification)
        }

        // Advance repeating tasks when alarm triggers
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val dao = db.reminderDao()
                val reminder = dao.getReminderById(id)
                if (reminder != null && reminder.repeatInterval != "None") {
                    val currentDate = LocalDate.parse(reminder.taskDate)
                    val nextDate = when (reminder.repeatInterval) {
                        "Daily" -> currentDate.plusDays(1)
                        "Weekly" -> currentDate.plusWeeks(1)
                        "Monthly" -> currentDate.plusMonths(1)
                        "Quarterly" -> currentDate.plusMonths(3)
                        "Half Yearly" -> currentDate.plusMonths(6)
                        "Yearly" -> currentDate.plusYears(1)
                        else -> currentDate
                    }
                    val updatedReminder = reminder.copy(taskDate = nextDate.toString())
                    dao.updateReminder(updatedReminder)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
