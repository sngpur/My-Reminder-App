package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Reminder"
        val category = intent.getStringExtra("category") ?: ""
        val id = intent.getIntExtra("id", 0)

        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            putExtra("title", title)
            putExtra("category", category)
            putExtra("id", id)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(context, serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
        
        // Advance repeating tasks when alarm triggers
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context)
                val dao = db.reminderDao()
                val reminder = dao.getReminderById(id)
                if (reminder != null && reminder.repeatInterval != "None") {
                    val currentDate = LocalDate.parse(reminder.taskDate)
                    val nextDate = when (reminder.repeatInterval) {
                        "Daily" -> currentDate.plusDays(1)
                        "Weekly" -> currentDate.plusWeeks(1)
                        "Monthly" -> currentDate.plusMonths(1)
                        "Quarterly" -> currentDate.plusMonths(3)
                        "Half Yearly" -> currentDate.plusMonths(6)
                        "Yearly" -> currentDate.plusYears(1)
                        else -> currentDate
                    }
                    val updatedReminder = reminder.copy(taskDate = nextDate.toString())
                    dao.updateReminder(updatedReminder)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
