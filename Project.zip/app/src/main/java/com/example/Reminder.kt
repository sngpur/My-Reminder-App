package com.example

import androidx.compose.runtime.Stable

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

@Stable
data class ActiveReminderInfo(
    val dateTime: LocalDateTime,
    val isPassed: Boolean
)

@Entity(tableName = "reminders")
@Stable
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val taskTitle: String,
    val category: String, // "Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other"
    val taskDate: String, // ISO String yyyy-MM-dd
    val taskTime: String, // ISO String HH:mm
    val reminder2Date: String? = null,
    val reminder2Time: String? = null,
    val reminder3Date: String? = null,
    val reminder3Time: String? = null,
    val isCompleted: Boolean = false,
    val location: String = "",
    val amount: Double? = null,
    val repeatInterval: String = "None",
    val imageUri: String? = null,
    val isAlarmEnabled: Boolean = false,
    val tags: String = "",
    val isDeleted: Boolean = false
) {
    fun getNextActiveReminder(): ActiveReminderInfo {
        val now = LocalDateTime.now()
        val primaryDt = try {
            LocalDateTime.of(LocalDate.parse(taskDate), LocalTime.parse(taskTime))
        } catch (e: Exception) {
            LocalDateTime.now() // Fallback
        }
        
        if (primaryDt.isAfter(now)) {
            return ActiveReminderInfo(primaryDt, false)
        }
        
        if (!reminder2Date.isNullOrBlank() && !reminder2Time.isNullOrBlank()) {
            try {
                val r2Dt = LocalDateTime.of(LocalDate.parse(reminder2Date), LocalTime.parse(reminder2Time))
                if (r2Dt.isAfter(now)) {
                    return ActiveReminderInfo(r2Dt, false)
                }
            } catch (e: Exception) {}
        }
        
        if (!reminder3Date.isNullOrBlank() && !reminder3Time.isNullOrBlank()) {
            try {
                val r3Dt = LocalDateTime.of(LocalDate.parse(reminder3Date), LocalTime.parse(reminder3Time))
                if (r3Dt.isAfter(now)) {
                    return ActiveReminderInfo(r3Dt, false)
                }
            } catch (e: Exception) {}
        }
        
        val lastDt = if (!reminder3Date.isNullOrBlank() && !reminder3Time.isNullOrBlank()) {
            try { LocalDateTime.of(LocalDate.parse(reminder3Date), LocalTime.parse(reminder3Time)) } catch(e: Exception) { primaryDt }
        } else if (!reminder2Date.isNullOrBlank() && !reminder2Time.isNullOrBlank()) {
            try { LocalDateTime.of(LocalDate.parse(reminder2Date), LocalTime.parse(reminder2Time)) } catch(e: Exception) { primaryDt }
        } else {
            primaryDt
        }
        
        return ActiveReminderInfo(lastDt, true)
    }
}
