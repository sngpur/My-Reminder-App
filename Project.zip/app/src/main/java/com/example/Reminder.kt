package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val taskTitle: String,
    val category: String, // "Upcoming Payment", "Money Lent (Udhar)", "Personal Work", "Other"
    val taskDate: String, // ISO String yyyy-MM-dd
    val taskTime: String, // ISO String HH:mm
    val reminder2Date: String? = null,
    val reminder2Time: String? = null,
    val reminder3Date: String? = null,
    val reminder3Time: String? = null,
    val isCompleted: Boolean = false,
    val location: String = "",
    val amount: Double? = null,
    val repeatInterval: String = "None",
    val imageUri: String? = null,
    val tags: String = "" // comma-separated
)
