package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SecureVaultViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).vaultRecordDao()
    
    val allRecords: StateFlow<List<VaultRecord>> = dao.getAllVaultRecords()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun insertRecord(record: VaultRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.insertVaultRecord(record)
        }
    }

    fun updateRecord(record: VaultRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.updateVaultRecord(record)
        }
    }

    fun deleteRecord(record: VaultRecord) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.deleteVaultRecord(record)
        }
    }
}
