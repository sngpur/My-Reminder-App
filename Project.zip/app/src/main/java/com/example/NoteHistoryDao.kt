package com.example

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteHistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNoteHistory(history: NoteHistory)

    @Query("SELECT * FROM note_history WHERE noteId = :noteId ORDER BY timestampInMillis DESC")
    fun getHistoryForNote(noteId: Int): Flow<List<NoteHistory>>
    
    @Query("DELETE FROM note_history WHERE noteId = :noteId")
    suspend fun deleteHistoryForNote(noteId: Int)
}
