package com.example

import androidx.compose.runtime.Stable

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
@Stable
data class Note(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val noteType: String, // "Text", "List", "Image", "Drawing"
    val content: String,
    val dateMillis: Long,
    val isDeleted: Boolean = false
)
