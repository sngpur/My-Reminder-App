package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val noteType: String, // "Text", "List", "Image", "Drawing"
    val content: String,
    val dateMillis: Long
)
