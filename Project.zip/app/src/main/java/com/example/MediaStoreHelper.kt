package com.example

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream

object MediaStoreHelper {
    suspend fun saveToPublicDocuments(
        context: Context,
        sourceUri: Uri,
        fileName: String,
        mimeType: String
    ): Uri? {
        return withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOCUMENTS}/MyBuddyScanner")
                }
                
                val collection = MediaStore.Files.getContentUri("external")
                val destUri = resolver.insert(collection, contentValues) ?: return@withContext null
                
                resolver.openInputStream(sourceUri)?.use { inputStream ->
                    resolver.openOutputStream(destUri)?.use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
                
                destUri
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}
