package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.util.Log
import com.example.MainActivity

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra("reminder_id", -1L)
        val title = intent.getStringExtra("reminder_title") ?: "Reminder Alert"
        val category = intent.getStringExtra("reminder_category") ?: "Other"
        val location = intent.getStringExtra("reminder_location") ?: ""

        Log.d("AlarmReceiver", "Received alarm trigger broadcast for: $title (ID: $reminderId)")

        // Acquire WakeLock to keep CPU awake while we start the service and launch the activity
        var wakeLock: PowerManager.WakeLock? = null
        try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "SomnathReminder:AlarmReceiverWakeLock"
            )
            wakeLock.acquire(10000L) // 10 seconds timeout is safe
            Log.d("AlarmReceiver", "Temporary WakeLock acquired")
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Failed to acquire temporary WakeLock", e)
        }

        // Start Foreground Service to play alarm sound and show stop action
        try {
            val serviceIntent = Intent(context, AlarmService::class.java).apply {
                action = AlarmService.ACTION_START_ALARM
                putExtra("reminder_id", reminderId)
                putExtra("reminder_title", title)
                putExtra("reminder_category", category)
                putExtra("reminder_location", location)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            Log.d("AlarmReceiver", "Foreground AlarmService start intent sent")
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Failed to start AlarmService", e)
        }

        // Auto-start MainActivity to turn the screen on and show on lock screen
        try {
            val mainActivityIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("is_alarm_trigger", true)
            }
            context.startActivity(mainActivityIntent)
            Log.d("AlarmReceiver", "MainActivity launch intent sent to turn on screen")
        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Failed to start MainActivity from receiver", e)
        } finally {
            if (wakeLock?.isHeld == true) {
                wakeLock.release()
                Log.d("AlarmReceiver", "Temporary WakeLock released")
            }
        }
    }
}
