package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.Reminder

class NotificationHelper(private val context: Context) {
    companion object {
        const val CHANNEL_ID = "somnath_reminders_channel"
        const val CHANNEL_NAME = "Somnath Reminders Alerts"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notification channel for Somnath Reminder alerts"
                enableVibration(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun scheduleAlarm(reminder: Reminder) {
        // Schedule up to 3 alarms based on the valid reminder milliseconds
        scheduleSingleAlarm(reminder.id, 1, reminder.reminder1Millis, reminder)
        scheduleSingleAlarm(reminder.id, 2, reminder.reminder2Millis, reminder)
        scheduleSingleAlarm(reminder.id, 3, reminder.reminder3Millis, reminder)
    }

    private fun scheduleSingleAlarm(reminderId: Long, index: Int, triggerMillis: Long, reminder: Reminder) {
        // Only schedule for future events
        if (triggerMillis <= System.currentTimeMillis()) {
            Log.d("NotificationHelper", "Skip alarm $index for id $reminderId (trigger time is in the past: $triggerMillis)")
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("reminder_id", reminderId)
            putExtra("reminder_index", index)
            putExtra("reminder_title", reminder.taskTitle)
            putExtra("reminder_category", reminder.category)
            putExtra("reminder_location", reminder.location)
        }

        // Generate unique request code: TaskId + Index
        val requestCode = (reminderId * 10 + index).toInt()
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            // Allows execution while device is in idle doze mode
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerMillis, pendingIntent)
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
                Log.d("NotificationHelper", "Scheduled setAlarmClock alarm $index for id $reminderId at $triggerMillis")
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
                Log.d("NotificationHelper", "Scheduled setExactAndAllowWhileIdle alarm $index for id $reminderId at $triggerMillis")
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
                Log.d("NotificationHelper", "Scheduled setExact alarm $index for id $reminderId at $triggerMillis")
            }
        } catch (e: SecurityException) {
            // Under SDK 31+, exact alarms can fail if permission is missing. Fallback to normal alarms.
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerMillis,
                pendingIntent
            )
            Log.w("NotificationHelper", "Exact alarm security exception, fell back to standard alarm: ${e.message}")
        }
    }

    fun cancelAlarm(reminderId: Long) {
        cancelSingleAlarm(reminderId, 1)
        cancelSingleAlarm(reminderId, 2)
        cancelSingleAlarm(reminderId, 3)
    }

    private fun cancelSingleAlarm(reminderId: Long, index: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val requestCode = (reminderId * 10 + index).toInt()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
            Log.d("NotificationHelper", "Cancelled alarm $index for id: $reminderId (Request Code: $requestCode)")
        }
    }
}
