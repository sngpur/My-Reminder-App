package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.Reminder

class NotificationHelper(private val context: Context) {
    companion object {
        const val CHANNEL_ID = "somnath_reminders_channel"
        const val CHANNEL_NAME = "Somnath Reminders Alerts"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notification channel for Somnath Reminder alerts"
                enableVibration(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun scheduleAlarm(reminder: Reminder) {
        // Only schedule for future events
        if (reminder.dateTimeMillis <= System.currentTimeMillis()) {
            return
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("reminder_id", reminder.id)
            putExtra("reminder_title", reminder.taskTitle)
            putExtra("reminder_category", reminder.category)
            putExtra("reminder_location", reminder.location)
        }

        // Use unique request code for each alarm to avoid overwriting them
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminder.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Allows execution while device is in idle doze mode
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminder.dateTimeMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    reminder.dateTimeMillis,
                    pendingIntent
                )
            }
            Log.d("NotificationHelper", "Successfully scheduled alarm for id: ${reminder.id} at ${reminder.dateTimeMillis}")
        } catch (e: SecurityException) {
            // Under SDK 31+, exact alarms can fail if permission is missing. Fallback to normal alarms.
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                reminder.dateTimeMillis,
                pendingIntent
            )
            Log.w("NotificationHelper", "Exact alarm security exception, fell back to inexact alarm: ${e.message}")
        }
    }

    fun cancelAlarm(reminderId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
