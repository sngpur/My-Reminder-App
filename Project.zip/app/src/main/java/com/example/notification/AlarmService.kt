package com.example.notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppDatabase
import com.example.data.calculateNextOccurrence
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        const val CHANNEL_ID = "somnath_alarm_service_channel"
        const val CHANNEL_NAME = "Somnath Active Alarms"
        const val NOTIFICATION_ID = 9999
        
        const val ACTION_START_ALARM = "com.example.notification.ACTION_START_ALARM"
        const val ACTION_STOP_ALARM = "com.example.notification.ACTION_STOP_ALARM"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Log.d("AlarmService", "AlarmService created")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        Log.d("AlarmService", "onStartCommand action: $action")

        if (action == ACTION_STOP_ALARM) {
            stopAlarm()
            return START_NOT_STICKY
        }

        val reminderId = intent?.getLongExtra("reminder_id", -1L) ?: -1L
        val title = intent?.getStringExtra("reminder_title") ?: "Reminder Alert"
        val category = intent?.getStringExtra("reminder_category") ?: "Other"
        val location = intent?.getStringExtra("reminder_location") ?: ""

        // Acquire WakeLock to keep CPU awake while playing alarm
        acquireWakeLock()

        // Play loud loop audio
        playAlarmAudio()

        // Build and display Foreground notification
        val notification = buildForegroundNotification(reminderId, title, category, location)
        
        startForeground(NOTIFICATION_ID, notification)

        // Reschedule repeating alarm if applicable
        handleRepeatingAlarmReschedule(reminderId)

        return START_STICKY
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) {
                wakeLock = powerManager.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "SomnathReminder:AlarmServiceWakeLock"
                )
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(10 * 60 * 1000L) // Limit to 10 minutes max
                Log.d("AlarmService", "WakeLock acquired")
            }
        } catch (e: Exception) {
            Log.e("AlarmService", "Failed to acquire wake lock", e)
        }
    }

    private fun playAlarmAudio() {
        if (mediaPlayer != null) return
        try {
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            
            mediaPlayer = MediaPlayer().apply {
                setDataSource(this@AlarmService, alarmUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
            Log.d("AlarmService", "Media player playing alarm loop")
        } catch (e: Exception) {
            Log.e("AlarmService", "Error preparing media player", e)
        }
    }

    private fun buildForegroundNotification(
        reminderId: Long,
        title: String,
        category: String,
        location: String
    ): Notification {
        val clickIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("is_alarm_trigger", true)
        }
        val clickPendingIntent = PendingIntent.getActivity(
            this,
            reminderId.toInt(),
            clickIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AlarmService::class.java).apply {
            action = ACTION_STOP_ALARM
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            0,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val contentText = buildString {
            append("Category: $category")
            if (location.isNotEmpty()) {
                append(" • Location: $location")
            }
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ $title")
            .setContentText(contentText)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(clickPendingIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "STOP ALARM",
                stopPendingIntent
            )
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Foreground Service Alarm Alerts"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(true)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopAlarm() {
        Log.d("AlarmService", "Stopping audio alarm")
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            Log.e("AlarmService", "Error release mediaPlayer", e)
        } finally {
            mediaPlayer = null
        }

        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        wakeLock = null

        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAlarm()
        Log.d("AlarmService", "AlarmService destroyed")
    }

    private fun handleRepeatingAlarmReschedule(reminderId: Long) {
        if (reminderId == -1L) return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(applicationContext)
                val reminder = db.reminderDao().getReminderById(reminderId)
                if (reminder != null && reminder.repeatInterval != "None") {
                    val nextReminder = calculateNextOccurrence(reminder)
                    db.reminderDao().updateReminder(nextReminder)
                    
                    val notificationHelper = NotificationHelper(applicationContext)
                    notificationHelper.scheduleAlarm(nextReminder)
                    Log.d("AlarmService", "Repeating task auto-rescheduled upon trigger: ${nextReminder.taskDate}")
                }
            } catch (e: Exception) {
                Log.e("AlarmService", "Error in handleRepeatingAlarmReschedule", e)
            }
        }
    }
}
