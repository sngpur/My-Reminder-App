package com.example

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WhatsAppActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val scheduleId = intent.getIntExtra("scheduleId", -1)
        val phoneNumber = intent.getStringExtra("phoneNumber") ?: return
        val message = intent.getStringExtra("message") ?: return

        // 1. Launch WhatsApp
        try {
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$phoneNumber&text=${Uri.encode(message)}")
            val whatsappIntent = Intent(Intent.ACTION_VIEW, uri)
            whatsappIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(whatsappIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Mark as sent in DB
        if (scheduleId != -1) {
            val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDatabase.getDatabase(context).whatsappScheduleDao().markAsSent(scheduleId)
            } finally {
                pendingResult.finish()
            }
        }
        }

        // 3. Cancel notification
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(scheduleId)
        
        // Collapse notification bar (optional but good for UX)
        val closeIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        context.sendBroadcast(closeIntent)
    }
}
