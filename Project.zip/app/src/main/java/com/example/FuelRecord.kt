package com.example

import androidx.compose.runtime.Stable

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fuel_records")
@Stable
data class FuelRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val vehicleType: String,
    val dateMillis: Long,
    val odometerKm: Int,
    val fuelLiters: Double
)
