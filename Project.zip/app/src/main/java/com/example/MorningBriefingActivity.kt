package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme

class MorningBriefingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MyApplicationTheme(isDarkModeOverride = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MorningBriefingScreen(
                        onDismiss = { finish() }
                    )
                }
            }
        }
    }
}

@Composable
fun MorningBriefingScreen(
    onDismiss: () -> Unit,
    viewModel: MorningBriefingViewModel = viewModel()
) {
    val todayTasks by viewModel.todayTasks.collectAsStateWithLifecycle()
    val todayEvents by viewModel.todayEvents.collectAsStateWithLifecycle()
    val todayServicing by viewModel.todayServicing.collectAsStateWithLifecycle()
    val payments by viewModel.pendingPayments.collectAsStateWithLifecycle()
    val receivables by viewModel.pendingReceivables.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Daily Briefing",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Good Morning, Buddy!",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
        }

        // Today's Overview
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Today's Overview",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Tasks Due:")
                        Text("${todayTasks.size}", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Birthdays/Anniversaries:")
                        Text("${todayEvents.size}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Pending Finances
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Pending Finances",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("To Pay:")
                        Text("₹${payments.toInt()}", color = Color(0xFFE57373), fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("To Receive:")
                        Text("₹${receivables.toInt()}", color = Color(0xFF81C784), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Today's Agenda Section Title
        item {
            Text(
                text = "Today's Agenda",
                color = Color.White,
                fontSize = 18.sp,
                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
            )
        }

        val allEmpty = todayTasks.isEmpty() && todayEvents.isEmpty() && todayServicing.isEmpty()

        if (allEmpty) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "You have a free day today! 🎉",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
        } else {
            // a) Tasks
            items(todayTasks, key = { "task_${it.id}" }) { task ->
                AgendaItemCard(
                    icon = "📝",
                    title = task.taskTitle,
                    subtitle = if (task.taskTime.isNotEmpty()) task.taskTime else "All day"
                )
            }

            // b) Events (Birthday / Anniversary)
            items(todayEvents, key = { "event_${it.id}" }) { event ->
                AgendaItemCard(
                    icon = "🎂",
                    title = "${event.eventType}: ${event.name}",
                    subtitle = event.relationship
                )
            }

            // c) Servicing
            items(todayServicing, key = { "service_${it.id}" }) { service ->
                AgendaItemCard(
                    icon = "🔧",
                    title = "${service.vehicleType} Servicing Due",
                    subtitle = "Last serviced: ${service.lastServiceDate}"
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Let's Go!")
            }
        }
    }
}

@Composable
fun AgendaItemCard(
    icon: String,
    title: String,
    subtitle: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = icon,
                fontSize = 24.sp,
                modifier = Modifier.padding(end = 16.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (subtitle.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

