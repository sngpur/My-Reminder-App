package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmStopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getIntExtra("id", 0)
        val title = intent.getStringExtra("title") ?: "Reminder"
        val category = intent.getStringExtra("category") ?: ""
        
        // Stop the alarm service (which stops media player and vibrator)
        val serviceIntent = Intent(context, AlarmService::class.java)
        context.stopService(serviceIntent)
        
        // CRUCIAL: Remove the notificationManager.cancel(notificationId) call.
        // Instead, re-issue the notification as a regular, non-ongoing notification so it stays in the tray.
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", taskId)
            putExtra("EXTRA_ENTITY_TYPE", "Task")
            putExtra("EXTRA_IS_RINGING", false)
            }
        val pendingIntent = android.app.PendingIntent.getActivity(
            context, taskId, launchIntent, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        
        val completeIntent = Intent(context, MarkCompleteReceiver::class.java).apply {
            putExtra("id", taskId)
        }
        val completePendingIntent = android.app.PendingIntent.getBroadcast(
            context, taskId, completeIntent, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        
        val notification = androidx.core.app.NotificationCompat.Builder(context, "reminder_alarm_channel")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(category)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_edit, "Mark Complete", completePendingIntent)
            .build()
            
        // Post it with the same ID so it replaces the foreground service notification in the tray
        notificationManager.notify(taskId + 10000, notification)
    }
}
