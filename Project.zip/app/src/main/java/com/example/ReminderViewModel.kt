package com.example

import android.app.AlarmManager
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import java.time.temporal.ChronoUnit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class ReminderViewModel(
    application: Application,
    private val repository: ReminderRepository
) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val reminderDao = db.reminderDao()
    private val eventDao = db.eventDao()
    private val fuelRecordDao = db.fuelRecordDao()
    private val serviceRecordDao = db.serviceRecordDao()

    val bikeServiceRecord = serviceRecordDao.getServiceRecord("Bike")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val carServiceRecord = serviceRecordDao.getServiceRecord("Car")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val nearestBirthday = eventDao.getAllEvents().map { events ->
        events.findNearest("Birthday")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val nearestAnniversary = eventDao.getAllEvents().map { events ->
        events.findNearest("Anniversary")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val latestBikeMileage = fuelRecordDao.getAllFuelRecords().map { records ->
        calculateAverageMileage(records.filter { it.vehicleType == "Bike" })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val latestCarMileage = fuelRecordDao.getAllFuelRecords().map { records ->
        calculateAverageMileage(records.filter { it.vehicleType == "Car" })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private fun calculateAverageMileage(records: List<FuelRecord>): Double? {
        if (records.size < 2) return null
        val sorted = records.sortedBy { it.odometerKm }
        val distance = (sorted.last().odometerKm - sorted.first().odometerKm).toDouble()
        val fuel = sorted.dropLast(1).sumOf { it.fuelLiters }
        return if (fuel == 0.0) null else distance / fuel
    }


    val uiState: StateFlow<List<Reminder>> = repository.allReminders
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        
    val trashedReminders: kotlinx.coroutines.flow.StateFlow<List<Reminder>> = reminderDao.getTrashedReminders()
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val currentReminders = repository.allReminders.first()
                if (currentReminders.isEmpty()) {
                    val today = LocalDate.now().toString()
                    val tomorrow = LocalDate.now().plusDays(1).toString()
                    
                    val dummies = listOf(
                        Reminder(taskTitle = "Payment for 70x70 plot construction materials", category = "Upcoming Payment", taskDate = tomorrow, taskTime = "10:00", location = "Jamtara, Jharkhand", amount = 15000.0),
                        Reminder(taskTitle = "Sonali chicken feed order for Jenny Farm", category = "Personal Work", taskDate = today, taskTime = "16:00", location = "Jamtara, Jharkhand"),
                        Reminder(taskTitle = "Money lent to Suresh for emergency", category = "Money Lent (Udhar)", taskDate = tomorrow, taskTime = "18:00", amount = 5000.0),
                        Reminder(taskTitle = "Railway duty roster update", category = "Personal Work", taskDate = today, taskTime = "20:00")
                    )
                    dummies.forEach { addReminder(it) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun addReminder(reminder: Reminder) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val id = repository.insert(reminder)
            scheduleNotification(reminder.copy(id = id.toInt()))
        }
    }

    fun updateReminder(reminder: Reminder) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.update(reminder)
            scheduleNotification(reminder)
        }
    }

    fun toggleCompletion(id: Int, isCompleted: Boolean) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            if (isCompleted) {
                val currentReminders = uiState.value
                val reminder = currentReminders.find { it.id == id }
                if (reminder != null && reminder.repeatInterval != "None") {
                    try {
                        val currentDate = LocalDate.parse(reminder.taskDate)
                        val nextDate = when (reminder.repeatInterval) {
                            "Daily" -> currentDate.plusDays(1)
                            "Weekly" -> currentDate.plusWeeks(1)
                            "Monthly" -> currentDate.plusMonths(1)
                            "Quarterly" -> currentDate.plusMonths(3)
                            "Half Yearly" -> currentDate.plusMonths(6)
                            "Yearly" -> currentDate.plusYears(1)
                            else -> currentDate
                        }
                        
                        // We mark this current one complete (if user wants history) 
                        // and create a new one for the future.
                        // Wait, it might be simpler to just advance the date of the CURRENT task 
                        // and keep it isCompleted = false. Let's do that for simplicity and avoiding clutter.
                        val updatedReminder = reminder.copy(
                            taskDate = nextDate.toString(),
                            isCompleted = false
                        )
                        repository.update(updatedReminder)
                        scheduleNotification(updatedReminder)
                        return@launch
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
            repository.updateCompletionStatus(id, isCompleted)
        }
    }

    fun permanentlyDeleteReminder(id: Int) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) { reminderDao.permanentlyDeleteReminderById(id) }
    }
    
    fun restoreReminder(id: Int) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) { reminderDao.restoreReminderById(id) }
    }
    
    fun deleteReminder(reminder: Reminder) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.deleteById(reminder.id)
            cancelNotification(reminder.id)
        }
    }

    private fun scheduleNotification(reminder: Reminder) {
        val context = getApplication<Application>()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val timesToSchedule = mutableListOf<Pair<Int, Long>>()
        
        try {
            val date1 = LocalDate.parse(reminder.taskDate)
            val time1 = LocalTime.parse(reminder.taskTime)
            val timeInMillis1 = LocalDateTime.of(date1, time1).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            timesToSchedule.add(Pair(reminder.id * 10 + 1, timeInMillis1))

            if (reminder.reminder2Date != null && reminder.reminder2Time != null) {
                val date2 = LocalDate.parse(reminder.reminder2Date)
                val time2 = LocalTime.parse(reminder.reminder2Time)
                val timeInMillis2 = LocalDateTime.of(date2, time2).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                timesToSchedule.add(Pair(reminder.id * 10 + 2, timeInMillis2))
            }

            if (reminder.reminder3Date != null && reminder.reminder3Time != null) {
                val date3 = LocalDate.parse(reminder.reminder3Date)
                val time3 = LocalTime.parse(reminder.reminder3Time)
                val timeInMillis3 = LocalDateTime.of(date3, time3).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                timesToSchedule.add(Pair(reminder.id * 10 + 3, timeInMillis3))
            }

            for ((alarmId, timeInMillis) in timesToSchedule) {
                val intent = Intent(context, NotificationReceiver::class.java).apply {
                    putExtra("title", reminder.taskTitle)
                    putExtra("category", reminder.category)
                    putExtra("id", reminder.id)
                    putExtra("isAlarmEnabled", reminder.isAlarmEnabled)
                }
                
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    alarmId,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                if (timeInMillis > System.currentTimeMillis()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    private fun cancelNotification(id: Int) {
        val context = getApplication<Application>()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, NotificationReceiver::class.java)
        
        for (i in 1..3) {
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                id * 10 + i,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
        }
    }
}
