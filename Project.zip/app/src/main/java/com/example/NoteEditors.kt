package com.example

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteTextEditorScreen(navController: NavController, viewModel: NoteViewModel, noteId: Int? = null) {
    val notes by viewModel.allNotes.collectAsStateWithLifecycle()
    val existingNote = remember(notes, noteId) { notes.find { it.id == noteId } }

    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var initialized by remember { mutableStateOf(false) }

    LaunchedEffect(existingNote) {
        if (!initialized && existingNote != null) {
            title = existingNote.title
            content = existingNote.content
            initialized = true
        }
    }

    val saveAndExit = {
        if (title.isBlank() && content.isBlank()) {
            navController.navigateUp()
        } else {
            val finalTitle = generateTitle(title, content, "Text Note")
            val currentNote = Note(
                id = noteId ?: 0,
                title = finalTitle,
                noteType = "Text",
                content = content,
                dateMillis = System.currentTimeMillis()
            )
            if (noteId != null && noteId != 0) {
                viewModel.updateNote(currentNote)
            } else {
                viewModel.addNote(currentNote)
            }
            navController.navigateUp()
        }
    }

    BackHandler { saveAndExit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (noteId != null) "Edit Text Note" else "New Text Note") },
                navigationIcon = {
                    IconButton(onClick = { saveAndExit() }) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    TextButton(onClick = { saveAndExit() }) { Text("Save") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("Note content...") },
                modifier = Modifier.fillMaxWidth().weight(1f),
                textStyle = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

data class DrawnPath(val points: List<Offset>, val color: Color)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDrawingEditorScreen(navController: NavController, viewModel: NoteViewModel, noteId: Int? = null) {
    val notes by viewModel.allNotes.collectAsStateWithLifecycle()
    val existingNote = remember(notes, noteId) { notes.find { it.id == noteId } }

    var title by remember { mutableStateOf("") }
    var currentPathPoints by remember { mutableStateOf(emptyList<Offset>()) }
    val completedPaths = remember { mutableStateListOf<DrawnPath>() }
    var selectedColor by remember { mutableStateOf(Color.Black) }
    var initialized by remember { mutableStateOf(false) }

    val colors = listOf(Color.Black, Color.Red, Color.Blue, Color.Green, Color.Yellow)

    LaunchedEffect(existingNote) {
        if (!initialized && existingNote != null) {
            title = existingNote.title
            try {
                val jsonArray = JSONArray(existingNote.content)
                for (i in 0 until jsonArray.length()) {
                    val pathObj = jsonArray.getJSONObject(i)
                    val colorInt = pathObj.getInt("color")
                    val pointsArray = pathObj.getJSONArray("points")
                    val pts = mutableListOf<Offset>()
                    for (j in 0 until pointsArray.length()) {
                        val ptObj = pointsArray.getJSONObject(j)
                        pts.add(Offset(ptObj.getDouble("x").toFloat(), ptObj.getDouble("y").toFloat()))
                    }
                    completedPaths.add(DrawnPath(pts, Color(colorInt)))
                }
            } catch (e: Exception) {
                // ignore parsing error
            }
            initialized = true
        }
    }

    val saveAndExit = {
        if (title.isBlank() && completedPaths.isEmpty() && currentPathPoints.isEmpty()) {
            navController.navigateUp()
        } else {
            val finalTitle = generateTitle(title, "", "Drawing Note")
            
            // Serialize paths
            val jsonArray = JSONArray()
            completedPaths.forEach { path ->
                val pathObj = JSONObject()
                pathObj.put("color", path.color.toArgb())
                val pointsArray = JSONArray()
                path.points.forEach { pt ->
                    val ptObj = JSONObject()
                    ptObj.put("x", pt.x.toDouble())
                    ptObj.put("y", pt.y.toDouble())
                    pointsArray.put(ptObj)
                }
                pathObj.put("points", pointsArray)
                jsonArray.put(pathObj)
            }
            val serializedContent = jsonArray.toString()
            
            val currentNote = Note(
                id = noteId ?: 0,
                title = finalTitle,
                noteType = "Drawing",
                content = serializedContent,
                dateMillis = System.currentTimeMillis()
            )
            
            if (noteId != null && noteId != 0) {
                viewModel.updateNote(currentNote)
            } else {
                viewModel.addNote(currentNote)
            }
            navController.navigateUp()
        }
    }

    BackHandler { saveAndExit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (noteId != null) "Edit Drawing Note" else "New Drawing Note") },
                navigationIcon = {
                    IconButton(onClick = { saveAndExit() }) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    IconButton(onClick = { if (completedPaths.isNotEmpty()) completedPaths.removeLast() }) { Icon(Icons.Filled.Undo, "Undo") }
                    IconButton(onClick = { completedPaths.clear(); currentPathPoints = emptyList() }) { Icon(Icons.Filled.DeleteOutline, "Clear") }
                    TextButton(onClick = { saveAndExit() }) { Text("Save") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            // Color picker
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                colors.forEach { color ->
                    Box(
                        modifier = Modifier.size(36.dp).clip(CircleShape).background(color).clickable { selectedColor = color }
                            .padding(2.dp).clip(CircleShape).background(if (selectedColor == color) Color.White.copy(alpha=0.3f) else Color.Transparent)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))

            Canvas(
                modifier = Modifier.fillMaxWidth().weight(1f).clip(MaterialTheme.shapes.medium).background(Color.White)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                currentPathPoints = listOf(offset)
                            },
                            onDrag = { change, _ ->
                                currentPathPoints = currentPathPoints + change.position
                            },
                            onDragEnd = {
                                completedPaths.add(DrawnPath(currentPathPoints, selectedColor))
                                currentPathPoints = emptyList()
                            }
                        )
                    }
            ) {
                completedPaths.forEach { drawnPath ->
                    val path = Path()
                    if (drawnPath.points.isNotEmpty()) {
                        path.moveTo(drawnPath.points.first().x, drawnPath.points.first().y)
                        for (i in 1 until drawnPath.points.size) {
                            path.lineTo(drawnPath.points[i].x, drawnPath.points[i].y)
                        }
                    }
                    drawPath(path, color = drawnPath.color, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                
                // Draw current path
                if (currentPathPoints.isNotEmpty()) {
                    val path = Path()
                    path.moveTo(currentPathPoints.first().x, currentPathPoints.first().y)
                    for (i in 1 until currentPathPoints.size) {
                        path.lineTo(currentPathPoints[i].x, currentPathPoints[i].y)
                    }
                    drawPath(path, color = selectedColor, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}

fun generateTitle(title: String, contentText: String, defaultPrefix: String): String {
    if (title.isNotBlank()) return title
    val text = contentText.trim()
    if (text.isNotBlank() && !text.startsWith("[")) {
        val words = text.split("\\s+".toRegex()).take(3).joinToString(" ")
        if (words.isNotBlank()) return words
    }
    val dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
    return "$defaultPrefix - $dateStr"
}
