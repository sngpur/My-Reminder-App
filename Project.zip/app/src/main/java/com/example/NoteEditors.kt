package com.example

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteTextEditorScreen(navController: NavController, viewModel: NoteViewModel, noteId: Int? = null) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    // In a real app, you'd load the note if noteId != null

    val saveAndExit = {
        val finalTitle = generateTitle(title, content, "Text Note")
        if (content.isNotBlank() || finalTitle.isNotBlank()) {
            val currentNote = Note(
                id = noteId ?: 0,
                title = finalTitle, 
                noteType = "Text", 
                content = content, 
                dateMillis = System.currentTimeMillis()
            )
            if (noteId != null && noteId != 0) {
                viewModel.updateNote(currentNote)
            } else {
                viewModel.addNote(currentNote)
            }
        }
        navController.navigateUp()
    }

    BackHandler { saveAndExit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Text Note") },
                navigationIcon = {
                    IconButton(onClick = { saveAndExit() }) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    TextButton(onClick = { saveAndExit() }) { Text("Save") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("Note content...") },
                modifier = Modifier.fillMaxWidth().weight(1f),
                textStyle = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

data class CheckListItem(var text: String, var isChecked: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteListEditorScreen(navController: NavController, viewModel: NoteViewModel) {
    var title by remember { mutableStateOf("") }
    val items = remember { mutableStateListOf<CheckListItem>() }

    val saveAndExit = {
        val serializedContent = items.joinToString("\n") { (if (it.isChecked) "[x] " else "[ ] ") + it.text }
        val finalTitle = generateTitle(title, items.firstOrNull()?.text ?: "", "List Note")
        if (items.isNotEmpty() || finalTitle.isNotBlank()) {
            viewModel.addNote(
                Note(title = finalTitle, noteType = "List", content = serializedContent, dateMillis = System.currentTimeMillis())
            )
        }
        navController.navigateUp()
    }

    BackHandler { saveAndExit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("List Note") },
                navigationIcon = {
                    IconButton(onClick = { saveAndExit() }) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    TextButton(onClick = { saveAndExit() }) { Text("Save") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { items.add(CheckListItem("", false)) }) {
                Icon(Icons.Filled.Add, "Add Item")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(16.dp))
            LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                itemsIndexed(items) { index, item ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = item.isChecked, onCheckedChange = { items[index] = item.copy(isChecked = it) })
                        OutlinedTextField(
                            value = item.text,
                            onValueChange = { items[index] = item.copy(text = it) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = { Text("Item...") }
                        )
                        IconButton(onClick = { items.removeAt(index) }) {
                            Icon(Icons.Filled.Close, "Remove", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteImageEditorScreen(navController: NavController, viewModel: NoteViewModel) {
    var title by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        imageUri = uri
    }

    val saveAndExit = {
        val finalTitle = generateTitle(title, "", "Image Note")
        val content = imageUri?.toString() ?: ""
        if (content.isNotBlank() || finalTitle.isNotBlank()) {
            viewModel.addNote(
                Note(title = finalTitle, noteType = "Image", content = content, dateMillis = System.currentTimeMillis())
            )
        }
        navController.navigateUp()
    }

    BackHandler { saveAndExit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Image Note") },
                navigationIcon = {
                    IconButton(onClick = { saveAndExit() }) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    TextButton(onClick = { saveAndExit() }) { Text("Save") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f).clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.surfaceVariant).clickable { launcher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                if (imageUri != null) {
                    AsyncImage(
                        model = imageUri,
                        contentDescription = "Selected Image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tap to select image", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

data class DrawnPath(val points: List<Offset>, val color: Color)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDrawingEditorScreen(navController: NavController, viewModel: NoteViewModel) {
    var title by remember { mutableStateOf("") }
    var currentPath by remember { mutableStateOf(mutableListOf<Offset>()) }
    var paths by remember { mutableStateOf(mutableListOf<DrawnPath>()) }
    var selectedColor by remember { mutableStateOf(Color.Black) }
    
    val colors = listOf(Color.Black, Color.Red, Color.Blue, Color.Green, Color.Yellow)

    val saveAndExit = {
        val finalTitle = generateTitle(title, "", "Drawing Note")
        
        // Serialize paths
        val jsonArray = JSONArray()
        paths.forEach { path ->
            val pathObj = JSONObject()
            pathObj.put("color", path.color.toArgb())
            val pointsArray = JSONArray()
            path.points.forEach { pt ->
                val ptObj = JSONObject()
                ptObj.put("x", pt.x.toDouble())
                ptObj.put("y", pt.y.toDouble())
                pointsArray.put(ptObj)
            }
            pathObj.put("points", pointsArray)
            jsonArray.put(pathObj)
        }
        val serializedContent = jsonArray.toString()

        if (paths.isNotEmpty() || finalTitle.isNotBlank()) {
            viewModel.addNote(
                Note(title = finalTitle, noteType = "Drawing", content = serializedContent, dateMillis = System.currentTimeMillis())
            )
        }
        navController.navigateUp()
    }

    BackHandler { saveAndExit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Drawing Note") },
                navigationIcon = {
                    IconButton(onClick = { saveAndExit() }) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    IconButton(onClick = { if (paths.isNotEmpty()) paths.removeLast() }) { Icon(Icons.Filled.Undo, "Undo") }
                    IconButton(onClick = { paths.clear(); currentPath.clear() }) { Icon(Icons.Filled.DeleteOutline, "Clear") }
                    TextButton(onClick = { saveAndExit() }) { Text("Save") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            // Color picker
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                colors.forEach { color ->
                    Box(
                        modifier = Modifier.size(36.dp).clip(CircleShape).background(color).clickable { selectedColor = color }
                            .padding(2.dp).clip(CircleShape).background(if (selectedColor == color) Color.White.copy(alpha=0.3f) else Color.Transparent)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))

            Canvas(
                modifier = Modifier.fillMaxWidth().weight(1f).clip(MaterialTheme.shapes.medium).background(Color.White)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                currentPath = mutableListOf(offset)
                            },
                            onDrag = { change, _ ->
                                currentPath.add(change.position)
                            },
                            onDragEnd = {
                                paths.add(DrawnPath(currentPath.toList(), selectedColor))
                                currentPath = mutableListOf()
                            }
                        )
                    }
            ) {
                paths.forEach { drawnPath ->
                    val path = Path()
                    if (drawnPath.points.isNotEmpty()) {
                        path.moveTo(drawnPath.points.first().x, drawnPath.points.first().y)
                        for (i in 1 until drawnPath.points.size) {
                            path.lineTo(drawnPath.points[i].x, drawnPath.points[i].y)
                        }
                    }
                    drawPath(path, color = drawnPath.color, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                
                // Draw current path
                if (currentPath.isNotEmpty()) {
                    val path = Path()
                    path.moveTo(currentPath.first().x, currentPath.first().y)
                    for (i in 1 until currentPath.size) {
                        path.lineTo(currentPath[i].x, currentPath[i].y)
                    }
                    drawPath(path, color = selectedColor, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}

fun generateTitle(title: String, contentText: String, defaultPrefix: String): String {
    if (title.isNotBlank()) return title
    val text = contentText.trim()
    if (text.isNotBlank() && !text.startsWith("[")) {
        val words = text.split("\\s+".toRegex()).take(3).joinToString(" ")
        if (words.isNotBlank()) return words
    }
    val dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
    return "$defaultPrefix - $dateStr"
}
