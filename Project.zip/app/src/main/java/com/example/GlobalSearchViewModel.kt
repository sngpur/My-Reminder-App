package com.example

import androidx.compose.runtime.Stable
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@Stable
data class SearchResult(
    val id: Int,
    val title: String,
    val subtitle: String,
    val type: String, // "Feature", "Task", "Note", "Event", "Document"
    val route: String
)

class GlobalSearchViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val reminderDao = db.reminderDao()
    private val eventDao = db.eventDao()
    private val noteDao = db.noteDao()
    private val scannedDocDao = db.scannedDocDao()
    private val documentExpiryDao = db.documentExpiryDao()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    private val staticFeatures = listOf(
        SearchResult(10001, "General Reminder", "Create or edit customized task alerts and list schedules", "Feature", "add_reminder"),
        SearchResult(10002, "Birthday & Anniversary", "Keep track of friends and family celebrations", "Feature", "birthday_anniversary"),
        SearchResult(10003, "Mileage Calculator", "Track and analyze your vehicle refueling logs and mileage statistics", "Feature", "milage_calculator"),
        SearchResult(10004, "My Notes", "Quickly write, sketch, edit, and keep local notes secure", "Feature", "my_notes"),
        SearchResult(10005, "Age Calculator", "Find exact ages, next birthdays, and countdowns", "Feature", "age_calculator"),
        SearchResult(10006, "Photo Resizer", "Resize images and optimize dimensions easily", "Feature", "photo_resizer"),
        SearchResult(10007, "Text Scanner", "Extract texts from scans and images locally with OCR", "Feature", "text_scanner"),
        SearchResult(10008, "Documents Scanner", "Scan images and export high quality documents", "Feature", "documents_scanner"),
        SearchResult(10009, "QR Scanner", "Generate and scan QR/barcodes automatically", "Feature", "qr_barcode_scanner"),
        SearchResult(10010, "Secure Vault", "Safeguard your passwords, accounts, and private logs", "Feature", "secure_vault"),
        SearchResult(10011, "WhatsApp Scheduler", "Automate and schedule your WhatsApp messages and notifications", "Feature", "whatsapp_scheduler"),
        SearchResult(10012, "Document Expiry", "Manage and alert yourself about document expiry deadlines", "Feature", "document_expiry")
    )

    private val allDbDataFlow = combine(
        reminderDao.getAllReminders(),
        eventDao.getAllEvents(),
        noteDao.getAllNotes(),
        scannedDocDao.getAllScannedDocs(),
        documentExpiryDao.getAllDocuments()
    ) { reminders, events, notes, scannedDocs, docExpiries ->
        DbSearchData(reminders, events, notes, scannedDocs, docExpiries)
    }

    val searchResults: StateFlow<Map<String, List<SearchResult>>> = combine(
        searchQuery,
        allDbDataFlow
    ) { query, dbData ->
        val q = query.trim().lowercase()
        
        // Filter Static Features
        val filteredFeatures = if (q.isEmpty()) {
            staticFeatures
        } else {
            staticFeatures.filter { it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q) }
        }

        if (q.isEmpty()) {
            return@combine mapOf("App Features" to filteredFeatures)
        }

        val filteredTasks = dbData.reminders.filter {
            it.taskTitle.lowercase().contains(q) || (it.location?.lowercase()?.contains(q) ?: false) || (it.tags?.lowercase()?.contains(q) ?: false)
        }.map {
            SearchResult(it.id, it.taskTitle, "${it.taskDate} • ${it.taskTime}", "Task", "edit_reminder/${it.id}")
        }

        val filteredEvents = dbData.events.filter {
            it.name.lowercase().contains(q) || it.eventType.lowercase().contains(q) || it.relationship.lowercase().contains(q)
        }.map {
            SearchResult(it.id, "${it.name}'s ${it.eventType}", "${it.date} • ${it.relationship}", "Event", "birthday_anniversary")
        }

        val filteredNotes = dbData.notes.filter {
            it.title.lowercase().contains(q) || it.content.lowercase().contains(q)
        }.map {
            val route = if (it.noteType == "Drawing") "note_editor_drawing?noteId=${it.id}" else "note_editor_text?noteId=${it.id}"
            SearchResult(it.id, it.title, "Note • ${it.noteType}", "Note", route)
        }

        val filteredDocs = mutableListOf<SearchResult>()
        dbData.scannedDocs.filter {
            it.title.lowercase().contains(q)
        }.forEach {
            filteredDocs.add(SearchResult(it.id, it.title, "Scanned Document • ${it.format}", "Document", "documents_scanner"))
        }
        dbData.docExpiries.filter {
            it.docName.lowercase().contains(q) || it.type.lowercase().contains(q)
        }.forEach {
            filteredDocs.add(SearchResult(it.id, it.docName, "Expiry Document • ${it.type}", "Document", "document_expiry"))
        }

        val resultMap = mutableMapOf<String, List<SearchResult>>()
        if (filteredFeatures.isNotEmpty()) {
            resultMap["App Features"] = filteredFeatures
        }
        if (filteredTasks.isNotEmpty()) {
            resultMap["Tasks"] = filteredTasks
        }
        if (filteredNotes.isNotEmpty()) {
            resultMap["Notes"] = filteredNotes
        }
        if (filteredEvents.isNotEmpty()) {
            resultMap["Events"] = filteredEvents
        }
        if (filteredDocs.isNotEmpty()) {
            resultMap["Documents"] = filteredDocs
        }

        resultMap
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())
}

private data class DbSearchData(
    val reminders: List<Reminder>,
    val events: List<Event>,
    val notes: List<Note>,
    val scannedDocs: List<ScannedDoc>,
    val docExpiries: List<DocumentExpiry>
)
