package com.example

import androidx.compose.runtime.Stable

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray

@Stable
data class SearchResult(
    val id: Int,
    val title: String,
    val subtitle: String,
    val type: String,
    val route: String
)

class GlobalSearchViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val reminderDao = db.reminderDao()
    private val eventDao = db.eventDao()
    private val fuelRecordDao = db.fuelRecordDao()
    private val vaultRecordDao = db.vaultRecordDao()
    private val noteDao = db.noteDao()

    private val prefs = application.getSharedPreferences("search_history", Context.MODE_PRIVATE)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _recentSearches = MutableStateFlow<List<String>>(emptyList())
    val recentSearches = _recentSearches.asStateFlow()

    init {
        loadRecentSearches()
    }

    private fun loadRecentSearches() {
        val json = prefs.getString("history", "[]") ?: "[]"
        val array = JSONArray(json)
        val list = mutableListOf<String>()
        for (i in 0 until array.length()) {
            list.add(array.getString(i))
        }
        _recentSearches.value = list
    }

    fun addRecentSearch(query: String) {
        if (query.isBlank()) return
        val current = _recentSearches.value.toMutableList()
        current.remove(query)
        current.add(0, query)
        val updated = current.take(10)
        _recentSearches.value = updated
        
        val array = JSONArray()
        updated.forEach { array.put(it) }
        prefs.edit().putString("history", array.toString()).apply()
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        prefs.edit().putString("history", "[]").apply()
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    private @Stable
data class SearchData(
        val reminders: List<Reminder>,
        val events: List<Event>,
        val fuelRecords: List<FuelRecord>,
        val vaultRecords: List<VaultRecord>,
        val notes: List<Note>
    )

    private val allDataFlow = combine(
        reminderDao.getAllReminders(),
        eventDao.getAllEvents(),
        fuelRecordDao.getAllFuelRecords(),
        vaultRecordDao.getAllVaultRecords(),
        noteDao.getAllNotes()
    ) { reminders, events, fuelRecords, vaultRecords, notes ->
        SearchData(reminders, events, fuelRecords, vaultRecords, notes)
    }

    val searchResults: StateFlow<List<SearchResult>> = combine(
        searchQuery,
        allDataFlow
    ) { query, data ->
        if (query.isBlank()) return@combine emptyList()
        
        val q = query.lowercase()
        val results = mutableListOf<SearchResult>()

        results.addAll(data.reminders.filter { 
            it.taskTitle.lowercase().contains(q) || it.location.lowercase().contains(q) || it.tags.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, it.taskTitle, "${it.taskDate} • ${it.taskTime}", "Task", "edit_reminder/${it.id}") 
        })

        results.addAll(data.events.filter { 
            it.name.lowercase().contains(q) || it.eventType.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, "${it.name}'s ${it.eventType}", it.date, "Event", "birthday_anniversary") 
        })

        results.addAll(data.fuelRecords.filter { 
            it.vehicleType.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, "${it.vehicleType} Fuel Record", "${it.odometerKm} km", "Mileage", "milage_calculator") 
        })

        results.addAll(data.vaultRecords.filter { 
            it.title.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, it.title, "Secure Vault • ${it.category}", "Vault", "secure_vault") 
        })

        results.addAll(data.notes.filter { 
            it.title.lowercase().contains(q) || it.content.lowercase().contains(q)
        }.map { 
            val route = if (it.noteType == "Drawing") "note_editor_drawing?noteId=${it.id}" else "note_editor_text?noteId=${it.id}"
            SearchResult(it.id, it.title, "Note • ${it.noteType}", "Note", route) 
        })

        results.sortedBy { it.title }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}
