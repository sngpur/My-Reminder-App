package com.example

import androidx.compose.runtime.Stable

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Stable
data class ChatMessage(val text: String, val isUser: Boolean, val id: String = java.util.UUID.randomUUID().toString())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(navController: NavController) {
    val context = LocalContext.current
    var inputQuery by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        messages.add(ChatMessage("Hi Buddy! I can help you search your offline data. Try asking 'How much Udhar?' or 'How many tasks today?'", false))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Smart Search (Offline)") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(MaterialTheme.colorScheme.surface),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask something...") },
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val query = inputQuery.trim()
                        if (query.isNotEmpty()) {
                            messages.add(ChatMessage(query, true))
                            inputQuery = ""
                            coroutineScope.launch {
                                val response = processQueryOffline(context, query)
                                messages.add(ChatMessage(response, false))
                            }
                        }
                    },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp)
        ) {
            items(messages, key = { it.id }, contentType = { "chat" }) { msg ->
                val alignment = if (msg.isUser) Alignment.CenterEnd else Alignment.CenterStart
                val bgColor = if (msg.isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                val textColor = if (msg.isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer

                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = alignment) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = bgColor),
                        modifier = Modifier.widthIn(max = 280.dp),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = msg.text,
                            color = textColor,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}

suspend fun processQueryOffline(context: android.content.Context, query: String): String {
    return withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val q = query.lowercase()

        if (q.contains("udhar") || q.contains("lent") || q.contains("receive")) {
            val financeTasks = db.reminderDao().getFinanceRemindersSync()
            var total = 0.0
            for (t in financeTasks) {
                if (!t.isCompleted && t.category == "Money Lent (Udhar)" && t.amount != null) {
                    total += t.amount
                }
            }
            return@withContext "You have ₹${total.toInt()} pending to receive in Udhar."
        } 
        else if (q.contains("pay") || q.contains("due")) {
            val financeTasks = db.reminderDao().getFinanceRemindersSync()
            var total = 0.0
            for (t in financeTasks) {
                if (!t.isCompleted && t.category == "Upcoming Payment" && t.amount != null) {
                    total += t.amount
                }
            }
            return@withContext "You have ₹${total.toInt()} in upcoming payments."
        }
        else if (q.contains("task") || q.contains("today")) {
            val today = java.time.LocalDate.now().toString()
            val tasks = db.reminderDao().getRemindersForDateSync(today)
            return@withContext "You have ${tasks.size} tasks scheduled for today."
        }
        else if (q.contains("birthday") || q.contains("anniversary")) {
            val allEvents = db.eventDao().getAllEventsSync()
            val currentLocalDate = java.time.LocalDate.now()
            var count = 0
            for (e in allEvents) {
                try {
                    val eventDate = java.time.LocalDate.parse(e.date)
                    if (eventDate.monthValue == currentLocalDate.monthValue && eventDate.dayOfMonth == currentLocalDate.dayOfMonth) {
                        count++
                    }
                } catch (ex: Exception) {}
            }
            return@withContext "You have $count birthdays/anniversaries today."
        }
        else {
            return@withContext "I'm not sure how to answer that yet. Try asking about your 'udhar', 'payments', 'tasks today', or 'birthdays'."
        }
    }
}
