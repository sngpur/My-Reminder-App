package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentExpiryScreen(
    navController: NavController,
    viewModel: DocumentExpiryViewModel,
    openDrawer: () -> Unit
) {
    val documents by viewModel.documents.collectAsStateWithLifecycle()
    var showDeleteDialog by remember { mutableStateOf(false) }
    var documentToDelete by remember { mutableStateOf<DocumentExpiry?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Document Expiry Tracker") },
                navigationIcon = {
                    IconButton(onClick = openDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "Menu")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate("add_edit_document/-1") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Document")
            }
        }
    ) { padding ->
        if (documents.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No documents added yet",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(documents, key = { it.id }, contentType = { "doc_expiry" }) { doc ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = doc.docName,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Type: ${doc.type}",
                                    fontSize = 16.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                
                                val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy")
                                val dateTime = LocalDateTime.ofInstant(
                                    java.time.Instant.ofEpochMilli(doc.expiryDateInMillis),
                                    ZoneId.systemDefault()
                                )
                                
                                val now = System.currentTimeMillis()
                                val thirtyDaysInMillis = 30L * 24 * 60 * 60 * 1000L
                                val isExpiringSoon = doc.expiryDateInMillis - now < thirtyDaysInMillis
                                val dateColor = if (isExpiringSoon) Color(0xFFEF4444) else MaterialTheme.colorScheme.primary
                                val dateWeight = if (isExpiringSoon) FontWeight.Bold else FontWeight.SemiBold
                                
                                Text(
                                    text = "Expires on: ${dateTime.format(formatter)}",
                                    fontSize = 16.sp,
                                    fontWeight = dateWeight,
                                    color = dateColor
                                )
                            }
                            
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { navController.navigate("add_edit_document/${doc.id}") }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        documentToDelete = doc
                                        showDeleteDialog = true
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDeleteDialog && documentToDelete != null) {
        AlertDialog(
            onDismissRequest = {
                showDeleteDialog = false
                documentToDelete = null
            },
            title = { Text("Delete Document") },
            text = { Text("Are you sure you want to delete \"${documentToDelete?.docName}\"? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        documentToDelete?.let { viewModel.deleteDocument(it.id) }
                        showDeleteDialog = false
                        documentToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        documentToDelete = null
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}
