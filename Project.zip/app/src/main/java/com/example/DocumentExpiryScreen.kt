package com.example

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentExpiryScreen(navController: NavController, viewModel: DocumentExpiryViewModel = viewModel()) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    val documents by viewModel.documents.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Document Expiry Tracker") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add Document")
            }
        }
    ) { padding ->
        if (documents.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("No documents added yet")
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
                items(documents, key = { it.id }, contentType = { "doc_expiry" }) { doc ->
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(doc.docName, style = MaterialTheme.typography.titleMedium)
                            Text("Type: ${doc.type}", style = MaterialTheme.typography.bodyMedium)
                            val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy")
                            val dateTime = LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(doc.expiryDateInMillis), ZoneId.systemDefault())
                            Text("Expires on: ${dateTime.format(formatter)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var docName by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("Driving License") }
        var expiryDate by remember { mutableStateOf(LocalDateTime.now().plusMonths(6)) }
        var expanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Document") },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = docName,
                        onValueChange = { docName = it },
                        label = { Text("Document Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Type: $type")
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            listOf("Driving License", "Insurance", "Passport", "ID Card", "Other").forEach { t ->
                                DropdownMenuItem(
                                    text = { Text(t) },
                                    onClick = { 
                                        type = t
                                        expanded = false 
                                    }
                                )
                            }
                        }
                    }

                    Button(onClick = {
                        val datePickerDialog = DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                expiryDate = LocalDateTime.of(year, month + 1, dayOfMonth, 12, 0)
                            },
                            expiryDate.year,
                            expiryDate.monthValue - 1,
                            expiryDate.dayOfMonth
                        )
                        datePickerDialog.show()
                    }, modifier = Modifier.fillMaxWidth()) {
                        val formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy")
                        Text("Pick Expiry Date: ${expiryDate.format(formatter)}")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (docName.isNotBlank()) {
                        viewModel.addDocument(
                            docName = docName,
                            type = type,
                            expiryDateInMillis = expiryDate.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        )
                        showAddDialog = false
                    }
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
