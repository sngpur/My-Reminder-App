package com.example

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

object ServicingAlarmScheduler {
    fun scheduleServicingAlarm(context: Context, record: ServiceRecord) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ServicingAlarmReceiver::class.java).apply {
            putExtra("RECORD_ID", record.id)
            putExtra("VEHICLE_TYPE", record.vehicleType)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            record.id + 100000, // Offset to avoid collisions
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (record.nextServiceDate.isEmpty() || record.nextServiceDate == "Not set") {
                return
            }

            val formatter = java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy", java.util.Locale.ENGLISH)
            val serviceLocalDate = LocalDate.parse(record.nextServiceDate, formatter)
            
            val alarmTime = LocalDateTime.of(serviceLocalDate, LocalTime.of(8, 0))
            val triggerTimeMillis = alarmTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            
            // If the nextServiceDate is already in the past, do NOT schedule a new alarm.
            if (triggerTimeMillis <= System.currentTimeMillis()) {
                return
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTimeMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTimeMillis, pendingIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelServicingAlarm(context: Context, record: ServiceRecord) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ServicingAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            record.id + 100000,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
