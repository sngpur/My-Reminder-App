package com.example

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrashScreen(navController: androidx.navigation.NavController, reminderViewModel: ReminderViewModel, noteViewModel: NoteViewModel) {
    val trashedReminders by reminderViewModel.trashedReminders.collectAsStateWithLifecycle()
    val trashedNotes by noteViewModel.trashedNotes.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Recycle Bin") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Tasks") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Notes") })
            }
            if (selectedTab == 0) {
                if (trashedReminders.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No tasks in trash") }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(trashedReminders, key = { it.id }) { reminder ->
                            TrashItemCard(
                                title = reminder.taskTitle,
                                subtitle = reminder.category,
                                onRestore = { scope.launch { reminderViewModel.restoreReminder(reminder.id) } },
                                onPermanentDelete = { scope.launch { reminderViewModel.permanentlyDeleteReminder(reminder.id) } }
                            )
                        }
                    }
                }
            } else {
                if (trashedNotes.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No notes in trash") }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(trashedNotes, key = { it.id }) { note ->
                            TrashItemCard(
                                title = note.title,
                                subtitle = note.noteType,
                                onRestore = { scope.launch { noteViewModel.restoreNote(note.id) } },
                                onPermanentDelete = { scope.launch { noteViewModel.permanentlyDeleteNote(note) } }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrashItemCard(title: String, subtitle: String, onRestore: () -> Unit, onPermanentDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
            Row {
                IconButton(onClick = onRestore) {
                    Icon(Icons.Default.Restore, contentDescription = "Restore", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onPermanentDelete) {
                    Icon(Icons.Default.DeleteForever, contentDescription = "Permanent Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
