package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "qr_records")
data class QrRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "Scanned" or "Generated"
    val data: String,
    val dateMillis: Long = System.currentTimeMillis()
)
