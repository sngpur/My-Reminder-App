import sys

with open("app/src/main/java/com/example/TextScannerScreen.kt", "r") as f:
    content = f.read()

helper = """
import android.content.ContextWrapper

fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

"""

if "fun android.content.Context.findActivity()" not in content:
    content = content.replace("import android.app.Activity", helper + "import android.app.Activity")

content = content.replace("(context as? Activity ?: (context as? android.content.ContextWrapper)?.baseContext as? Activity)!!", "context.findActivity()!!")

with open("app/src/main/java/com/example/TextScannerScreen.kt", "w") as f:
    f.write(content)
