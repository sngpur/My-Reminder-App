import os
import re

def replace_with_exact_allow_while_idle(filepath):
    if not os.path.exists(filepath):
        return
    with open(filepath, "r") as f:
        content = f.read()

    # MorningBriefingScheduler.kt
    if "MorningBriefingScheduler.kt" in filepath:
        content = content.replace("alarmManager.setRepeating(", "alarmManager.setExactAndAllowWhileIdle(")
        content = content.replace("AlarmManager.INTERVAL_DAY,", "") # Remove interval parameter

    # WhatsAppAlarmScheduler.kt and DocumentExpiryAlarmScheduler.kt
    if "WhatsAppAlarmScheduler.kt" in filepath or "DocumentExpiryAlarmScheduler.kt" in filepath:
        old_block = """            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        schedule.scheduledTimeInMillis,
                        pendingIntent
                    )
                } else {
                    // Fallback or request permission
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        schedule.scheduledTimeInMillis,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    schedule.scheduledTimeInMillis,
                    pendingIntent
                )
            }"""
        new_block = """            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                schedule.scheduledTimeInMillis,
                pendingIntent
            )"""
        
        # for DocumentExpiryAlarmScheduler it's expiryTimeInMillis instead of schedule.scheduledTimeInMillis
        if "DocumentExpiryAlarmScheduler" in filepath:
            old_block = old_block.replace("schedule.scheduledTimeInMillis", "expiryTimeInMillis")
            new_block = new_block.replace("schedule.scheduledTimeInMillis", "expiryTimeInMillis")
            
        content = content.replace(old_block, new_block)

    # ReminderViewModel.kt
    if "ReminderViewModel.kt" in filepath:
        old_block_1 = """                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (alarmManager.canScheduleExactAlarms()) {
                            val info = AlarmManager.AlarmClockInfo(timeInMillis, pendingIntent)
                            alarmManager.setAlarmClock(info, pendingIntent)
                        } else {
                            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                        }
                    } else {
                        val info = AlarmManager.AlarmClockInfo(timeInMillis, pendingIntent)
                        alarmManager.setAlarmClock(info, pendingIntent)
                    }"""
        new_block_1 = """                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
                    }"""
        content = content.replace(old_block_1, new_block_1)
        
    with open(filepath, "w") as f:
        f.write(content)

files = [
    "app/src/main/java/com/example/MorningBriefingScheduler.kt",
    "app/src/main/java/com/example/WhatsAppAlarmScheduler.kt",
    "app/src/main/java/com/example/DocumentExpiryAlarmScheduler.kt",
    "app/src/main/java/com/example/ReminderViewModel.kt"
]

for file in files:
    replace_with_exact_allow_while_idle(file)

