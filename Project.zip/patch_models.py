import re

# Reminder.kt
with open("app/src/main/java/com/example/Reminder.kt", "r") as f:
    content = f.read()
if "val isDeleted: Boolean" not in content:
    content = content.replace('val tags: String = "" // comma-separated', 'val tags: String = "",\n    val isDeleted: Boolean = false')
with open("app/src/main/java/com/example/Reminder.kt", "w") as f:
    f.write(content)

# Note.kt
with open("app/src/main/java/com/example/Note.kt", "r") as f:
    content = f.read()
if "val isDeleted: Boolean" not in content:
    content = content.replace('val dateMillis: Long', 'val dateMillis: Long,\n    val isDeleted: Boolean = false')
with open("app/src/main/java/com/example/Note.kt", "w") as f:
    f.write(content)

# ReminderDao.kt
with open("app/src/main/java/com/example/ReminderDao.kt", "r") as f:
    content = f.read()
content = content.replace('@Query("SELECT * FROM reminders ORDER BY taskDate ASC, taskTime ASC")', '@Query("SELECT * FROM reminders WHERE isDeleted = 0 ORDER BY taskDate ASC, taskTime ASC")')
if "getTrashedReminders" not in content:
    content = content.replace('interface ReminderDao {', 'interface ReminderDao {\n    @Query("SELECT * FROM reminders WHERE isDeleted = 1 ORDER BY taskDate ASC, taskTime ASC")\n    fun getTrashedReminders(): Flow<List<Reminder>>')
    content = content.replace('@Query("DELETE FROM reminders WHERE id = :id")', '@Query("UPDATE reminders SET isDeleted = 1 WHERE id = :id")')
    content = content.replace('suspend fun deleteReminderById(id: Int)', 'suspend fun deleteReminderById(id: Int)\n\n    @Query("DELETE FROM reminders WHERE id = :id")\n    suspend fun permanentlyDeleteReminderById(id: Int)\n\n    @Query("UPDATE reminders SET isDeleted = 0 WHERE id = :id")\n    suspend fun restoreReminderById(id: Int)')
with open("app/src/main/java/com/example/ReminderDao.kt", "w") as f:
    f.write(content)

# NoteDao.kt
with open("app/src/main/java/com/example/NoteDao.kt", "r") as f:
    content = f.read()
content = content.replace('@Query("SELECT * FROM notes ORDER BY dateMillis DESC")', '@Query("SELECT * FROM notes WHERE isDeleted = 0 ORDER BY dateMillis DESC")')
if "getTrashedNotes" not in content:
    content = content.replace('interface NoteDao {', 'interface NoteDao {\n    @Query("SELECT * FROM notes WHERE isDeleted = 1 ORDER BY dateMillis DESC")\n    fun getTrashedNotes(): Flow<List<Note>>\n\n    @Query("UPDATE notes SET isDeleted = 1 WHERE id = :id")\n    suspend fun softDeleteNoteById(id: Int)\n\n    @Query("UPDATE notes SET isDeleted = 0 WHERE id = :id")\n    suspend fun restoreNoteById(id: Int)')
with open("app/src/main/java/com/example/NoteDao.kt", "w") as f:
    f.write(content)

# AppDatabase.kt
with open("app/src/main/java/com/example/AppDatabase.kt", "r") as f:
    content = f.read()
content = content.replace('version = 14', 'version = 15')
content = content.replace('(1..13)', '(1..14)')
content = content.replace('object : Migration(startVersion, 14)', 'object : Migration(startVersion, 15)')
if "ALTER TABLE reminders ADD COLUMN isDeleted" not in content:
    content = content.replace('try { db.execSQL("ALTER TABLE notes ADD COLUMN dateMillis INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}', 'try { db.execSQL("ALTER TABLE notes ADD COLUMN dateMillis INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}\n                    try { db.execSQL("ALTER TABLE reminders ADD COLUMN isDeleted INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}\n                    try { db.execSQL("ALTER TABLE notes ADD COLUMN isDeleted INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}')
with open("app/src/main/java/com/example/AppDatabase.kt", "w") as f:
    f.write(content)
