import re

with open("app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

old_filters = """<receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>"""

new_filters = """<receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.TIME_SET" />
                <action android:name="android.intent.action.TIMEZONE_CHANGED" />
            </intent-filter>
        </receiver>"""

content = content.replace(old_filters, new_filters)

with open("app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
