import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

old_upcoming = """    val now = LocalDateTime.now()
    val upcomingTasks = reminders.filter { !it.isCompleted }.filter {
        val dt = LocalDateTime.of(LocalDate.parse(it.taskDate), LocalTime.parse(it.taskTime))
        dt.isAfter(now)
    }.sortedBy { LocalDateTime.of(LocalDate.parse(it.taskDate), LocalTime.parse(it.taskTime)) }"""

new_upcoming = """    val now = LocalDateTime.now()
    val upcomingTasks = reminders.filter { !it.isCompleted }.filter {
        !it.getNextActiveReminder().isPassed
    }.sortedBy { it.getNextActiveReminder().dateTime }"""

content = content.replace(old_upcoming, new_upcoming)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
