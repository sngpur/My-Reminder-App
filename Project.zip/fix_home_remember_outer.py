import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# We need to extract the parts and move them up.
part_to_remove = """            val filteredReminders = remember(reminders, searchQuery, selectedFilter) {
                reminders.filter {
                    val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                    val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                    matchesSearch && matchesFilter
                }
            }
            
            if (filteredReminders.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Text(if (searchQuery.isNotEmpty()) "No results found." else "No reminders yet. Add one to get started!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                val groupedAndSorted = remember(filteredReminders) {
                    filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }.toSortedMap()
                }
                val todayStr = remember { LocalDate.now().toString() }
                
                groupedAndSorted.forEach { (date, tasks) ->"""


replacement_part = """            if (filteredReminders.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                        Text(if (searchQuery.isNotEmpty()) "No results found." else "No reminders yet. Add one to get started!", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                groupedAndSorted.forEach { (date, tasks) ->"""

content = content.replace(part_to_remove, replacement_part)


insert_part = """
        val filteredReminders = remember(reminders, searchQuery, selectedFilter) {
            reminders.filter {
                val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                matchesSearch && matchesFilter
            }
        }
        val groupedAndSorted = remember(filteredReminders) {
            filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }.toSortedMap()
        }
        val todayStr = remember { LocalDate.now().toString() }
        
        LazyColumn(
"""

content = content.replace("        LazyColumn(", insert_part)


with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
