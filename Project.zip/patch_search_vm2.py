import re

with open("app/src/main/java/com/example/GlobalSearchViewModel.kt", "r") as f:
    content = f.read()

content = content.replace("it.type", "it.noteType") # for notes
content = content.replace("Vault • ${it.noteType}", "Vault • ${it.category}") # fix vault
content = content.replace("SearchResult(it.id, it.title, \"Secure Vault • ${it.category}\", \"Vault\", \"secure_vault\")", "SearchResult(it.id, it.title, \"Secure Vault • ${it.category}\", \"Vault\", \"secure_vault\")")

# let's just rewrite the Vault and Note part
pattern = r"results\.addAll\(data\.vaultRecords.*?results\.sortedBy \{ it\.title \}"

new_code = """results.addAll(data.vaultRecords.filter { 
            it.title.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, it.title, "Secure Vault • ${it.category}", "Vault", "secure_vault") 
        })

        results.addAll(data.notes.filter { 
            it.title.lowercase().contains(q) || it.content.lowercase().contains(q)
        }.map { 
            val route = if (it.noteType == "Drawing") "note_editor_drawing?noteId=${it.id}" else "note_editor_text?noteId=${it.id}"
            SearchResult(it.id, it.title, "Note • ${it.noteType}", "Note", route) 
        })

        results.sortedBy { it.title }"""

content = re.sub(pattern, new_code, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/GlobalSearchViewModel.kt", "w") as f:
    f.write(content)
