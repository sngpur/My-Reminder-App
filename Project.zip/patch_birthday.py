import re

with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "r") as f:
    content = f.read()

# 1. Add Imports
if "import java.time.LocalDate" not in content:
    content = content.replace(
        "import java.time.LocalTime", 
        "import java.time.LocalTime\nimport java.time.LocalDate\nimport java.time.temporal.ChronoUnit\nimport java.time.format.DateTimeFormatter"
    )
if "import androidx.compose.material.icons.filled.NotificationsActive" not in content:
    content = content.replace(
        "import androidx.compose.material.icons.filled.Favorite",
        "import androidx.compose.material.icons.filled.Favorite\nimport androidx.compose.material.icons.filled.NotificationsActive"
    )

# 2. Add calculateDaysLeft function
helper_func = """
fun calculateDaysLeft(dateString: String): Long {
    return try {
        val formatter = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())
        val today = LocalDate.now()
        var eventDate = LocalDate.parse("$dateString ${today.year}", formatter)
        if (eventDate.isBefore(today)) {
            eventDate = eventDate.plusYears(1)
        }
        ChronoUnit.DAYS.between(today, eventDate)
    } catch (e: Exception) {
        Long.MAX_VALUE
    }
}

@OptIn(ExperimentalMaterial3Api::class)"""
content = content.replace("@OptIn(ExperimentalMaterial3Api::class)", helper_func, 1)

# 3. Create sortedEvents
content = content.replace(
    "val events by eventViewModel.allEvents.collectAsStateWithLifecycle()",
    "val events by eventViewModel.allEvents.collectAsStateWithLifecycle()\n    val sortedEvents = events.sortedBy { calculateDaysLeft(it.date) }"
)

# Replace 'events' with 'sortedEvents' where needed
content = content.replace("events.filter { it.eventType == \"Birthday\" }", "sortedEvents.filter { it.eventType == \"Birthday\" }")
content = content.replace("events.filter { it.eventType == \"Anniversary\" }", "sortedEvents.filter { it.eventType == \"Anniversary\" }")
content = content.replace("if (events.isEmpty()) {", "if (sortedEvents.isEmpty()) {")
content = content.replace("items(events) { event ->", "items(sortedEvents) { event ->")

# 4. Update the Text in the Card
old_text = """                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = event.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${event.relationship} • ${event.date}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }"""
new_text = """                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = event.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "${event.relationship} • ${event.date}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            val daysLeft = calculateDaysLeft(event.date)
                                            if (daysLeft != Long.MAX_VALUE) {
                                                Text(
                                                    text = " • $daysLeft Days Left",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }
                                            if (event.ringAlarm) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Filled.NotificationsActive,
                                                    contentDescription = "Alarm On",
                                                    modifier = Modifier.size(14.dp),
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }"""
content = content.replace(old_text, new_text)

with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "w") as f:
    f.write(content)
