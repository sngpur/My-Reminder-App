with open("app/src/main/java/com/example/AddReminderScreen.kt", "r") as f:
    content = f.read()

import re

toggle_ui = """                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Ring Full Alarm", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                            Switch(checked = isAlarmEnabled, onCheckedChange = { isAlarmEnabled = it })
                        }
                    }
                }
            }"""

content = content.replace(toggle_ui, """                        }
                    }
                }
            }""")

with open("app/src/main/java/com/example/AddReminderScreen.kt", "w") as f:
    f.write(content)
