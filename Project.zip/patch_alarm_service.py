import re

with open("app/src/main/java/com/example/AlarmService.kt", "r") as f:
    content = f.read()

# Add putExtra to stopIntent
old_stop_intent = """        val stopIntent = Intent(this, AlarmStopReceiver::class.java).apply {
            putExtra("id", notificationId)
        }"""
new_stop_intent = """        val stopIntent = Intent(this, AlarmStopReceiver::class.java).apply {
            putExtra("id", notificationId)
            putExtra("title", title)
            putExtra("category", category)
        }"""
content = content.replace(old_stop_intent, new_stop_intent)

# Add "Mark Complete" action to the ongoing alarm notification as well
old_notification = """            .setFullScreenIntent(pendingIntent, true)
            .addAction(android.R.drawable.ic_media_pause, "Stop Alarm", stopPendingIntent)
            .setOngoing(true)
            .build()"""

new_notification = """            .setFullScreenIntent(pendingIntent, true)
            .addAction(android.R.drawable.ic_media_pause, "Stop Alarm", stopPendingIntent)
            .addAction(android.R.drawable.ic_menu_edit, "Mark Complete", PendingIntent.getBroadcast(
                this, notificationId + 20000, Intent(this, MarkCompleteReceiver::class.java).apply {
                    putExtra("id", notificationId)
                }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            ))
            .setOngoing(true)
            .build()"""
content = content.replace(old_notification, new_notification)

with open("app/src/main/java/com/example/AlarmService.kt", "w") as f:
    f.write(content)
