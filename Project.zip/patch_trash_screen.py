import re

with open("app/src/main/java/com/example/TrashScreen.kt", "r") as f:
    content = f.read()

content = content.replace("emptyList<Reminder>()", "emptyList()")
content = content.replace("emptyList()", "emptyList()")

content = content.replace("trashedReminders.collectAsStateWithLifecycle(emptyList())", "trashedReminders.collectAsStateWithLifecycle()")
content = content.replace("trashedNotes.collectAsStateWithLifecycle(emptyList())", "trashedNotes.collectAsStateWithLifecycle()")

with open("app/src/main/java/com/example/TrashScreen.kt", "w") as f:
    f.write(content)
