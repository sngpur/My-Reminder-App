import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# Add necessary imports
imports_to_add = """
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
"""
content = content.replace("import androidx.compose.ui.graphics.Color\n", "import androidx.compose.ui.graphics.Color\n" + imports_to_add)

# Dynamic Live Banner component
mb_components = """
@Composable
fun MBBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFFFACC15), Color(0xFFF97316)))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "MB",
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun LiveColorBanner(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val infiniteTransition = rememberInfiniteTransition()
    val color1 by infiniteTransition.animateColor(
        initialValue = Color(0xFF6366F1), // Indigo
        targetValue = Color(0xFFEC4899), // Pink
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Reverse)
    )
    val color2 by infiniteTransition.animateColor(
        initialValue = Color(0xFF3B82F6), // Blue
        targetValue = Color(0xFF8B5CF6), // Purple
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Reverse)
    )
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(color1, color2))),
        content = content
    )
}
"""

content = content.replace("@OptIn(ExperimentalMaterial3Api::class)\n@Composable\nfun HomeScreen", mb_components + "\n@OptIn(ExperimentalMaterial3Api::class)\n@Composable\nfun HomeScreen")

# Replace Drawer Header
old_drawer_header = """                // Drawer Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9)) // Purple gradient
                        )),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("B", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "My Buddy",
                            color = Color.White,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }"""

new_drawer_header = """                // Drawer Header
                LiveColorBanner(modifier = Modifier.height(180.dp)) {
                    Column(
                        modifier = Modifier.padding(16.dp).align(Alignment.BottomStart)
                    ) {
                        MBBadge(modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "My Buddy",
                            color = Color.White,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }"""
content = content.replace(old_drawer_header, new_drawer_header)

# Replace Drawer Menu Items definition and usage
old_menu_items = """                val menuItems = listOf(
                    "General Reminder" to androidx.compose.material.icons.Icons.Filled.CheckCircle,
                    "Birthday & Anniversary" to androidx.compose.material.icons.Icons.Outlined.CalendarToday,
                    "Milage Calculator" to androidx.compose.material.icons.Icons.Filled.AccountBalanceWallet,
                    "My Notes" to androidx.compose.material.icons.Icons.Outlined.Circle,
                    "Age Calculator" to androidx.compose.material.icons.Icons.Outlined.AccessTime,
                    "Photo Resizer" to androidx.compose.material.icons.Icons.Filled.Image,
                    "Text Scanner" to androidx.compose.material.icons.Icons.Filled.Search,
                    "Documents Scanner" to androidx.compose.material.icons.Icons.Filled.Sync,
                    "QR & Barcode Scanner" to androidx.compose.material.icons.Icons.Outlined.Circle,
                    "Secure Vault" to androidx.compose.material.icons.Icons.Filled.AccountBalanceWallet
                )"""

new_menu_items = """                val menuItems = listOf(
                    "General Reminder" to androidx.compose.material.icons.Icons.Rounded.CheckCircle,
                    "Birthday & Anniversary" to androidx.compose.material.icons.Icons.Rounded.Cake,
                    "Milage Calculator" to androidx.compose.material.icons.Icons.Rounded.DirectionsCar,
                    "My Notes" to androidx.compose.material.icons.Icons.Rounded.EditNote,
                    "Age Calculator" to androidx.compose.material.icons.Icons.Rounded.HourglassEmpty,
                    "Photo Resizer" to androidx.compose.material.icons.Icons.Rounded.PhotoSizeSelectLarge,
                    "Text Scanner" to androidx.compose.material.icons.Icons.Rounded.DocumentScanner,
                    "Documents Scanner" to androidx.compose.material.icons.Icons.Rounded.DocumentScanner,
                    "QR & Barcode Scanner" to androidx.compose.material.icons.Icons.Rounded.QrCodeScanner,
                    "Secure Vault" to androidx.compose.material.icons.Icons.Rounded.Lock
                )"""
content = content.replace(old_menu_items, new_menu_items)

old_nav_item = """                    items(menuItems) { (title, icon) ->
                        androidx.compose.material3.NavigationDrawerItem(
                            icon = { Icon(icon, contentDescription = null) },
                            label = { Text(title) },
                            selected = title == "General Reminder",
                            onClick = {"""

new_nav_item = """                    items(menuItems) { (title, icon) ->
                        val isSelected = title == "General Reminder"
                        androidx.compose.material3.NavigationDrawerItem(
                            icon = { Icon(icon, contentDescription = null, tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant) },
                            label = { Text(title, color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface) },
                            selected = isSelected,
                            colors = androidx.compose.material3.NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                unselectedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                            onClick = {"""
content = content.replace(old_nav_item, new_nav_item)

# Insert Live Banner in the Main Screen top bar
old_top_bar = """                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(androidx.compose.material.icons.Icons.Filled.Menu, contentDescription = "Open Drawer")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("My Buddy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        }"""
new_top_bar = """                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(androidx.compose.material.icons.Icons.Filled.Menu, contentDescription = "Open Drawer")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            LiveColorBanner(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .padding(vertical = 12.dp, horizontal = 16.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    MBBadge(modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("My Buddy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }"""
content = content.replace(old_top_bar, new_top_bar)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
