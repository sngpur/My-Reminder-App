import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# Replace from `val dateStr = reminder.taskDate` up to `Text(monthStr, style = MaterialTheme.typography.labelSmall)\n                }`
old_date_logic = """                val dateStr = reminder.taskDate
                var monthStr = dateStr
                var dayStr = ""
                try {
                    val date = LocalDate.parse(dateStr)
                    monthStr = date.month.name.take(3).uppercase()
                    dayStr = String.format("%02d", date.dayOfMonth)
                } catch (e: Exception) {
                    // Ignore parsing error
                }
                
                if (dayStr.isNotEmpty()) {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(dayStr, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                } else {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall)
                }"""

new_date_logic = """                val activeInfo = reminder.getNextActiveReminder()
                val dateStr = activeInfo.dateTime.toLocalDate().toString()
                val timeStr = String.format(java.util.Locale.getDefault(), "%02d:%02d", activeInfo.dateTime.hour, activeInfo.dateTime.minute)
                val alphaVal = if (activeInfo.isPassed) 0.4f else 1.0f

                var monthStr = dateStr
                var dayStr = ""
                try {
                    val date = LocalDate.parse(dateStr)
                    monthStr = date.month.name.take(3).uppercase()
                    dayStr = String.format(java.util.Locale.getDefault(), "%02d", date.dayOfMonth)
                } catch (e: Exception) {
                    // Ignore parsing error
                }
                
                if (dayStr.isNotEmpty()) {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal))
                    Text(dayStr, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alphaVal))
                } else {
                    Text(monthStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = alphaVal))
                }"""

content = content.replace(old_date_logic, new_date_logic)

# Now we need to replace the time part in the same function.
# We'll use a targeted regex
old_time_logic = """                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (reminder.isAlarmEnabled) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = "Alarm On", modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = reminder.taskTime,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }"""

new_time_logic = """                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (reminder.isAlarmEnabled) {
                            Icon(Icons.Filled.NotificationsActive, contentDescription = "Alarm On", modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = alphaVal))
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = timeStr,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alphaVal)
                        )
                    }"""

content = content.replace(old_time_logic, new_time_logic)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
