import re

with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "r") as f:
    content = f.read()

content = content.replace("val sortedEvents = events.sortedBy { calculateDaysLeft(it.date) }", "val sortedEvents = remember(events) { events.sortedBy { calculateDaysLeft(it.date) } }")
content = content.replace("val daysLeft = calculateDaysLeft(event.date)", "val daysLeft = remember(event.date) { calculateDaysLeft(event.date) }")

with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "w") as f:
    f.write(content)

