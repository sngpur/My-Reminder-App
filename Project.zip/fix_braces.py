with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "r") as f:
    lines = f.readlines()

for i, l in enumerate(lines[320:360]):
    print(f"{i + 321}: {l.rstrip()}")
