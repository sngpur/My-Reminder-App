with open("app/src/main/java/com/example/ReminderViewModel.kt", "r") as f:
    content = f.read()

content = content.replace('putExtra("id", reminder.id)', 'putExtra("id", reminder.id)\n                    putExtra("isAlarmEnabled", reminder.isAlarmEnabled)')

with open("app/src/main/java/com/example/ReminderViewModel.kt", "w") as f:
    f.write(content)
