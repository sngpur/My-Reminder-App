import re

with open("app/src/main/java/com/example/ReminderViewModel.kt", "r") as f:
    content = f.read()

# Find the class declaration and add properties
class_pattern = r"class ReminderViewModel\(\s*application: Application,\s*private val repository: ReminderRepository\s*\) : AndroidViewModel\(application\) \{"
new_properties = """
    private val db = AppDatabase.getDatabase(application)
    private val eventDao = db.eventDao()
    private val fuelRecordDao = db.fuelRecordDao()

    val nearestBirthday = eventDao.getAllEvents().map { events ->
        findNearestEvent(events.filter { it.type == "Birthday" })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val nearestAnniversary = eventDao.getAllEvents().map { events ->
        findNearestEvent(events.filter { it.type == "Anniversary" })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val latestBikeMileage = fuelRecordDao.getAllFuelRecords().map { records ->
        records.filter { it.vehicleType == "Bike" }.maxByOrNull { it.dateMillis }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val latestCarMileage = fuelRecordDao.getAllFuelRecords().map { records ->
        records.filter { it.vehicleType == "Car" }.maxByOrNull { it.dateMillis }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private fun findNearestEvent(events: List<Event>): Pair<Event, Long>? {
        if (events.isEmpty()) return null
        val today = LocalDate.now()
        var nearestEvent: Event? = null
        var minDaysLeft = Long.MAX_VALUE

        events.forEach { event ->
            try {
                val eventDate = LocalDate.parse(event.date)
                var nextEventDate = eventDate.withYear(today.year)
                if (nextEventDate.isBefore(today)) {
                    nextEventDate = nextEventDate.plusYears(1)
                }
                val daysLeft = ChronoUnit.DAYS.between(today, nextEventDate)
                if (daysLeft < minDaysLeft) {
                    minDaysLeft = daysLeft
                    nearestEvent = event
                }
            } catch (e: Exception) {
            }
        }
        return nearestEvent?.let { Pair(it, minDaysLeft) }
    }
"""

content = re.sub(class_pattern, lambda m: m.group(0) + new_properties, content, count=1, flags=re.DOTALL)

with open("app/src/main/java/com/example/ReminderViewModel.kt", "w") as f:
    f.write(content)
