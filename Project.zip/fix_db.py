import re

with open("app/src/main/java/com/example/AppDatabase.kt", "r") as f:
    content = f.read()

# Replace version = 13 with version = 14
content = content.replace("version = 13", "version = 14")

# Remove fallbackToDestructiveMigration()
content = content.replace(".fallbackToDestructiveMigration()", "")

# Add imports
imports_to_add = """
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
"""
if "androidx.room.migration.Migration" not in content:
    content = content.replace("import androidx.room.RoomDatabase", "import androidx.room.RoomDatabase\n" + imports_to_add)

migrations_block = """
        val migrations = (1..13).map { startVersion ->
            object : Migration(startVersion, 14) {
                override fun migrate(db: SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE IF NOT EXISTS `events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `eventType` TEXT NOT NULL, `name` TEXT NOT NULL, `relationship` TEXT NOT NULL, `date` TEXT NOT NULL, `time` TEXT NOT NULL, `ringAlarm` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `fuel_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `vehicleType` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `odometerKm` INTEGER NOT NULL, `fuelLiters` REAL NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `service_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `vehicleType` TEXT NOT NULL, `lastServiceDate` TEXT NOT NULL, `nextServiceDate` TEXT NOT NULL, `nextServiceMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `notes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `noteType` TEXT NOT NULL, `content` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `scanned_texts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `extractedText` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `pdfUri` TEXT, `pageCount` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `scanned_docs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `fileUri` TEXT NOT NULL, `format` TEXT NOT NULL, `pageCount` INTEGER NOT NULL, `dateMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `qr_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `type` TEXT NOT NULL, `data` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `vault_records` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `category` TEXT NOT NULL, `title` TEXT NOT NULL, `secretData` TEXT NOT NULL, `extraInfo` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL)")
                    
                    try { db.execSQL("ALTER TABLE reminders ADD COLUMN isAlarmEnabled INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE notes ADD COLUMN noteType TEXT NOT NULL DEFAULT 'Text'") } catch (e: Exception) {}
                    try { db.execSQL("ALTER TABLE notes ADD COLUMN dateMillis INTEGER NOT NULL DEFAULT 0") } catch (e: Exception) {}
                }
            }
        }.toTypedArray()

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "somnath_reminder_db"
                ).addMigrations(*migrations)
                .build()
"""

# Replace the getDatabase function
old_get_db = """        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "somnath_reminder_db"
                )
                .build()"""

content = re.sub(
    r"        fun getDatabase\(context: Context\): AppDatabase \{.*?\.build\(\)",
    migrations_block.strip(),
    content,
    flags=re.DOTALL
)

with open("app/src/main/java/com/example/AppDatabase.kt", "w") as f:
    f.write(content)
