import re

with open("app/src/main/java/com/example/Reminder.kt", "r") as f:
    content = f.read()

new_content = content.replace("package com.example", "package com.example\n\nimport java.time.LocalDate\nimport java.time.LocalDateTime\nimport java.time.LocalTime\n\ndata class ActiveReminderInfo(\n    val dateTime: LocalDateTime,\n    val isPassed: Boolean\n)")

body = """} {
    fun getNextActiveReminder(): ActiveReminderInfo {
        val now = LocalDateTime.now()
        val primaryDt = try {
            LocalDateTime.of(LocalDate.parse(taskDate), LocalTime.parse(taskTime))
        } catch (e: Exception) {
            LocalDateTime.now() // Fallback
        }
        
        if (primaryDt.isAfter(now)) {
            return ActiveReminderInfo(primaryDt, false)
        }
        
        if (!reminder2Date.isNullOrBlank() && !reminder2Time.isNullOrBlank()) {
            try {
                val r2Dt = LocalDateTime.of(LocalDate.parse(reminder2Date), LocalTime.parse(reminder2Time))
                if (r2Dt.isAfter(now)) {
                    return ActiveReminderInfo(r2Dt, false)
                }
            } catch (e: Exception) {}
        }
        
        if (!reminder3Date.isNullOrBlank() && !reminder3Time.isNullOrBlank()) {
            try {
                val r3Dt = LocalDateTime.of(LocalDate.parse(reminder3Date), LocalTime.parse(reminder3Time))
                if (r3Dt.isAfter(now)) {
                    return ActiveReminderInfo(r3Dt, false)
                }
            } catch (e: Exception) {}
        }
        
        val lastDt = if (!reminder3Date.isNullOrBlank() && !reminder3Time.isNullOrBlank()) {
            try { LocalDateTime.of(LocalDate.parse(reminder3Date), LocalTime.parse(reminder3Time)) } catch(e: Exception) { primaryDt }
        } else if (!reminder2Date.isNullOrBlank() && !reminder2Time.isNullOrBlank()) {
            try { LocalDateTime.of(LocalDate.parse(reminder2Date), LocalTime.parse(reminder2Time)) } catch(e: Exception) { primaryDt }
        } else {
            primaryDt
        }
        
        return ActiveReminderInfo(lastDt, true)
    }
}"""

new_content = new_content.replace("\n)", "\n" + body)

with open("app/src/main/java/com/example/Reminder.kt", "w") as f:
    f.write(new_content)
