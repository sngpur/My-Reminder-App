with open("app/src/main/java/com/example/Reminder.kt", "r") as f:
    content = f.read()

content = content.replace('val imageUri: String? = null,', 'val imageUri: String? = null,\n    val isAlarmEnabled: Boolean = false,')

with open("app/src/main/java/com/example/Reminder.kt", "w") as f:
    f.write(content)
