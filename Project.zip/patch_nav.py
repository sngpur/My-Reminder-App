import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add to NavHost
nav_code = """        composable("settings") {
            SettingsScreen(navController = navController, settingsViewModel = settingsViewModel, reminderViewModel = reminderViewModel)
        }
        composable("trash") {
            TrashScreen(navController = navController, reminderViewModel = reminderViewModel, noteViewModel = noteViewModel)
        }"""
content = content.replace('composable("settings") {\n            SettingsScreen(navController = navController, settingsViewModel = settingsViewModel, reminderViewModel = reminderViewModel)\n        }', nav_code)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/SettingsScreen.kt", "r") as f:
    content = f.read()

# Add button to SettingsScreen
settings_code = """            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Enable Auto-Backup (Weekly)", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = isAutoBackupEnabled,
                    onCheckedChange = { settingsViewModel.setAutoBackup(it) }
                )
            }
            HorizontalDivider()
            
            Button(
                onClick = { navController.navigate("trash") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Open Recycle Bin")
            }
            
            HorizontalDivider()"""

content = content.replace("""            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Enable Auto-Backup (Weekly)", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = isAutoBackupEnabled,
                    onCheckedChange = { settingsViewModel.setAutoBackup(it) }
                )
            }
            HorizontalDivider()""", settings_code)

with open("app/src/main/java/com/example/SettingsScreen.kt", "w") as f:
    f.write(content)
