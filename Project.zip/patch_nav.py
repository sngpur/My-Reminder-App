import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    """} else if (title == "Documents Scanner") {
                                        navController.navigate("documents_scanner")
                                    } else {""",
    """} else if (title == "Documents Scanner") {
                                        navController.navigate("documents_scanner")
                                    } else if (title == "QR & Barcode Scanner") {
                                        navController.navigate("qr_barcode_scanner")
                                    } else {"""
)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

nav_route = """        composable("qr_barcode_scanner") {
            val qrBarcodeViewModel: QrBarcodeViewModel = viewModel { QrBarcodeViewModel(application) }
            QrBarcodeScreen(navController = navController, viewModel = qrBarcodeViewModel)
        }
"""

content = content.replace("""        composable("placeholder/{title}")""", nav_route + """        composable("placeholder/{title}")""")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
