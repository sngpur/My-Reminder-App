import re

with open("app/src/main/java/com/example/AppDatabase.kt", "r") as f:
    content = f.read()

content = content.replace("version = 10", "version = 11")
content = content.replace("ScannedDoc::class]", "ScannedDoc::class, QrRecord::class]")
content = content.replace("abstract fun scannedDocDao(): ScannedDocDao", "abstract fun scannedDocDao(): ScannedDocDao\n    abstract fun qrRecordDao(): QrRecordDao")

with open("app/src/main/java/com/example/AppDatabase.kt", "w") as f:
    f.write(content)
