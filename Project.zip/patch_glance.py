import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

glance_deps = """
    implementation("androidx.glance:glance-appwidget:1.1.0")
    implementation("androidx.glance:glance-material3:1.1.0")
"""

if "glance-appwidget" not in content:
    content = content.replace('dependencies {', 'dependencies {' + glance_deps)

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
