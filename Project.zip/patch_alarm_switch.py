import re

with open("app/src/main/java/com/example/AddReminderScreen.kt", "r") as f:
    content = f.read()

# Try to insert it before the "+ Add more reminders" button or at the end of the first card if it's there
match_str = "TextButton(onClick = { showExtraReminders = true }"

toggle_ui = """                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Ring Full Alarm", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                        Switch(checked = isAlarmEnabled, onCheckedChange = { isAlarmEnabled = it })
                    }
                    
                    """
content = content.replace(match_str, toggle_ui + match_str)

with open("app/src/main/java/com/example/AddReminderScreen.kt", "w") as f:
    f.write(content)
