import re

with open("app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

services_code = """        <service
            android:name=".QuickAddTileService"
            android:label="Add Task"
            android:icon="@android:drawable/ic_menu_add"
            android:permission="android.permission.BIND_QUICK_SETTINGS_TILE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.service.quicksettings.action.QS_TILE" />
            </intent-filter>
        </service>
        
        <activity
            android:name=".QuickAddActivity"
            android:theme="@style/Theme.AppCompat.Transparent.NoActionBar"
            android:excludeFromRecents="true"
            android:taskAffinity=""
            android:exported="true" />
            
    </application>"""

content = content.replace("</application>", services_code)

with open("app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
