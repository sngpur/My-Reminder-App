with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "r") as f:
    lines = f.readlines()

new_lines = []
dt_seen = False
for line in lines:
    if line.strip() == "import java.time.format.DateTimeFormatter":
        if not dt_seen:
            dt_seen = True
            new_lines.append(line)
    else:
        new_lines.append(line)

with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "w") as f:
    f.writelines(new_lines)
