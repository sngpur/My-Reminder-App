import re

with open("app/src/main/java/com/example/BootReceiver.kt", "r") as f:
    content = f.read()

old_code = """                    val events = eventDao.getAllEvents().firstOrNull()
                    events?.forEach { event ->
                        AlarmScheduler.scheduleEventAlarm(context, event)
                    }"""

new_code = """                    val events = eventDao.getAllEvents().firstOrNull()
                    events?.forEach { event ->
                        AlarmScheduler.scheduleEventAlarm(context, event)
                    }

                    val serviceRecords = db.serviceRecordDao().getAllServiceRecords().firstOrNull()
                    serviceRecords?.forEach { record ->
                        ServicingAlarmScheduler.scheduleServicingAlarm(context, record)
                    }"""

content = content.replace(old_code, new_code)

with open("app/src/main/java/com/example/BootReceiver.kt", "w") as f:
    f.write(content)
