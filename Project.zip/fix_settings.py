with open("app/src/main/java/com/example/SettingsScreen.kt", "r") as f:
    content = f.read()

pc_sync_insert = """            HorizontalDivider()
            var isSyncEnabled by remember { mutableStateOf(false) }
            val ipAddress = remember { com.example.PcSyncService.getLocalIpAddress() ?: "localhost" }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("PC Sync Dashboard", style = MaterialTheme.typography.titleMedium)
                    if (isSyncEnabled) {
                        Text("http://$ipAddress:8080/dashboard", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Switch(
                    checked = isSyncEnabled,
                    onCheckedChange = { 
                        isSyncEnabled = it
                        if (it) {
                            val intent = android.content.Intent(context, com.example.PcSyncService::class.java)
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                context.startForegroundService(intent)
                            } else {
                                context.startService(intent)
                            }
                        } else {
                            context.stopService(android.content.Intent(context, com.example.PcSyncService::class.java))
                        }
                    }
                )
            }
"""

content = content.replace("            Text(\"Full App Backup (Secure)\", style = MaterialTheme.typography.titleMedium)", pc_sync_insert + "\n            Text(\"Full App Backup (Secure)\", style = MaterialTheme.typography.titleMedium)")

with open("app/src/main/java/com/example/SettingsScreen.kt", "w") as f:
    f.write(content)
