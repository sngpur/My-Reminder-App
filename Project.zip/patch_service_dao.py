import re

with open("app/src/main/java/com/example/ServiceRecordDao.kt", "r") as f:
    content = f.read()

content = content.replace("suspend fun insertServiceRecord(record: ServiceRecord)", "suspend fun insertServiceRecord(record: ServiceRecord): Long")

with open("app/src/main/java/com/example/ServiceRecordDao.kt", "w") as f:
    f.write(content)
