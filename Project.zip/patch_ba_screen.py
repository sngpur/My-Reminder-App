import re

with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "r") as f:
    content = f.read()

# Add eventToEdit
if "var eventToEdit" not in content:
    content = content.replace("var showAddEventSheet by remember { mutableStateOf(false) }", "var showAddEventSheet by remember { mutableStateOf(false) }\n    var eventToEdit by remember { mutableStateOf<Event?>(null) }")

    # Update FAB
    content = content.replace("onClick = { showAddEventSheet = true }", "onClick = { eventToEdit = null; showAddEventSheet = true }")

    # Bottom sheet initial values
    content = content.replace('var eventType by remember { mutableStateOf("Birthday") }', 'var eventType by remember { mutableStateOf(eventToEdit?.eventType ?: "Birthday") }')
    content = content.replace('var name by remember { mutableStateOf("") }', 'var name by remember { mutableStateOf(eventToEdit?.name ?: "") }')
    content = content.replace('var relationship by remember { mutableStateOf("") }', 'var relationship by remember { mutableStateOf(eventToEdit?.relationship ?: "") }')
    content = content.replace('var dateStr by remember { mutableStateOf("1 Jan") }', 'var dateStr by remember { mutableStateOf(eventToEdit?.date ?: "1 Jan") }')
    content = content.replace('var timeStr by remember { mutableStateOf(String.format(Locale.getDefault(), "%02d:%02d", LocalTime.now().hour, LocalTime.now().minute)) }', 'var timeStr by remember { mutableStateOf(eventToEdit?.time ?: String.format(Locale.getDefault(), "%02d:%02d", LocalTime.now().hour, LocalTime.now().minute)) }')
    content = content.replace('var ringAlarm by remember { mutableStateOf(true) }', 'var ringAlarm by remember { mutableStateOf(eventToEdit?.ringAlarm ?: true) }')

    # Save button logic
    content = content.replace("""eventViewModel.addEvent(
                                Event(
                                    eventType = eventType,
                                    name = name,
                                    relationship = relationship,
                                    date = dateStr,
                                    time = timeStr,
                                    ringAlarm = ringAlarm
                                )
                            )""", """if (eventToEdit == null) {
                                eventViewModel.addEvent(
                                    Event(
                                        eventType = eventType,
                                        name = name,
                                        relationship = relationship,
                                        date = dateStr,
                                        time = timeStr,
                                        ringAlarm = ringAlarm
                                    )
                                )
                            } else {
                                eventViewModel.updateEvent(
                                    eventToEdit!!.copy(
                                        eventType = eventType,
                                        name = name,
                                        relationship = relationship,
                                        date = dateStr,
                                        time = timeStr,
                                        ringAlarm = ringAlarm
                                    )
                                )
                            }""")

    # Update list items to add edit and delete
    new_card_content = """var showDeleteConfirm by remember { mutableStateOf(false) }
                            if (showDeleteConfirm) {
                                AlertDialog(
                                    onDismissRequest = { showDeleteConfirm = false },
                                    title = { Text("Delete Event") },
                                    text = { Text("Are you sure you want to delete this event?") },
                                    confirmButton = {
                                        TextButton(
                                            onClick = {
                                                showDeleteConfirm = false
                                                eventViewModel.deleteEvent(event)
                                            }
                                        ) {
                                            Text("Delete", color = MaterialTheme.colorScheme.error)
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { showDeleteConfirm = false }) {
                                            Text("Cancel")
                                        }
                                    }
                                )
                            }
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    eventToEdit = event
                                    showAddEventSheet = true
                                },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                if (event.eventType == "Birthday") MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                                else MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (event.eventType == "Birthday") Icons.Filled.Cake else Icons.Filled.Favorite,
                                            contentDescription = event.eventType,
                                            tint = if (event.eventType == "Birthday") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = event.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${event.relationship} • ${event.date}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { showDeleteConfirm = true }) {
                                        Icon(androidx.compose.material.icons.Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }"""

    content = re.sub(r'Card\(\s*modifier = Modifier.fillMaxWidth\(\),\s*colors = CardDefaults.cardColors.*?Row\(.*?Spacer.*?Column.*?Text.*?Text.*?\}\s*\}\s*\}', new_card_content, content, flags=re.DOTALL)
    
    # We need to import Delete icon
    if "import androidx.compose.material.icons.filled.Delete" not in content:
        content = content.replace("import androidx.compose.material.icons.filled.Favorite", "import androidx.compose.material.icons.filled.Favorite\nimport androidx.compose.material.icons.filled.Delete")

    with open("app/src/main/java/com/example/BirthdayAnniversaryScreen.kt", "w") as f:
        f.write(content)

