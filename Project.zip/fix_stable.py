import os
import re

files_to_update = [
    "app/src/main/java/com/example/Reminder.kt",
    "app/src/main/java/com/example/VaultRecord.kt",
    "app/src/main/java/com/example/Note.kt",
    "app/src/main/java/com/example/ServiceRecord.kt",
    "app/src/main/java/com/example/AgeCalculatorScreen.kt",
    "app/src/main/java/com/example/Event.kt",
    "app/src/main/java/com/example/FuelRecord.kt",
    "app/src/main/java/com/example/ScannedText.kt",
    "app/src/main/java/com/example/NoteEditors.kt",
    "app/src/main/java/com/example/QrRecord.kt",
    "app/src/main/java/com/example/ScannedDoc.kt",
    "app/src/main/java/com/example/GlobalSearchViewModel.kt",
    "app/src/main/java/com/example/GlobalSearchScreen.kt",
    "app/src/main/java/com/example/WhatsAppSchedule.kt",
    "app/src/main/java/com/example/DocumentExpiry.kt",
    "app/src/main/java/com/example/NoteHistory.kt"
]

for file in files_to_update:
    if not os.path.exists(file):
        continue
    with open(file, "r") as f:
        content = f.read()
        
    if "import androidx.compose.runtime.Stable" not in content and "data class " in content:
        content = content.replace("package com.example\n", "package com.example\n\nimport androidx.compose.runtime.Stable\n")
        
        # We need to prepend @Stable to `data class`
        content = re.sub(r'data class ', r'@Stable\ndata class ', content)
        
        with open(file, "w") as f:
            f.write(content)
