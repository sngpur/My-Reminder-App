import re

with open("app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

# Add REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
if "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" not in content:
    content = content.replace(
        '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
        '<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />'
    )

# Add MY_PACKAGE_REPLACED
if "android.intent.action.MY_PACKAGE_REPLACED" not in content:
    content = content.replace(
        '<action android:name="android.intent.action.TIMEZONE_CHANGED" />',
        '<action android:name="android.intent.action.TIMEZONE_CHANGED" />\n                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />'
    )

with open("app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
