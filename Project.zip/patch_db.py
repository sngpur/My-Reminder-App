with open("app/src/main/java/com/example/AppDatabase.kt", "r") as f:
    content = f.read()

content = content.replace('version = 12,', 'version = 13,')

with open("app/src/main/java/com/example/AppDatabase.kt", "w") as f:
    f.write(content)
