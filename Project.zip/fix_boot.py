with open("app/src/main/java/com/example/BootReceiver.kt", "r") as f:
    content = f.read()

content = content.replace(
    'if (intent.action == Intent.ACTION_BOOT_COMPLETED) {',
    'if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {'
)

with open("app/src/main/java/com/example/BootReceiver.kt", "w") as f:
    f.write(content)
