import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# Change `val reminders by viewModel.uiState.collectAsStateWithLifecycle()` to `val remindersState = viewModel.uiState.collectAsStateWithLifecycle()`
# Wait, let's keep `val reminders by ...` and just use `remindersState`?
# Actually, I can just replace `val reminders by viewModel.uiState.collectAsStateWithLifecycle()` with `val remindersState = viewModel.uiState.collectAsStateWithLifecycle()`

old_collect = "val reminders by viewModel.uiState.collectAsStateWithLifecycle()"
new_collect = "val remindersState = viewModel.uiState.collectAsStateWithLifecycle()"
content = content.replace(old_collect, new_collect)

# Then replace `reminders` with `remindersState.value` everywhere except where we rewrite the derived state.
# Wait, doing global replace on `reminders` is risky. Let's do it surgically.

# For BentoDashboard call:
content = content.replace("reminders = reminders,", "reminders = remindersState.value,")
# For "View All (${reminders.size})":
content = content.replace("reminders.size", "remindersState.value.size")

# For the filtered state:
old_filtered = """        val filteredReminders = remember(reminders, searchQuery, selectedFilter) {
            reminders.filter {
                val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                matchesSearch && matchesFilter
            }
        }
        val groupedAndSorted = remember(filteredReminders) {
            filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }.toSortedMap()
        }"""
new_filtered = """        val filteredReminders by remember(searchQuery, selectedFilter) {
            androidx.compose.runtime.derivedStateOf {
                remindersState.value.filter {
                    val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                    val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                    matchesSearch && matchesFilter
                }
            }
        }
        val groupedAndSorted by remember(searchQuery, selectedFilter) {
            androidx.compose.runtime.derivedStateOf {
                filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }.toSortedMap()
            }
        }"""
content = content.replace(old_filtered, new_filtered)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
