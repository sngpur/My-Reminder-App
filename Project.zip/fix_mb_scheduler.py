with open("app/src/main/java/com/example/MorningBriefingScheduler.kt", "r") as f:
    content = f.read()

old_block = """            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                
                pendingIntent
            )"""
new_block = """            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            }"""

content = content.replace(old_block, new_block)

with open("app/src/main/java/com/example/MorningBriefingScheduler.kt", "w") as f:
    f.write(content)

