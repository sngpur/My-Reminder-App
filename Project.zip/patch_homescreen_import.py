import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# Add import for NotificationsActive
if "import androidx.compose.material.icons.filled.NotificationsActive" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.CheckCircle", "import androidx.compose.material.icons.filled.CheckCircle\nimport androidx.compose.material.icons.filled.NotificationsActive")

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
