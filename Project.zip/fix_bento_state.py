import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# BentoDashboard uses `reminders` directly. Wait, if it receives `reminders: List<Reminder>`, it can't use `derivedStateOf` on it efficiently since the list identity changes.
# We should change `BentoDashboard` to receive `remindersState: androidx.compose.runtime.State<List<Reminder>>`.

content = content.replace("reminders: List<Reminder>,", "remindersState: androidx.compose.runtime.State<List<Reminder>>,")
content = content.replace("reminders = remindersState.value,", "remindersState = remindersState,")

old_bento_calc = """    val (nearestTask, currentMonthPayment, currentMonthLent) = remember(reminders) {
        val upcomingTasks = reminders.filter { !it.isCompleted }.filter {
            !it.getNextActiveReminder().isPassed
        }.sortedBy { it.getNextActiveReminder().dateTime }
        
        val firstTask = upcomingTasks.firstOrNull()
        
        val currentYearMonth = YearMonth.now()
        var payment = 0.0
        var lent = 0.0
        
        reminders.forEach { r ->
            try {
                val date = LocalDate.parse(r.taskDate)
                if (YearMonth.from(date) == currentYearMonth && r.amount != null) {
                    if (r.category == "Upcoming Payment") payment += r.amount
                    else if (r.category == "Money Lent (Udhar)") lent += r.amount
                }
            } catch (e: Exception) {}
        }
        Triple(firstTask, payment, lent)
    }"""
new_bento_calc = """    val bentoData by remember {
        androidx.compose.runtime.derivedStateOf {
            val remindersList = remindersState.value
            val upcomingTasks = remindersList.filter { !it.isCompleted }.filter {
                !it.getNextActiveReminder().isPassed
            }.sortedBy { it.getNextActiveReminder().dateTime }
            
            val firstTask = upcomingTasks.firstOrNull()
            
            val currentYearMonth = YearMonth.now()
            var payment = 0.0
            var lent = 0.0
            
            remindersList.forEach { r ->
                try {
                    val date = LocalDate.parse(r.taskDate)
                    if (YearMonth.from(date) == currentYearMonth && r.amount != null) {
                        if (r.category == "Upcoming Payment") payment += r.amount
                        else if (r.category == "Money Lent (Udhar)") lent += r.amount
                    }
                } catch (e: Exception) {}
            }
            Triple(firstTask, payment, lent)
        }
    }
    val nearestTask = bentoData.first
    val currentMonthPayment = bentoData.second
    val currentMonthLent = bentoData.third"""

content = content.replace(old_bento_calc, new_bento_calc)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
