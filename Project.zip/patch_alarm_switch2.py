import re

with open("app/src/main/java/com/example/AddReminderScreen.kt", "r") as f:
    content = f.read()

match_str = "            if (!showExtraReminders) {"

toggle_ui = """            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Ring Full Alarm", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                    Switch(checked = isAlarmEnabled, onCheckedChange = { isAlarmEnabled = it })
                }
            }
            
"""
content = content.replace(match_str, toggle_ui + match_str)

with open("app/src/main/java/com/example/AddReminderScreen.kt", "w") as f:
    f.write(content)
