import re

with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "r") as f:
    content = f.read()
    
# Let's count braces in the file
def count_braces(text):
    open_b = text.count('{')
    close_b = text.count('}')
    return open_b, close_b

print(f"Total: {count_braces(content)}")
