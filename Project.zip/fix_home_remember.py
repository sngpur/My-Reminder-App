import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# Filtered Reminders
old_filtered = """            val filteredReminders = reminders.filter {
                val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                matchesSearch && matchesFilter
            }"""

new_filtered = """            val filteredReminders = remember(reminders, searchQuery, selectedFilter) {
                reminders.filter {
                    val matchesSearch = it.taskTitle.contains(searchQuery, ignoreCase = true) || it.location.contains(searchQuery, ignoreCase = true)
                    val matchesFilter = selectedFilter == "All" || it.category.contains(selectedFilter, ignoreCase = true) || (selectedFilter == "Udhar" && it.category == "Money Lent (Udhar)")
                    matchesSearch && matchesFilter
                }
            }"""

content = content.replace(old_filtered, new_filtered)

old_grouped = """                val grouped = filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }
                val todayStr = LocalDate.now().toString()
                
                grouped.toSortedMap().forEach { (date, tasks) ->"""

new_grouped = """                val groupedAndSorted = remember(filteredReminders) {
                    filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }.toSortedMap()
                }
                val todayStr = remember { LocalDate.now().toString() }
                
                groupedAndSorted.forEach { (date, tasks) ->"""

content = content.replace(old_grouped, new_grouped)

old_stats = """    val upcomingTasks = reminders.filter { !it.isCompleted }.filter {
        !it.getNextActiveReminder().isPassed
    }.sortedBy { it.getNextActiveReminder().dateTime }
    
    val nearestTask = upcomingTasks.firstOrNull()
    
    val currentYearMonth = YearMonth.now()
    var currentMonthPayment = 0.0
    var currentMonthLent = 0.0
    
    reminders.forEach { r ->
        val date = LocalDate.parse(r.taskDate)
        if (YearMonth.from(date) == currentYearMonth && r.amount != null) {
            if (r.category == "Upcoming Payment") currentMonthPayment += r.amount
            else if (r.category == "Money Lent (Udhar)") currentMonthLent += r.amount
        }
    }"""

new_stats = """    val (nearestTask, currentMonthPayment, currentMonthLent) = remember(reminders) {
        val upcomingTasks = reminders.filter { !it.isCompleted }.filter {
            !it.getNextActiveReminder().isPassed
        }.sortedBy { it.getNextActiveReminder().dateTime }
        
        val firstTask = upcomingTasks.firstOrNull()
        
        val currentYearMonth = YearMonth.now()
        var payment = 0.0
        var lent = 0.0
        
        reminders.forEach { r ->
            try {
                val date = LocalDate.parse(r.taskDate)
                if (YearMonth.from(date) == currentYearMonth && r.amount != null) {
                    if (r.category == "Upcoming Payment") payment += r.amount
                    else if (r.category == "Money Lent (Udhar)") lent += r.amount
                }
            } catch (e: Exception) {}
        }
        Triple(firstTask, payment, lent)
    }"""

content = content.replace(old_stats, new_stats)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)

