with open("app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

content = content.replace('<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />', '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />')

service_decl = """        <service android:name=".PcSyncService" android:foregroundServiceType="dataSync" android:exported="false" />"""

content = content.replace("        <service android:name=\".AlarmService\" android:foregroundServiceType=\"mediaPlayback\" android:exported=\"false\" />", "        <service android:name=\".AlarmService\" android:foregroundServiceType=\"mediaPlayback\" android:exported=\"false\" />\n" + service_decl)

with open("app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
