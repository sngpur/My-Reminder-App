import re

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "r") as f:
    content = f.read()

# Add imports for Context and WindowManager if they are not there
if "import android.view.WindowManager" not in content:
    content = content.replace("import androidx.compose.ui.Alignment", "import androidx.compose.ui.Alignment\nimport android.view.WindowManager\nimport android.app.Activity")

# Inject DisposableEffect inside SecureVaultScreen composable
old_composable_start = r"fun SecureVaultScreen\(navController: NavController, viewModel: SecureVaultViewModel\) \{"

new_composable_start = """fun SecureVaultScreen(navController: NavController, viewModel: SecureVaultViewModel) {

    val currentContext = LocalContext.current
    DisposableEffect(Unit) {
        val activity = currentContext as? Activity
        activity?.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }"""

content = re.sub(old_composable_start, new_composable_start, content, count=1)

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "w") as f:
    f.write(content)

