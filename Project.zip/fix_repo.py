import re

with open("app/src/main/java/com/example/ReminderRepository.kt", "r") as f:
    content = f.read()

new_content = """package com.example

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ReminderRepository(private val reminderDao: ReminderDao) {
    val allReminders: Flow<List<Reminder>> = reminderDao.getAllReminders()

    suspend fun insert(reminder: Reminder): Long = withContext(Dispatchers.IO) {
        reminderDao.insertReminder(reminder)
    }

    suspend fun update(reminder: Reminder) = withContext(Dispatchers.IO) {
        reminderDao.updateReminder(reminder)
    }

    suspend fun updateCompletionStatus(id: Int, isCompleted: Boolean) = withContext(Dispatchers.IO) {
        reminderDao.updateCompletionStatus(id, isCompleted)
    }

    suspend fun deleteById(id: Int) = withContext(Dispatchers.IO) {
        reminderDao.deleteReminderById(id)
    }
}
"""

with open("app/src/main/java/com/example/ReminderRepository.kt", "w") as f:
    f.write(new_content)

