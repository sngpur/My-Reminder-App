import re

with open("app/src/main/java/com/example/FullBackupManager.kt", "r") as f:
    content = f.read()

old_insert = "items.forEach { db.eventDao().insertEvent(it) }"
new_insert = "items.forEach { \n                            val newId = db.eventDao().insertEvent(it)\n                            AlarmScheduler.scheduleEventAlarm(context, it.copy(id = newId.toInt()))\n                        }"

content = content.replace(old_insert, new_insert)

with open("app/src/main/java/com/example/FullBackupManager.kt", "w") as f:
    f.write(content)
