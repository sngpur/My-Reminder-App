with open("app/src/main/java/com/example/ServiceRecordDao.kt", "r") as f:
    content = f.read()

content = content.replace("    fun getAllServiceRecords(): Flow<List<ServiceRecord>>", "    fun getAllServiceRecords(): Flow<List<ServiceRecord>>\n\n    @Query(\"SELECT * FROM service_records\")\n    fun getAllServiceRecordsSync(): List<ServiceRecord>")

with open("app/src/main/java/com/example/ServiceRecordDao.kt", "w") as f:
    f.write(content)
