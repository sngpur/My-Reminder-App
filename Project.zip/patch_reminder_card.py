with open("app/src/main/java/com/example/AddReminderScreen.kt", "r") as f:
    content = f.read()

import re

# Replace Reminder 2 trailing icon
old_r2_time = """                            OutlinedTextField(
                                value = reminder2TimeStr ?: "",
                                onValueChange = {},
                                readOnly = true,
                                placeholder = { Text("Time") },
                                trailingIcon = { Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) },"""
new_r2_time = """                            OutlinedTextField(
                                value = reminder2TimeStr ?: "",
                                onValueChange = {},
                                readOnly = true,
                                placeholder = { Text("Time") },
                                trailingIcon = { 
                                    if (reminder2TimeStr != null) {
                                        IconButton(onClick = { reminder2DateStr = null; reminder2TimeStr = null }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear Reminder", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                                        }
                                    } else {
                                        Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) 
                                    }
                                },"""
content = content.replace(old_r2_time, new_r2_time)

# Replace Reminder 3 trailing icon
old_r3_time = """                            OutlinedTextField(
                                value = reminder3TimeStr ?: "",
                                onValueChange = {},
                                readOnly = true,
                                placeholder = { Text("Time") },
                                trailingIcon = { Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) },"""
new_r3_time = """                            OutlinedTextField(
                                value = reminder3TimeStr ?: "",
                                onValueChange = {},
                                readOnly = true,
                                placeholder = { Text("Time") },
                                trailingIcon = { 
                                    if (reminder3TimeStr != null) {
                                        IconButton(onClick = { reminder3DateStr = null; reminder3TimeStr = null }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear Reminder", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                                        }
                                    } else {
                                        Icon(androidx.compose.material.icons.Icons.Outlined.AccessTime, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) 
                                    }
                                },"""
content = content.replace(old_r3_time, new_r3_time)

# Add Toggle for Alarm at the end of Primary Reminder Card
old_end_card = """                        TextButton(onClick = { showExtraReminders = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("+ Add more reminders")
                        }
                    }
                }
            }"""
new_end_card = """                        TextButton(onClick = { showExtraReminders = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("+ Add more reminders")
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Ring Full Alarm", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                        Switch(checked = isAlarmEnabled, onCheckedChange = { isAlarmEnabled = it })
                    }
                }
            }"""
content = content.replace(old_end_card, new_end_card)

# Inject isAlarmEnabled into Reminder constructor
old_reminder_init = """                            imageUri = imageUri,
                            tags = tags,
                            isCompleted = existingReminder?.isCompleted ?: false"""
new_reminder_init = """                            imageUri = imageUri,
                            isAlarmEnabled = isAlarmEnabled,
                            tags = tags,
                            isCompleted = existingReminder?.isCompleted ?: false"""
content = content.replace(old_reminder_init, new_reminder_init)

# Check if Icons.Default.Clear is imported, if not add it
if "import androidx.compose.material.icons.filled.Clear" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.Check", "import androidx.compose.material.icons.filled.Check\nimport androidx.compose.material.icons.filled.Clear")

with open("app/src/main/java/com/example/AddReminderScreen.kt", "w") as f:
    f.write(content)

