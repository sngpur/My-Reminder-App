import re

with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "r") as f:
    content = f.read()

start_str = "itemsIndexed(sortedRecords) {"
start_idx = content.find(start_str)
end_str = "}            }        }    }    if (showFuelDialog) {"

if start_idx != -1:
    end_idx = content.find(end_str)
    if end_idx != -1:
        replacement = """itemsIndexed(sortedRecords) { index, record ->
                    val previousRecord = if (index + 1 < sortedRecords.size) sortedRecords[index + 1] else null
                    FuelRecordItem(
                        record = record,
                        previousRecord = previousRecord,
                        onEdit = {
                            logToEdit = record
                            showFuelDialog = true
                        },
                        onDelete = { viewModel.deleteFuelRecord(record) }
                    )
                }
"""
        content = content[:start_idx] + replacement + "            " + content[end_idx:]

with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "w") as f:
    f.write(content)

