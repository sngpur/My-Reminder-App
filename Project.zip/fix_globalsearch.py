with open("app/src/main/java/com/example/GlobalSearchScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    "data class ChatMessage(val text: String, val isUser: Boolean)",
    "data class ChatMessage(val text: String, val isUser: Boolean, val id: String = java.util.UUID.randomUUID().toString())"
)

content = content.replace(
    "items(messages) { msg ->",
    "items(messages, key = { it.id }, contentType = { \"chat\" }) { msg ->"
)

with open("app/src/main/java/com/example/GlobalSearchScreen.kt", "w") as f:
    f.write(content)
