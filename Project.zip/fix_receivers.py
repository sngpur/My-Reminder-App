import os
import re

files_to_update = [
    "app/src/main/java/com/example/NotificationReceiver.kt",
    "app/src/main/java/com/example/MarkCompleteReceiver.kt",
    "app/src/main/java/com/example/BootReceiver.kt",
    "app/src/main/java/com/example/ServicingActionReceiver.kt",
    "app/src/main/java/com/example/WhatsAppAlarmReceiver.kt",
    "app/src/main/java/com/example/WhatsAppActionReceiver.kt",
    "app/src/main/java/com/example/MorningBriefingReceiver.kt"
]

for file in files_to_update:
    if not os.path.exists(file):
        continue
    with open(file, "r") as f:
        content = f.read()

    if "val pendingResult = goAsync()" not in content:
        content = content.replace(
            "CoroutineScope(Dispatchers.IO).launch {",
            "val pendingResult = goAsync()\n        CoroutineScope(Dispatchers.IO).launch {\n            try {"
        )
        # This is a bit tricky, let's find the closing brace of CoroutineScope.
        # Actually, let's just do a manual replacement for each file if it's too complex, or just use a simple regex.
        # Let's replace the last closing brace of the file with `} finally { pendingResult.finish() } } }`
        
        # A better way is to do it using python script that counts braces, but since we know the structure:
        
        pass

