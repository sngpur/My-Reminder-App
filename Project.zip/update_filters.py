import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# 1. Remove the chips
chips_pattern = r"item \{\s*val filters = listOf.*?\}\s*\}"
content = re.sub(chips_pattern, "", content, flags=re.DOTALL)

# 2. Add the Filter icon and Dropdown Menu
header_original = """            item {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("UPCOMING SCHEDULE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                    Text("View All (${reminders.size})", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
            }"""

header_new = """            item {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("UPCOMING SCHEDULE", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("View All (${reminders.size})", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { expanded = true }) {
                                Icon(androidx.compose.material.icons.Icons.Default.FilterList, contentDescription = "Filter")
                            }
                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                listOf("All", "Upcoming Payment", "Udhar", "Personal Work", "Other").forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category) },
                                        onClick = { 
                                            selectedFilter = category
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }"""

if "UPCOMING SCHEDULE" in content:
    content = content.replace(header_original, header_new)

# Add import
import_stmt = "import androidx.compose.material.icons.filled.FilterList\n"
if "FilterList" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.Add", "import androidx.compose.material.icons.filled.Add\n" + import_stmt)


with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
