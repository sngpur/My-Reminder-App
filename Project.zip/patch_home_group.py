import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

old_grouping = "val grouped = filteredReminders.groupBy { it.taskDate }"
new_grouping = "val grouped = filteredReminders.groupBy { it.getNextActiveReminder().dateTime.toLocalDate().toString() }"

content = content.replace(old_grouping, new_grouping)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
