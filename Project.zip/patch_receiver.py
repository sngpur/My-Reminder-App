with open("app/src/main/java/com/example/NotificationReceiver.kt", "r") as f:
    content = f.read()

import re

# Add imports for Notification
if "import android.app.NotificationManager" not in content:
    content = content.replace("import android.content.Intent", "import android.content.Intent\nimport android.app.NotificationManager\nimport android.app.NotificationChannel\nimport androidx.core.app.NotificationCompat\nimport android.app.PendingIntent\nimport android.media.RingtoneManager")

new_onReceive = """    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Reminder"
        val category = intent.getStringExtra("category") ?: ""
        val id = intent.getIntExtra("id", 0)
        val isAlarmEnabled = intent.getBooleanExtra("isAlarmEnabled", false)

        if (isAlarmEnabled) {
            val serviceIntent = Intent(context, AlarmService::class.java).apply {
                putExtra("title", title)
                putExtra("category", category)
                putExtra("id", id)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } else {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "standard_reminder_channel"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    channelId,
                    "Standard Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Task reminders without full-screen alarm"
                }
                notificationManager.createNotificationChannel(channel)
            }
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context, id, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(category)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setContentIntent(pendingIntent)
                .build()
            notificationManager.notify(id, notification)
        }

        // Advance repeating tasks when alarm triggers"""

content = re.sub(r'    override fun onReceive\(context: Context, intent: Intent\) \{.*?\n        // Advance repeating tasks when alarm triggers', new_onReceive, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/NotificationReceiver.kt", "w") as f:
    f.write(content)

