import re

with open("app/src/main/java/com/example/ReminderViewModel.kt", "r") as f:
    content = f.read()

content = content.replace("val uiState: StateFlow<List<Reminder>> = repository.allReminders",
"""val uiState: StateFlow<List<Reminder>> = repository.allReminders
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        
    val trashedReminders: kotlinx.coroutines.flow.StateFlow<List<Reminder>> = reminderDao.getTrashedReminders()
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
""")

with open("app/src/main/java/com/example/ReminderViewModel.kt", "w") as f:
    f.write(content)
