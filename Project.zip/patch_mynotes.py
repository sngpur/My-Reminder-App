import re

with open("app/src/main/java/com/example/MyNotesScreen.kt", "r") as f:
    content = f.read()

# Update NoteCard onClick mapping
old_routing = """                                val route = when (selectedNote.noteType) {
                                    "Text" -> "note_editor_text"
                                    "List" -> "note_editor_list"
                                    "Image" -> "note_editor_image"
                                    "Drawing" -> "note_editor_drawing"
                                    else -> "note_editor_text"
                                }"""
new_routing = """                                val route = when (selectedNote.noteType) {
                                    "Drawing" -> "note_editor_drawing"
                                    else -> "note_editor_text"
                                }"""
content = content.replace(old_routing, new_routing)

# Update FabMenu items
old_fab_items = """                    NoteTypeItem(
                        icon = Icons.Outlined.Checklist,
                        label = "List",
                        onClick = { showFabMenu = false; navController.navigate("note_editor_list") }
                    )
                    NoteTypeItem(
                        icon = Icons.Outlined.Image,
                        label = "Image",
                        onClick = { showFabMenu = false; navController.navigate("note_editor_image") }
                    )"""
content = content.replace(old_fab_items, "")

with open("app/src/main/java/com/example/MyNotesScreen.kt", "w") as f:
    f.write(content)
