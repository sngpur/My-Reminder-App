import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace('Text("${nearestTask.taskDate}"', 'Text("${nearestTask.getNextActiveReminder().dateTime.toLocalDate()}"')

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
