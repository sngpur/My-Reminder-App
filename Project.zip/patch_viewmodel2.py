import re

with open("app/src/main/java/com/example/ReminderViewModel.kt", "r") as f:
    content = f.read()

# Replace the latestBikeMileage and latestCarMileage declarations and add the helper
pattern = r"val latestBikeMileage = fuelRecordDao\.getAllFuelRecords.*?private fun findNearestEvent"

new_code = """val latestBikeMileage = fuelRecordDao.getAllFuelRecords().map { records ->
        calculateLatestMileage(records.filter { it.vehicleType == "Bike" })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val latestCarMileage = fuelRecordDao.getAllFuelRecords().map { records ->
        calculateLatestMileage(records.filter { it.vehicleType == "Car" })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private fun calculateLatestMileage(records: List<FuelRecord>): Double? {
        val sorted = records.sortedByDescending { it.dateMillis }
        if (sorted.size >= 2) {
            val latest = sorted[0]
            val previous = sorted[1]
            val distance = latest.odometerKm - previous.odometerKm
            if (distance > 0 && latest.fuelLiters > 0) {
                return distance / latest.fuelLiters
            }
        }
        return null
    }

    private fun findNearestEvent"""

content = re.sub(pattern, new_code, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/ReminderViewModel.kt", "w") as f:
    f.write(content)
