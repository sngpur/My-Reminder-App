import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

ktor_deps = """
  implementation("io.ktor:ktor-server-core:2.3.9")
  implementation("io.ktor:ktor-server-netty:2.3.9")
"""
content = content.replace('  implementation("com.google.zxing:core:3.5.3")', '  implementation("com.google.zxing:core:3.5.3")\n' + ktor_deps)

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
