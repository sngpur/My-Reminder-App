import re

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "r") as f:
    content = f.read()

import_insert = """import android.graphics.Bitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import androidx.compose.material.icons.filled.QrCode
"""

content = content.replace("import android.content.Context", "import android.content.Context\n" + import_insert)

qr_func = """
fun generateQrCode(text: String, size: Int = 512): Bitmap? {
    try {
        val bitMatrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val width = bitMatrix.width
        val height = bitMatrix.height
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bmp.setPixel(x, y, if (bitMatrix.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
        return bmp
    } catch (e: Exception) {
        return null
    }
}
"""
content = content.replace("@Composable\nfun VaultItemCard(", qr_func + "\n@Composable\nfun VaultItemCard(")

state_insert = """    var isVisible by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }

    if (showQrDialog) {
        var timeLeft by remember { mutableStateOf(60) }
        LaunchedEffect(Unit) {
            while (timeLeft > 0) {
                kotlinx.coroutines.delay(1000)
                timeLeft--
            }
            showQrDialog = false
        }
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            title = { Text("Temporary QR Share") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text("Self-destructing in $timeLeft seconds...", color = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.height(16.dp))
                    val qrBmp = remember(record.secretData) { generateQrCode(record.secretData) }
                    if (qrBmp != null) {
                        Image(
                            bitmap = qrBmp.asImageBitmap(),
                            contentDescription = "QR Code",
                            modifier = Modifier.size(200.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQrDialog = false }) { Text("Close") }
            }
        )
    }
"""

content = content.replace("    var isVisible by remember { mutableStateOf(false) }\n    var showDeleteConfirm by remember { mutableStateOf(false) }", state_insert)

btn_insert = """                    IconButton(onClick = { showQrDialog = true }) {
                        Icon(Icons.Default.QrCode, contentDescription = "Share via QR")
                    }
                    IconButton(onClick = { isVisible = !isVisible }) {"""

content = content.replace("                    IconButton(onClick = { isVisible = !isVisible }) {", btn_insert)

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "w") as f:
    f.write(content)
