with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "r") as f:
    content = f.read()
import re
# We need to make sure `val sortedRecords = currentFuelRecords.sortedByDescending { it.dateMillis }` is present before `itemsIndexed(sortedRecords)`
if "val sortedRecords" not in content:
    content = content.replace("itemsIndexed(sortedRecords) {", "val sortedRecords = currentFuelRecords.sortedByDescending { it.dateMillis }\n                itemsIndexed(sortedRecords) {")
    with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "w") as f:
        f.write(content)
