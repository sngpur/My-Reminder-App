import sys

with open("app/src/main/java/com/example/DocumentScannerScreen.kt", "r") as f:
    content = f.read()

imports = """
import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_JPEG
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_PDF
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.SCANNER_MODE_FULL
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
"""

content = content.replace("import androidx.compose.runtime.getValue", "import androidx.compose.runtime.getValue\n" + imports)

logic = """
    val scannedDocs by viewModel.allScannedDocs.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var scanResult by remember { mutableStateOf<GmsDocumentScanningResult?>(null) }

    val scannerOptions = remember {
        GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setResultFormats(RESULT_FORMAT_JPEG, RESULT_FORMAT_PDF)
            .setScannerMode(SCANNER_MODE_FULL)
            .build()
    }

    val scannerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scanResult = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
        }
    }

    val launchScanner = {
        val client = GmsDocumentScanning.getClient(scannerOptions)
        val activity = context.findActivity()
        if (activity != null) {
            client.getStartScanIntent(activity)
                .addOnSuccessListener { intentSender ->
                    scannerLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Failed to start scanner: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(context, "Could not find Activity context", Toast.LENGTH_SHORT).show()
        }
    }
"""

content = content.replace("    val scannedDocs by viewModel.allScannedDocs.collectAsStateWithLifecycle()", logic)

content = content.replace(".clickable { /* TODO: Launch Scanner in Part 2 */ }", ".clickable { launchScanner() }")

with open("app/src/main/java/com/example/DocumentScannerScreen.kt", "w") as f:
    f.write(content)
