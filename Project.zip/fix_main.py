with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if "val globalSearchViewModel: GlobalSearchViewModel" in line:
        continue
    if "GlobalSearchScreen(navController = navController, viewModel = globalSearchViewModel)" in line:
        new_lines.append(line.replace(", viewModel = globalSearchViewModel", ""))
    else:
        new_lines.append(line)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.writelines(new_lines)
