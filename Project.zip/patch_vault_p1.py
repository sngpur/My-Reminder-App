import re

# 1. Update build.gradle.kts
with open("app/build.gradle.kts", "r") as f:
    content = f.read()
if "androidx.biometric:biometric" not in content:
    content = content.replace(
        'implementation(libs.androidx.room.runtime)',
        'implementation(libs.androidx.room.runtime)\n  implementation("androidx.biometric:biometric:1.1.0")'
    )
with open("app/build.gradle.kts", "w") as f:
    f.write(content)

# 2. Room Database files
with open("app/src/main/java/com/example/VaultRecord.kt", "w") as f:
    f.write("""package com.example

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_records")
data class VaultRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // "Password", "Card", or "Note"
    val title: String,
    val secretData: String,
    val extraInfo: String,
    val dateMillis: Long = System.currentTimeMillis()
)
""")

with open("app/src/main/java/com/example/VaultRecordDao.kt", "w") as f:
    f.write("""package com.example

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultRecordDao {
    @Query("SELECT * FROM vault_records ORDER BY dateMillis DESC")
    fun getAllVaultRecords(): Flow<List<VaultRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultRecord(record: VaultRecord)

    @Update
    suspend fun updateVaultRecord(record: VaultRecord)

    @Delete
    suspend fun deleteVaultRecord(record: VaultRecord)
}
""")

with open("app/src/main/java/com/example/SecureVaultViewModel.kt", "w") as f:
    f.write("""package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SecureVaultViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).vaultRecordDao()
    
    val allRecords: StateFlow<List<VaultRecord>> = dao.getAllVaultRecords()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun insertRecord(record: VaultRecord) {
        viewModelScope.launch {
            dao.insertVaultRecord(record)
        }
    }

    fun updateRecord(record: VaultRecord) {
        viewModelScope.launch {
            dao.updateVaultRecord(record)
        }
    }

    fun deleteRecord(record: VaultRecord) {
        viewModelScope.launch {
            dao.deleteVaultRecord(record)
        }
    }
}
""")

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "w") as f:
    f.write("""package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecureVaultScreen(navController: NavController, viewModel: SecureVaultViewModel) {
    var isUnlocked by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Secure Vault", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        if (!isUnlocked) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Locked",
                    modifier = Modifier.size(100.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Vault is Locked",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Unlock to view your secure data",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(32.dp))
                Button(
                    onClick = { isUnlocked = true },
                    modifier = Modifier.fillMaxWidth(0.8f),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    Icon(Icons.Default.LockOpen, contentDescription = "Unlock")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Unlock Vault")
                }
            }
        } else {
            // Unlocked state (placeholder for now)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Vault Unlocked", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = { isUnlocked = false }) {
                    Text("Lock Vault")
                }
            }
        }
    }
}
""")

# 3. Update AppDatabase.kt
with open("app/src/main/java/com/example/AppDatabase.kt", "r") as f:
    content = f.read()

content = content.replace("version = 11", "version = 12")
content = content.replace("QrRecord::class]", "QrRecord::class, VaultRecord::class]")
if "abstract fun vaultRecordDao(): VaultRecordDao" not in content:
    content = content.replace("abstract fun qrRecordDao(): QrRecordDao", "abstract fun qrRecordDao(): QrRecordDao\n    abstract fun vaultRecordDao(): VaultRecordDao")

with open("app/src/main/java/com/example/AppDatabase.kt", "w") as f:
    f.write(content)

# 4. Update HomeScreen.kt
with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    """} else if (title == "QR & Barcode Scanner") {
                                        navController.navigate("qr_barcode_scanner")
                                    } else {""",
    """} else if (title == "QR & Barcode Scanner") {
                                        navController.navigate("qr_barcode_scanner")
                                    } else if (title == "Secure Vault") {
                                        navController.navigate("secure_vault")
                                    } else {"""
)
with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)

# 5. Update MainActivity.kt
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

nav_route = """        composable("secure_vault") {
            val secureVaultViewModel: SecureVaultViewModel = viewModel { SecureVaultViewModel(application) }
            SecureVaultScreen(navController = navController, viewModel = secureVaultViewModel)
        }
"""
if 'composable("secure_vault")' not in content:
    content = content.replace("""        composable("placeholder/{title}")""", nav_route + """        composable("placeholder/{title}")""")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
