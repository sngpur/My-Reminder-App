import re

with open("app/src/main/java/com/example/ServiceRecordDao.kt", "r") as f:
    content = f.read()

content = content.replace("fun getAllServiceRecords(): Flow<List<ServiceRecord>>", "fun getAllServiceRecords(): Flow<List<ServiceRecord>>\n\n    @Query(\"SELECT * FROM service_records WHERE id = :id LIMIT 1\")\n    suspend fun getServiceRecordById(id: Int): ServiceRecord?")

with open("app/src/main/java/com/example/ServiceRecordDao.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/EventDao.kt", "r") as f:
    content = f.read()

content = content.replace("fun getAllEvents(): Flow<List<Event>>", "fun getAllEvents(): Flow<List<Event>>\n\n    @Query(\"SELECT * FROM events WHERE id = :id LIMIT 1\")\n    suspend fun getEventById(id: Int): Event?")

with open("app/src/main/java/com/example/EventDao.kt", "w") as f:
    f.write(content)
