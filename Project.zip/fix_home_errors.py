import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# Fix export launcher
content = content.replace("reminders.forEach { r ->", "remindersState.value.forEach { r ->")

# Fix BentoDashboard smart casts
old_bento = """@Composable
fun BentoDashboard(
    remindersState: androidx.compose.runtime.State<List<Reminder>>,
    viewModel: ReminderViewModel,
    onMonthlySummaryClick: () -> Unit
) {
    val nearestBirthday by viewModel.nearestBirthday.collectAsStateWithLifecycle()
    val nearestAnniversary by viewModel.nearestAnniversary.collectAsStateWithLifecycle()
    val latestBikeMileage by viewModel.latestBikeMileage.collectAsStateWithLifecycle()
    val latestCarMileage by viewModel.latestCarMileage.collectAsStateWithLifecycle()"""

new_bento = """@Composable
fun BentoDashboard(
    remindersState: androidx.compose.runtime.State<List<Reminder>>,
    viewModel: ReminderViewModel,
    onMonthlySummaryClick: () -> Unit
) {
    val nearestBirthdayState by viewModel.nearestBirthday.collectAsStateWithLifecycle()
    val nearestAnniversaryState by viewModel.nearestAnniversary.collectAsStateWithLifecycle()
    val latestBikeMileageState by viewModel.latestBikeMileage.collectAsStateWithLifecycle()
    val latestCarMileageState by viewModel.latestCarMileage.collectAsStateWithLifecycle()
    
    val nearestBirthday = nearestBirthdayState
    val nearestAnniversary = nearestAnniversaryState
    val latestBikeMileage = latestBikeMileageState
    val latestCarMileage = latestCarMileageState"""

content = content.replace(old_bento, new_bento)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
