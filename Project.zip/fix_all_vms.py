import glob
import os

for filepath in glob.glob("app/src/main/java/com/example/*.kt"):
    with open(filepath, "r") as f:
        content = f.read()
    
    if "viewModelScope.launch {" in content:
        content = content.replace("viewModelScope.launch {", "viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {")
        with open(filepath, "w") as f:
            f.write(content)

