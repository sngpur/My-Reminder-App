import re

with open("app/src/main/java/com/example/AddReminderScreen.kt", "r") as f:
    content = f.read()

content = content.replace('value = reminder2DateStr ?: "",', 'value = reminder2DateStr ?: "",\n                                placeholder = { Text("No Alarm") },')
content = content.replace('placeholder = { Text("Date") },', '') # we just added No Alarm as placeholder, let's just do a clean replace

