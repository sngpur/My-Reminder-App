import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace("                            modifier = Modifier.padding(androidx.compose.material3.NavigationDrawerItemDefaults.ItemPadding)\n", "")

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
