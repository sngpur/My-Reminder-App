import re

# ReminderViewModel.kt
with open("app/src/main/java/com/example/ReminderViewModel.kt", "r") as f:
    content = f.read()

if "trashedReminders" not in content:
    content = content.replace("val allReminders: StateFlow<List<Reminder>> = reminderDao.getAllReminders()",
    """val allReminders: StateFlow<List<Reminder>> = reminderDao.getAllReminders()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        
    val trashedReminders: StateFlow<List<Reminder>> = reminderDao.getTrashedReminders()""")
    content = content.replace("fun deleteReminder(reminder: Reminder) {",
    """fun permanentlyDeleteReminder(id: Int) {
        viewModelScope.launch { reminderDao.permanentlyDeleteReminderById(id) }
    }
    
    fun restoreReminder(id: Int) {
        viewModelScope.launch { reminderDao.restoreReminderById(id) }
    }
    
    fun deleteReminder(reminder: Reminder) {""")

with open("app/src/main/java/com/example/ReminderViewModel.kt", "w") as f:
    f.write(content)

# NoteViewModel.kt
with open("app/src/main/java/com/example/NoteViewModel.kt", "r") as f:
    content = f.read()
if "trashedNotes" not in content:
    content = content.replace("val allNotes: StateFlow<List<Note>> = noteDao.getAllNotes()",
    """val allNotes: StateFlow<List<Note>> = noteDao.getAllNotes()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        
    val trashedNotes: StateFlow<List<Note>> = noteDao.getTrashedNotes()""")
    content = content.replace("fun deleteNote(note: Note) {",
    """fun permanentlyDeleteNote(note: Note) {
        viewModelScope.launch { noteDao.deleteNote(note) }
    }
    
    fun restoreNote(id: Int) {
        viewModelScope.launch { noteDao.restoreNoteById(id) }
    }
    
    fun deleteNote(note: Note) {""")

with open("app/src/main/java/com/example/NoteViewModel.kt", "w") as f:
    f.write(content)
