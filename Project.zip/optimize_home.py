import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

# 1. Remove collect from HomeScreen
content = content.replace("    val nearestBirthday by viewModel.nearestBirthday.collectAsStateWithLifecycle()\n", "")
content = content.replace("    val nearestAnniversary by viewModel.nearestAnniversary.collectAsStateWithLifecycle()\n", "")
content = content.replace("    val latestBikeMileage by viewModel.latestBikeMileage.collectAsStateWithLifecycle()\n", "")
content = content.replace("    val latestCarMileage by viewModel.latestCarMileage.collectAsStateWithLifecycle()\n", "")

# 2. Update BentoDashboard call
old_bento_call = """                BentoDashboard(
                    reminders = reminders,
                    nearestBirthday = nearestBirthday,
                    nearestAnniversary = nearestAnniversary,
                    latestBikeMileage = latestBikeMileage,
                    latestCarMileage = latestCarMileage,
                    onMonthlySummaryClick = { navController.navigate("monthly_summary") }
                )"""
new_bento_call = """                BentoDashboard(
                    reminders = reminders,
                    viewModel = viewModel,
                    onMonthlySummaryClick = { navController.navigate("monthly_summary") }
                )"""
content = content.replace(old_bento_call, new_bento_call)

# 3. Update BentoDashboard signature and collect inside
old_bento_sig = """@Composable
fun BentoDashboard(
    reminders: List<Reminder>,
    nearestBirthday: Pair<com.example.Event, Long>?,
    nearestAnniversary: Pair<com.example.Event, Long>?,
    latestBikeMileage: Double?,
    latestCarMileage: Double?,
    onMonthlySummaryClick: () -> Unit
) {"""
new_bento_sig = """@Composable
fun BentoDashboard(
    reminders: List<Reminder>,
    viewModel: ReminderViewModel,
    onMonthlySummaryClick: () -> Unit
) {
    val nearestBirthday by viewModel.nearestBirthday.collectAsStateWithLifecycle()
    val nearestAnniversary by viewModel.nearestAnniversary.collectAsStateWithLifecycle()
    val latestBikeMileage by viewModel.latestBikeMileage.collectAsStateWithLifecycle()
    val latestCarMileage by viewModel.latestCarMileage.collectAsStateWithLifecycle()"""
content = content.replace(old_bento_sig, new_bento_sig)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
