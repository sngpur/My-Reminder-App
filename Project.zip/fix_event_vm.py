with open("app/src/main/java/com/example/EventViewModel.kt", "r") as f:
    content = f.read()

content = content.replace("viewModelScope.launch {", "viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {")

with open("app/src/main/java/com/example/EventViewModel.kt", "w") as f:
    f.write(content)
