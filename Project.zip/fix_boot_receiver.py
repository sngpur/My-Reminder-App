with open("app/src/main/java/com/example/BootReceiver.kt", "r") as f:
    content = f.read()

content = content.replace("eventDao.getAllEvents().firstOrNull()", "eventDao.getAllEventsSync()")
content = content.replace("db.serviceRecordDao().getAllServiceRecords().firstOrNull()", "db.serviceRecordDao().getAllServiceRecordsSync()")

with open("app/src/main/java/com/example/BootReceiver.kt", "w") as f:
    f.write(content)
