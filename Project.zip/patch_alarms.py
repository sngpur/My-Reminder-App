import re

files = [
    "app/src/main/java/com/example/AlarmService.kt",
    "app/src/main/java/com/example/BirthdayAlarmService.kt",
    "app/src/main/java/com/example/ServicingAlarmReceiver.kt",
    "app/src/main/java/com/example/BirthdayAlarmReceiver.kt",
    "app/src/main/java/com/example/AlarmStopReceiver.kt",
    "app/src/main/java/com/example/BirthdayActionReceiver.kt"
]

for file in files:
    with open(file, "r") as f:
        content = f.read()

    # For AlarmService.kt
    if "AlarmService.kt" in file:
        content = content.replace(
            """val launchIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }""",
            """val launchIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("route", "notification_details/Task/${notificationId}?isAlarmRinging=true")
        }"""
        )
    
    if "BirthdayAlarmService.kt" in file:
        content = content.replace(
            """val launchIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }""",
            """val launchIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("route", "notification_details/${eventType}/${eventId}?isAlarmRinging=true")
        }"""
        )

    if "ServicingAlarmReceiver.kt" in file:
        content = content.replace(
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }""",
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("route", "notification_details/Vehicle/${recordId}?isAlarmRinging=false")
        }"""
        )

    if "BirthdayAlarmReceiver.kt" in file:
        content = content.replace(
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }""",
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("route", "notification_details/${eventType}/${eventId}?isAlarmRinging=false")
        }"""
        )

    if "AlarmStopReceiver.kt" in file:
        content = content.replace(
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }""",
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("route", "notification_details/Task/${taskId}?isAlarmRinging=false")
        }"""
        )

    if "BirthdayActionReceiver.kt" in file:
        content = content.replace(
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }""",
            """val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("route", "notification_details/${eventType}/${eventId}?isAlarmRinging=false")
            }"""
        )

    with open(file, "w") as f:
        f.write(content)

