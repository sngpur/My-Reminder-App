import re

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "r") as f:
    content = f.read()

old_code = """    if (!isUnlocked) {"""
new_code = """    LaunchedEffect(Unit) {
        if (!isUnlocked) {
            showBiometricPrompt()
        }
    }
    
    if (!isUnlocked) {"""

content = content.replace(old_code, new_code)

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "w") as f:
    f.write(content)

