import re

with open("app/src/main/java/com/example/NoteViewModel.kt", "r") as f:
    content = f.read()
content = content.replace('noteDao.deleteNote(note)', 'noteDao.softDeleteNoteById(note.id)')
with open("app/src/main/java/com/example/NoteViewModel.kt", "w") as f:
    f.write(content)

