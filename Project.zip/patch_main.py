import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Update routes
old_text_route = """        composable("note_editor_text") {
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteTextEditorScreen(navController = navController, viewModel = noteViewModel)
        }"""
new_text_route = """        composable(
            "note_editor_text?noteId={noteId}",
            arguments = listOf(androidx.navigation.navArgument("noteId") { type = androidx.navigation.NavType.StringType; nullable = true })
        ) { backStackEntry ->
            val noteIdStr = backStackEntry.arguments?.getString("noteId")
            val noteId = noteIdStr?.toIntOrNull()
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteTextEditorScreen(navController = navController, viewModel = noteViewModel, noteId = noteId)
        }"""
content = content.replace(old_text_route, new_text_route)

old_draw_route = """        composable("note_editor_drawing") {
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteDrawingEditorScreen(navController = navController, viewModel = noteViewModel)
        }"""
new_draw_route = """        composable(
            "note_editor_drawing?noteId={noteId}",
            arguments = listOf(androidx.navigation.navArgument("noteId") { type = androidx.navigation.NavType.StringType; nullable = true })
        ) { backStackEntry ->
            val noteIdStr = backStackEntry.arguments?.getString("noteId")
            val noteId = noteIdStr?.toIntOrNull()
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteDrawingEditorScreen(navController = navController, viewModel = noteViewModel, noteId = noteId)
        }"""
content = content.replace(old_draw_route, new_draw_route)

# Delete List and Image routes
list_route = """        composable("note_editor_list") {
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteListEditorScreen(navController = navController, viewModel = noteViewModel)
        }"""
content = content.replace(list_route, "")

img_route = """        composable("note_editor_image") {
            val noteViewModel: NoteViewModel = viewModel { NoteViewModel(application) }
            NoteImageEditorScreen(navController = navController, viewModel = noteViewModel)
        }"""
content = content.replace(img_route, "")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
