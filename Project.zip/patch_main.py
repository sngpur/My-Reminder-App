import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

old_code = """    val initialRoute = (context as? android.app.Activity)?.intent?.getStringExtra("route") ?: "home"
    val navController = rememberNavController()
        
    androidx.compose.runtime.LaunchedEffect(initialRoute) {
        if (initialRoute != "home") {
            navController.navigate(initialRoute)
        }
    }"""

new_code = """    val activityIntent = (context as? android.app.Activity)?.intent
    val entityId = activityIntent?.getIntExtra("EXTRA_ENTITY_ID", -1) ?: -1
    val entityType = activityIntent?.getStringExtra("EXTRA_ENTITY_TYPE")
    val isRinging = activityIntent?.getBooleanExtra("EXTRA_IS_RINGING", false) ?: false
    
    val initialRoute = if (entityId != -1 && entityType != null) {
        "notification_details/$entityType/$entityId?isAlarmRinging=$isRinging"
    } else {
        activityIntent?.getStringExtra("route") ?: "home"
    }

    val navController = rememberNavController()
        
    androidx.compose.runtime.LaunchedEffect(initialRoute) {
        if (initialRoute != "home") {
            navController.navigate(initialRoute)
        }
    }"""

content = content.replace(old_code, new_code)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
