import re

with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    original_code = f.read()

start_index = original_code.find("@Composable\nfun BentoDashboard(")
end_index = original_code.find("@Composable\nfun ReminderCard(", start_index)

if start_index == -1 or end_index == -1:
    print("Could not find bounds")
    exit(1)

new_bento = """@Composable
fun BentoDashboard(
    reminders: List<Reminder>,
    nearestBirthday: Pair<com.example.Event, Long>?,
    nearestAnniversary: Pair<com.example.Event, Long>?,
    latestBikeMileage: Double?,
    latestCarMileage: Double?,
    onMonthlySummaryClick: () -> Unit
) {
    val now = LocalDateTime.now()
    val upcomingTasks = reminders.filter { !it.isCompleted }.filter {
        !it.getNextActiveReminder().isPassed
    }.sortedBy { it.getNextActiveReminder().dateTime }
    
    val nearestTask = upcomingTasks.firstOrNull()
    
    val currentYearMonth = YearMonth.now()
    var currentMonthPayment = 0.0
    var currentMonthLent = 0.0
    
    reminders.forEach { r ->
        val date = LocalDate.parse(r.taskDate)
        if (YearMonth.from(date) == currentYearMonth && r.amount != null) {
            if (r.category == "Upcoming Payment") currentMonthPayment += r.amount
            else if (r.category == "Money Lent (Udhar)") currentMonthLent += r.amount
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Row 1: Upcoming Task | Finance
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Nearest Upcoming
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Box(modifier = Modifier.size(28.dp).background(MaterialTheme.colorScheme.primary.copy(alpha=0.2f), shape = RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                            Icon(androidx.compose.material.icons.Icons.Outlined.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        }
                        Surface(color = MaterialTheme.colorScheme.primary.copy(alpha=0.15f), shape = RoundedCornerShape(12.dp)) {
                            Text("UPCOMING", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    if (nearestTask != null) {
                        Text(nearestTask.taskTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("${nearestTask.getNextActiveReminder().dateTime.toLocalDate()}", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                    } else {
                        Text("No upcoming tasks", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            
            // Right Card: Finance
            Card(
                modifier = Modifier.weight(1f).height(130.dp).clickable { onMonthlySummaryClick() },
                shape = RoundedCornerShape(20.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.linearGradient(colors = listOf(Color(0xFF8B5CF6), Color(0xFF3B82F6))))) {
                    Column(modifier = Modifier.padding(12.dp).fillMaxSize()) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Box(modifier = Modifier.size(28.dp).background(Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                Icon(androidx.compose.material.icons.Icons.Filled.AccountBalanceWallet, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                            Surface(color = Color.White.copy(alpha=0.2f), shape = RoundedCornerShape(12.dp)) {
                                Text("FINANCE", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.weight(1f))
                        Text("Pay: ₹${currentMonthPayment.toInt()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("Lent: ₹${currentMonthLent.toInt()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("View Breakdown", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha=0.8f))
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = Color.White.copy(alpha=0.8f), modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }
        
        // Row 2: Birthday | Anniversary
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Birthday
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.Cake, contentDescription = null, tint = Color(0xFFF43F5E), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Birthday", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (nearestBirthday != null) {
                        Text(nearestBirthday.first.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Text("${nearestBirthday.second} days left", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // Right Card: Anniversary
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.Favorite, contentDescription = null, tint = Color(0xFFEC4899), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Anniv.", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (nearestAnniversary != null) {
                        Text(nearestAnniversary.first.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Text("${nearestAnniversary.second} days left", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        
        // Row 3: Bike | Car
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Left Card: Bike Mileage
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.TwoWheeler, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Bike", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (latestBikeMileage != null) {
                        Text("${String.format("%.1f", latestBikeMileage)} km/l", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Text("Last refuel", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // Right Card: Car Mileage
            Card(
                modifier = Modifier.weight(1f).height(130.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp).fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(androidx.compose.material.icons.Icons.Rounded.DirectionsCar, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Car", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (latestCarMileage != null) {
                        Text("${String.format("%.1f", latestCarMileage)} km/l", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Text("Last refuel", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    } else {
                        Text("No data", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
"""

new_content = original_code[:start_index] + new_bento + original_code[end_index:]

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(new_content)

