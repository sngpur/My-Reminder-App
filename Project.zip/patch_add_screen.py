import re

with open("app/src/main/java/com/example/AddReminderScreen.kt", "r") as f:
    content = f.read()

# Add isAlarmEnabled state
content = content.replace('var imageUri by remember { mutableStateOf<String?>(existingReminder?.imageUri) }', 'var imageUri by remember { mutableStateOf<String?>(existingReminder?.imageUri) }\n    var isAlarmEnabled by remember { mutableStateOf(existingReminder?.isAlarmEnabled ?: false) }')

# Add Alarm vs Notification Toggle
toggle_ui = """                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Ring Full Alarm", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                            Switch(checked = isAlarmEnabled, onCheckedChange = { isAlarmEnabled = it })
                        }
                    }
"""
content = re.sub(r'                        \}\n                    \}\n                \}\n            \}', toggle_ui + '                }\n            }', content, count=1) # Need to be careful here

with open("app/src/main/java/com/example/AddReminderScreen.kt", "w") as f:
    f.write(content)
