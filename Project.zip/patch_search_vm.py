import re

with open("app/src/main/java/com/example/GlobalSearchViewModel.kt", "r") as f:
    content = f.read()

pattern = r"    val searchResults: StateFlow<List<SearchResult>> = combine\(\s*searchQuery,.*?(?=\.stateIn)"

new_code = """    private data class SearchData(
        val reminders: List<Reminder>,
        val events: List<Event>,
        val fuelRecords: List<FuelRecord>,
        val vaultRecords: List<VaultRecord>,
        val notes: List<Note>
    )

    private val allDataFlow = combine(
        reminderDao.getAllReminders(),
        eventDao.getAllEvents(),
        fuelRecordDao.getAllFuelRecords(),
        vaultRecordDao.getAllVaultRecords(),
        noteDao.getAllNotes()
    ) { reminders, events, fuelRecords, vaultRecords, notes ->
        SearchData(reminders, events, fuelRecords, vaultRecords, notes)
    }

    val searchResults: StateFlow<List<SearchResult>> = combine(
        searchQuery,
        allDataFlow
    ) { query, data ->
        if (query.isBlank()) return@combine emptyList()
        
        val q = query.lowercase()
        val results = mutableListOf<SearchResult>()

        results.addAll(data.reminders.filter { 
            it.taskTitle.lowercase().contains(q) || it.location.lowercase().contains(q) || it.tags.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, it.taskTitle, "${it.taskDate} • ${it.taskTime}", "Task", "edit_reminder/${it.id}") 
        })

        results.addAll(data.events.filter { 
            it.name.lowercase().contains(q) || it.eventType.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, "${it.name}'s ${it.eventType}", it.date, "Event", "birthday_anniversary") 
        })

        results.addAll(data.fuelRecords.filter { 
            it.vehicleType.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, "${it.vehicleType} Fuel Record", "${it.odometerKm} km", "Mileage", "milage_calculator") 
        })

        results.addAll(data.vaultRecords.filter { 
            it.title.lowercase().contains(q)
        }.map { 
            SearchResult(it.id, it.title, "Secure Vault • ${it.type}", "Vault", "secure_vault") 
        })

        results.addAll(data.notes.filter { 
            it.title.lowercase().contains(q) || it.content.lowercase().contains(q)
        }.map { 
            val route = if (it.type == "Drawing") "note_editor_drawing?noteId=${it.id}" else "note_editor_text?noteId=${it.id}"
            SearchResult(it.id, it.title, "Note • ${it.type}", "Note", route) 
        })

        results.sortedBy { it.title }
    }"""

content = re.sub(pattern, new_code, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/GlobalSearchViewModel.kt", "w") as f:
    f.write(content)
