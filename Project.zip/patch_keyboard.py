import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add imports
imports = """import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.layout.Box
"""
if "import androidx.compose.ui.platform.LocalFocusManager" not in content:
    content = content.replace("import androidx.compose.ui.platform.LocalContext", imports + "import androidx.compose.ui.platform.LocalContext")

old_code = """        setContent {
            val settingsViewModel: SettingsViewModel = viewModel { SettingsViewModel(application) }
            val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
            MyApplicationTheme(isDarkModeOverride = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SomnathReminderApp(settingsViewModel)
                }
            }
        }"""

new_code = """        setContent {
            val settingsViewModel: SettingsViewModel = viewModel { SettingsViewModel(application) }
            val isDarkMode by settingsViewModel.isDarkMode.collectAsStateWithLifecycle()
            MyApplicationTheme(isDarkModeOverride = isDarkMode) {
                val focusManager = LocalFocusManager.current
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(onTap = { focusManager.clearFocus() })
                        },
                    color = MaterialTheme.colorScheme.background
                ) {
                    SomnathReminderApp(settingsViewModel)
                }
            }
        }"""

content = content.replace(old_code, new_code)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

