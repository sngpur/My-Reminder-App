with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

old_parse = """                var monthStr = dateStr
                var dayStr = ""
                try {
                    val date = LocalDate.parse(dateStr)
                    monthStr = date.month.name.take(3).uppercase()
                    dayStr = String.format(java.util.Locale.getDefault(), "%02d", date.dayOfMonth)
                } catch (e: Exception) {
                    // Ignore parsing error
                }"""

new_parse = """                val (monthStr, dayStr) = remember(dateStr) {
                    var mStr = dateStr
                    var dStr = ""
                    try {
                        val date = LocalDate.parse(dateStr)
                        mStr = date.month.name.take(3).uppercase()
                        dStr = String.format(java.util.Locale.getDefault(), "%02d", date.dayOfMonth)
                    } catch (e: Exception) {}
                    Pair(mStr, dStr)
                }"""

content = content.replace(old_parse, new_parse)

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)

