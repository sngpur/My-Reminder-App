import re

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "r") as f:
    content = f.read()

# Replace the categories list
content = content.replace(
    'val categories = listOf("Password", "Card", "Note")',
    'val categories = listOf("Password", "Bank Card", "Secure Note")'
)

# Replace the default category if needed
content = content.replace(
    'var category by remember { mutableStateOf(recordToEdit?.category ?: "Password") }',
    'var category by remember { mutableStateOf(recordToEdit?.category ?: "Password") }'
)

# Update the label and icon logic to match new categories
content = content.replace(
    'label = { Text(if (category == "Card") "Card Number" else if (category == "Note") "Secret Note" else "Password") }',
    'label = { Text(if (category == "Bank Card") "Card Number" else if (category == "Secure Note") "Secret Note" else "Password") }'
)

content = content.replace(
    'visualTransformation = if (category == "Note") VisualTransformation.None else PasswordVisualTransformation()',
    'visualTransformation = if (category == "Secure Note") VisualTransformation.None else PasswordVisualTransformation()'
)

content = content.replace(
    '"Card" -> Icons.Default.CreditCard\n        "Note" -> Icons.Default.Notes',
    '"Bank Card" -> Icons.Default.CreditCard\n        "Secure Note" -> Icons.Default.Notes\n        "Card" -> Icons.Default.CreditCard\n        "Note" -> Icons.Default.Notes'
)

# Update VaultItemCard to add Delete Confirmation
new_vault_card = """@Composable
fun VaultItemCard(record: VaultRecord, onEdit: () -> Unit, onDelete: () -> Unit) {
    val context = LocalContext.current
    var isVisible by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    
    val icon = when (record.category) {
        "Bank Card", "Card" -> Icons.Default.CreditCard
        "Secure Note", "Note" -> Icons.Default.Notes
        else -> Icons.Default.Password
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Item") },
            text = { Text("Are you sure you want to delete this secure item?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth().clickable { onEdit() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = record.category,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = record.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = record.category,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { showDeleteConfirm = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isVisible) record.secretData else "••••••••••••••••",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                
                Row {
                    IconButton(onClick = { isVisible = !isVisible }) {
                        Icon(
                            imageVector = if (isVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (isVisible) "Hide" else "Show"
                        )
                    }
                    IconButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Secret Data", record.secretData))
                        Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                    }
                }
            }
            
            if (record.extraInfo.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = record.extraInfo,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}"""

content = re.sub(r'@Composable\nfun VaultItemCard.*?\n}\n', new_vault_card + '\n', content, flags=re.DOTALL)

with open("app/src/main/java/com/example/SecureVaultScreen.kt", "w") as f:
    f.write(content)
