with open("app/src/main/java/com/example/QuickAddTileService.kt", "r") as f:
    content = f.read()

content = content.replace(
    "android.app.PendingIntent.FLAG_IMMUTABLE",
    "android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE"
)

with open("app/src/main/java/com/example/QuickAddTileService.kt", "w") as f:
    f.write(content)
