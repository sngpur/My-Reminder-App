import sys

with open("app/src/main/java/com/example/TextScannerScreen.kt", "r") as f:
    content = f.read()

import_statement = """
import androidx.activity.result.PickVisualMediaRequest
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.provider.MediaStore
"""

if "import com.google.mlkit.vision.text.TextRecognition" not in content:
    content = content.replace("import com.google.mlkit.vision.documentscanner", import_statement + "\nimport com.google.mlkit.vision.documentscanner")


gallery_launcher = """
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(context, uri)
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        if (visionText.text.isNotBlank()) {
                            tempPdfUri = uri // we don't have pdf, but we can reuse this logic, or just save without pdf
                            tempPageCount = 1
                            documentTitle = "Gallery Scan"
                            // For gallery, we just extract text, so maybe save directly or show dialog?
                            // Let's just save directly since we don't have a pdf. Wait, no, we can show dialog.
                            // But wait, the dialog expects pdfUri to be non-null to save.
                            // If we don't have a PDF, copyPdfToInternalStorage will fail if it's not a pdf.
                            // Let's just create a dummy file or skip pdf saving for gallery images?
                            // Or just copy the image as pdf? No, image is not pdf.
                            // Better: For gallery images, we just save the ScannedText with extracted text!
                            
                            viewModel.insertScannedText(
                                ScannedText(
                                    title = "Gallery Scan",
                                    extractedText = visionText.text,
                                    dateMillis = System.currentTimeMillis(),
                                    pdfUri = null,
                                    pageCount = 1
                                )
                            )
                            Toast.makeText(context, "Text extracted from Gallery", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "No text found in image", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(context, "Failed to extract text: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
"""

if "galleryLauncher" not in content:
    content = content.replace("val scannerLauncher =", gallery_launcher + "\n    val scannerLauncher =")


content = content.replace("""Card(
                    modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clickable { launchScanner() },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                )""", """Card(
                    modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clickable { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                )""")

with open("app/src/main/java/com/example/TextScannerScreen.kt", "w") as f:
    f.write(content)
