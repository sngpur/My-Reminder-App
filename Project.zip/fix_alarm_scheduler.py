import re

with open("app/src/main/java/com/example/AlarmScheduler.kt", "r") as f:
    content = f.read()

old_parse = """            val eventDate = LocalDate.parse(event.date)"""
new_parse = """            val formatter = java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy", java.util.Locale.getDefault())
            val eventDate = LocalDate.parse("${event.date} ${LocalDateTime.now().year}", formatter)"""

content = content.replace(old_parse, new_parse)

with open("app/src/main/java/com/example/AlarmScheduler.kt", "w") as f:
    f.write(content)

