import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

route_insert = """        composable("secure_vault") {
            val secureVaultViewModel: SecureVaultViewModel = viewModel { SecureVaultViewModel(application) }
            SecureVaultScreen(navController = navController, viewModel = secureVaultViewModel)
        }
        composable("whatsapp_scheduler") {
            val whatsappViewModel: WhatsAppViewModel = viewModel { WhatsAppViewModel(application) }
            WhatsAppSchedulerScreen(navController = navController, viewModel = whatsappViewModel)
        }"""

content = content.replace('        composable("secure_vault") {\n            val secureVaultViewModel: SecureVaultViewModel = viewModel { SecureVaultViewModel(application) }\n            SecureVaultScreen(navController = navController, viewModel = secureVaultViewModel)\n        }', route_insert)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
