with open("app/src/main/java/com/example/SettingsViewModel.kt", "r") as f:
    content = f.read()

old_block = """    private fun scheduleAutoBackup() {
        val backupRequest = PeriodicWorkRequestBuilder<BackupWorker>(7, TimeUnit.DAYS)
            .build()"""
new_block = """    private fun scheduleAutoBackup() {
        val constraints = androidx.work.Constraints.Builder()
            .setRequiresDeviceIdle(true)
            .setRequiresCharging(true)
            .build()
        val backupRequest = PeriodicWorkRequestBuilder<BackupWorker>(7, TimeUnit.DAYS)
            .setConstraints(constraints)
            .build()"""

content = content.replace(old_block, new_block)

with open("app/src/main/java/com/example/SettingsViewModel.kt", "w") as f:
    f.write(content)
