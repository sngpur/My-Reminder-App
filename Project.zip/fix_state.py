import glob
import re

for filename in glob.glob("app/src/main/java/com/example/**/*.kt", recursive=True):
    with open(filename, "r") as f:
        content = f.read()

    if ".collectAsState(" in content:
        # Check if collectAsStateWithLifecycle is imported
        if "androidx.lifecycle.compose.collectAsStateWithLifecycle" not in content:
            content = content.replace("import androidx.compose.runtime.collectAsState", "import androidx.lifecycle.compose.collectAsStateWithLifecycle")
            
        content = content.replace(".collectAsState(", ".collectAsStateWithLifecycle(")
        
        with open(filename, "w") as f:
            f.write(content)
