with open("app/build.gradle.kts", "r") as f:
    content = f.read()

packaging_block = """
  packaging {
    resources {
      excludes += "META-INF/INDEX.LIST"
      excludes += "META-INF/io.netty.versions.properties"
    }
  }
"""

content = content.replace("  buildFeatures {", packaging_block + "\n  buildFeatures {")

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
