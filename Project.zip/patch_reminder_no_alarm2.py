import re

with open("app/src/main/java/com/example/AddReminderScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    'OutlinedTextField(\n                                value = reminder2TimeStr ?: "",\n                                onValueChange = {},\n                                readOnly = true,\n                                placeholder = { Text("Time") },',
    'OutlinedTextField(\n                                value = reminder2TimeStr ?: "",\n                                onValueChange = {},\n                                readOnly = true,\n                                placeholder = { Text("No Alarm") },'
)

content = content.replace(
    'OutlinedTextField(\n                                value = reminder3TimeStr ?: "",\n                                onValueChange = {},\n                                readOnly = true,\n                                placeholder = { Text("Time") },',
    'OutlinedTextField(\n                                value = reminder3TimeStr ?: "",\n                                onValueChange = {},\n                                readOnly = true,\n                                placeholder = { Text("No Alarm") },'
)

with open("app/src/main/java/com/example/AddReminderScreen.kt", "w") as f:
    f.write(content)
