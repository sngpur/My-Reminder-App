import os
import re

files_to_update = [
    "app/src/main/java/com/example/NotificationReceiver.kt",
    "app/src/main/java/com/example/MarkCompleteReceiver.kt",
    "app/src/main/java/com/example/BootReceiver.kt",
    "app/src/main/java/com/example/ServicingActionReceiver.kt",
    "app/src/main/java/com/example/WhatsAppAlarmReceiver.kt",
    "app/src/main/java/com/example/WhatsAppActionReceiver.kt",
    "app/src/main/java/com/example/MorningBriefingReceiver.kt"
]

for file in files_to_update:
    if not os.path.exists(file):
        continue
    
    with open(file, "r") as f:
        lines = f.readlines()
    
    new_lines = []
    in_coroutine = False
    brace_count = 0
    
    for line in lines:
        if "CoroutineScope(Dispatchers.IO).launch {" in line:
            new_lines.append(line.replace("CoroutineScope(Dispatchers.IO).launch {", "val pendingResult = goAsync()\n        CoroutineScope(Dispatchers.IO).launch {\n            try {"))
            in_coroutine = True
            brace_count = 1
        elif in_coroutine:
            if "{" in line:
                brace_count += line.count("{")
            if "}" in line:
                brace_count -= line.count("}")
                
            if brace_count == 0:
                # We reached the end of the coroutine
                new_lines.append("            } finally {\n                pendingResult.finish()\n            }\n        }\n")
                in_coroutine = False
            else:
                new_lines.append(line)
        else:
            new_lines.append(line)

    with open(file, "w") as f:
        f.writelines(new_lines)

