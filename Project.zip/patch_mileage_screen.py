import re

with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "r") as f:
    content = f.read()

# 1. Add logToEdit
if "var logToEdit" not in content:
    content = content.replace("var showServiceDialog by remember { mutableStateOf(false) }", "var showServiceDialog by remember { mutableStateOf(false) }\n    var logToEdit by remember { mutableStateOf<FuelRecord?>(null) }")

    # Update FloatingActionButton
    content = content.replace("""FloatingActionButton(onClick = {
                            if (tabIndex == 0) showFuelDialog = true
                            else showServiceDialog = true
                        })""", """FloatingActionButton(onClick = {
                            if (tabIndex == 0) {
                                logToEdit = null
                                showFuelDialog = true
                            } else {
                                showServiceDialog = true
                            }
                        })""")

    # Fuel dialog values
    content = content.replace("var odometerStr by remember { mutableStateOf(\"\") }", "var odometerStr by remember { mutableStateOf(logToEdit?.odometerKm?.toString() ?: \"\") }")
    content = content.replace("var fuelLitersStr by remember { mutableStateOf(\"\") }", "var fuelLitersStr by remember { mutableStateOf(logToEdit?.fuelLiters?.toString() ?: \"\") }")
    content = content.replace("var dateMillis by remember { mutableStateOf(System.currentTimeMillis()) }", "var dateMillis by remember { mutableStateOf(logToEdit?.dateMillis ?: System.currentTimeMillis()) }")
    
    # Save button logic in fuel dialog
    content = content.replace("""viewModel.addFuelRecord(FuelRecord(vehicleType = fuelVehicleType, dateMillis = dateMillis, odometerKm = odo, fuelLiters = fuel))""", """if (logToEdit == null) {
                                    viewModel.addFuelRecord(FuelRecord(vehicleType = fuelVehicleType, dateMillis = dateMillis, odometerKm = odo, fuelLiters = fuel))
                                } else {
                                    viewModel.updateFuelRecord(logToEdit!!.copy(dateMillis = dateMillis, odometerKm = odo, fuelLiters = fuel))
                                }""")

    # Update itemCard
    content = re.sub(
        r'fun FuelRecordCard\(record: FuelRecord\).*?\}\s*\}',
        r'''fun FuelRecordCard(record: FuelRecord, onEdit: () -> Unit, onDelete: () -> Unit) {
    var showDelete by remember { mutableStateOf(false) }
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete Record") },
            text = { Text("Are you sure you want to delete this fuel record?") },
            confirmButton = { TextButton(onClick = { showDelete = false; onDelete() }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } }
        )
    }
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onEdit() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${record.odometerKm} km",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = Instant.ofEpochMilli(record.dateMillis).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Fuel: ${record.fuelLiters} L",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    IconButton(onClick = { showDelete = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}''',
        content,
        flags=re.DOTALL
    )

    # Call side
    content = content.replace("FuelRecordCard(record = record)", "FuelRecordCard(record = record, onEdit = { logToEdit = record; showFuelDialog = true }, onDelete = { viewModel.deleteFuelRecord(record) })")
    
    with open("app/src/main/java/com/example/MilageCalculatorScreen.kt", "w") as f:
        f.write(content)

