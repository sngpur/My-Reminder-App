import re

with open("app/src/main/java/com/example/EventDao.kt", "r") as f:
    content = f.read()
if "updateEvent" not in content:
    content = content.replace("import androidx.room.Insert", "import androidx.room.Insert\nimport androidx.room.Update\nimport androidx.room.Delete")
    content = content.replace("suspend fun insertEvent(event: Event)", "suspend fun insertEvent(event: Event)\n\n    @Update\n    suspend fun updateEvent(event: Event)\n\n    @Delete\n    suspend fun deleteEvent(event: Event)")
    with open("app/src/main/java/com/example/EventDao.kt", "w") as f:
        f.write(content)

with open("app/src/main/java/com/example/EventViewModel.kt", "r") as f:
    content = f.read()
if "updateEvent" not in content:
    content = content.replace("fun addEvent(event: Event) {", "fun updateEvent(event: Event) {\n        viewModelScope.launch {\n            eventDao.updateEvent(event)\n        }\n    }\n\n    fun deleteEvent(event: Event) {\n        viewModelScope.launch {\n            eventDao.deleteEvent(event)\n        }\n    }\n\n    fun addEvent(event: Event) {")
    with open("app/src/main/java/com/example/EventViewModel.kt", "w") as f:
        f.write(content)
