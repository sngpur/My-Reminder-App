import re

with open("app/src/main/java/com/example/ReminderViewModel.kt", "r") as f:
    content = f.read()

content = content.replace('it.type == "Birthday"', 'it.eventType == "Birthday"')
content = content.replace('it.type == "Anniversary"', 'it.eventType == "Anniversary"')

with open("app/src/main/java/com/example/ReminderViewModel.kt", "w") as f:
    f.write(content)
