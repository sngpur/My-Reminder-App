import re

with open("app/src/main/java/com/example/NotificationDetailsScreen.kt", "r") as f:
    content = f.read()

old_code = """    fun cancelNotification() {
        val notifId = when (entityType) {
            "Task" -> entityId + 10000
            "Birthday", "Anniversary" -> entityId + 30000
            "Vehicle" -> entityId + 100000
            else -> entityId
        }
        notificationManager.cancel(notifId)
    }"""

new_code = """    fun cancelNotification() {
        when (entityType) {
            "Task" -> {
                notificationManager.cancel(entityId)
                notificationManager.cancel(entityId + 10000)
            }
            "Birthday", "Anniversary" -> notificationManager.cancel(entityId + 30000)
            "Vehicle" -> notificationManager.cancel(entityId + 100000)
            else -> notificationManager.cancel(entityId)
        }
    }"""

content = content.replace(old_code, new_code)

with open("app/src/main/java/com/example/NotificationDetailsScreen.kt", "w") as f:
    f.write(content)

