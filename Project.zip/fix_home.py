with open("app/src/main/java/com/example/HomeScreen.kt", "r") as f:
    content = f.read()

content = content.replace("IconButton(onClick = { isSearchActive = true }) {", "IconButton(onClick = { navController.navigate(\"global_search\") }) {")

with open("app/src/main/java/com/example/HomeScreen.kt", "w") as f:
    f.write(content)
