import re

with open("app/src/main/AndroidManifest.xml", "r") as f:
    content = f.read()

widget_code = """        <receiver
            android:name=".MyBuddyWidgetReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data
                android:name="android.appwidget.provider"
                android:resource="@xml/my_buddy_widget_info" />
        </receiver>
        
    </application>"""

if "MyBuddyWidgetReceiver" not in content:
    content = content.replace("</application>", widget_code)

with open("app/src/main/AndroidManifest.xml", "w") as f:
    f.write(content)
