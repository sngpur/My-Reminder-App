import re

files = [
    "app/src/main/java/com/example/AlarmService.kt",
    "app/src/main/java/com/example/BirthdayAlarmService.kt",
    "app/src/main/java/com/example/ServicingAlarmReceiver.kt",
    "app/src/main/java/com/example/BirthdayAlarmReceiver.kt",
    "app/src/main/java/com/example/AlarmStopReceiver.kt",
    "app/src/main/java/com/example/BirthdayActionReceiver.kt",
    "app/src/main/java/com/example/NotificationReceiver.kt"
]

for file in files:
    with open(file, "r") as f:
        content = f.read()

    # Remove the route extra if it exists
    content = re.sub(r'putExtra\("route", "notification_details.*"\)\n\s*', '', content)

    # Now add the new extras
    if "AlarmService.kt" in file:
        content = content.replace(
            """this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK""",
            """this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", notificationId)
            putExtra("EXTRA_ENTITY_TYPE", "Task")
            putExtra("EXTRA_IS_RINGING", true)"""
        )
    elif "BirthdayAlarmService.kt" in file:
        content = content.replace(
            """this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK""",
            """this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", eventId)
            putExtra("EXTRA_ENTITY_TYPE", eventType)
            putExtra("EXTRA_IS_RINGING", true)"""
        )
    elif "ServicingAlarmReceiver.kt" in file:
        content = content.replace(
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK""",
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", recordId)
            putExtra("EXTRA_ENTITY_TYPE", "Vehicle")
            putExtra("EXTRA_IS_RINGING", false)"""
        )
    elif "BirthdayAlarmReceiver.kt" in file:
        content = content.replace(
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK""",
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", eventId)
            putExtra("EXTRA_ENTITY_TYPE", eventType)
            putExtra("EXTRA_IS_RINGING", false)"""
        )
    elif "AlarmStopReceiver.kt" in file:
        content = content.replace(
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK""",
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_ENTITY_ID", taskId)
            putExtra("EXTRA_ENTITY_TYPE", "Task")
            putExtra("EXTRA_IS_RINGING", false)"""
        )
    elif "BirthdayActionReceiver.kt" in file:
        content = content.replace(
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK""",
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("EXTRA_ENTITY_ID", eventId)
                putExtra("EXTRA_ENTITY_TYPE", eventType)
                putExtra("EXTRA_IS_RINGING", false)"""
        )
    elif "NotificationReceiver.kt" in file:
        content = content.replace(
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK""",
            """flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("EXTRA_ENTITY_ID", id)
                putExtra("EXTRA_ENTITY_TYPE", "Task")
                putExtra("EXTRA_IS_RINGING", false)"""
        )

    with open(file, "w") as f:
        f.write(content)
